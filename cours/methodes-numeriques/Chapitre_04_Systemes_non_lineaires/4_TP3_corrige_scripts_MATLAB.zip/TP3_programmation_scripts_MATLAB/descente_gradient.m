function [x, k] = descente_gradient(F, JF, x0, alpha, tol, nmax)
% DESCENTE_GRADIENT  Descente de gradient a pas fixe sur G(x) = 1/2 ||F(x)||^2  (Manipulation 4).
%   Le gradient de G est  JF(x)' * F(x) : un simple produit matrice-vecteur, AUCUN systeme lineaire a resoudre.
%   Arret quand ||grad G|| < tol ; k = numero de l'iteration ou le test est satisfait.
  x = x0(:);
  for k = 1:nmax
    g = JF(x)' * F(x);
    if norm(g) < tol, break; end
    x = x - alpha * g;
  end
  if ~(norm(g) < tol)
    warning('Pas de convergence.');
  end
end
