%% video_chrono.m
% TP3 : cout de Newton et de la descente de gradient sur le systeme de pompage (un seul coeur, mediane de plusieurs essais).
% Les secondes dependent de la machine ; ce qui compte, c'est le RAPPORT entre les deux methodes.
% Lancement (depuis ce dossier, machine au repos) :  matlab -batch "video_chrono"      (sortie : sorties/video_chrono.txt)
% Duree : quelques secondes.
clear; clc;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_chrono.txt', 'file'), delete('sorties/video_chrono.txt'); end
diary('sorties/video_chrono.txt');

nthreads_avant = maxNumCompThreads;
maxNumCompThreads(1);
R1 = 2;  R2 = 8;  Qtot = 30;
F  = @(x) [x(1) + x(2) - Qtot; R1*x(1)^2 - R2*x(2)^2];
JF = @(x) [1, 1; 2*R1*x(1), -2*R2*x(2)];
x0 = [15; 15];
fprintf('systeme de pompage, depart (15, 15), un seul coeur\n');

[~, kN] = newton_systeme(F, JF, x0, 1e-10, 20);
tn = arrayfun(@(r) timeit(@() newton_systeme(F, JF, x0, 1e-10, 20)), 1:15);
tN = median(tn);
fprintf('Newton : %d iterations, %.0f microsecondes par resolution complete (mediane de 15 mesures timeit ; min %.0f, max %.0f)\n', ...
    kN, 1e6 * tN, 1e6 * min(tn), 1e6 * max(tn));

nrep = 7;
tg = zeros(1, nrep);
for r = 1:nrep
  tic;  [~, kG] = descente_gradient(F, JF, x0, 3e-5, 1e-6, 500000);  tg(r) = toc;
end
tG = median(tg);
fprintf('descente de gradient (alpha = 3e-5) : %d iterations, %.0f millisecondes (mediane de %d essais ; min %.0f, max %.0f)\n', ...
    kG, 1e3 * tG, nrep, 1e3 * min(tg), 1e3 * max(tg));
fprintf('rapport des durees : %.0f ; rapport des nombres d''iterations : %.0f\n', tG / tN, kG / kN);
fprintf('cout par iteration : Newton %.2f microsecondes, gradient %.2f microsecondes\n', 1e6 * tN / kN, 1e6 * tG / kG);

[F3, JF3] = pompage([2 8 4], 30);
t3 = median(arrayfun(@(r) timeit(@() newton_systeme(F3, JF3, 10*ones(3, 1), 1e-10, 20)), 1:15));
fprintf('Newton, 3 conduites : %.0f microsecondes (mediane)\n', 1e6 * t3);
maxNumCompThreads(nthreads_avant);
diary off;
