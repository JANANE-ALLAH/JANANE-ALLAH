%% video_essais.m
% TP3 -- video "programmer la methode de Newton sous MATLAB" (systeme de pompage, chapitre 4).
% Tous les nombres et toutes les sorties affichees dans la video viennent de ce script.
% Lancement (depuis ce dossier) :  matlab -batch "video_essais"      (sortie : sorties/video_essais.txt)
% Les fonctions pompage, newton_systeme, jacobienne_fd, descente_gradient et newton_signe_faux sont dans ce dossier.
% Duree : environ 30 secondes.
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_essais.txt', 'file'), delete('sorties/video_essais.txt'); end
diary('sorties/video_essais.txt');
tol = 1e-10;  nmax = 20;

%% 0) Le systeme de pompage et ses deux fonctions
disp('=== 0) le systeme (R1 = 2, R2 = 8, Qtot = 30)');
R1 = 2;  R2 = 8;  Qtot = 30;
F  = @(x) [x(1) + x(2) - Qtot; R1*x(1)^2 - R2*x(2)^2];
JF = @(x) [1, 1; 2*R1*x(1), -2*R2*x(2)];
x = [15; 15]
Fx = F(x)
Jx = JF(x)
Q1ex = Qtot / (1 + sqrt(R1/R2));
fprintf('solution analytique : Q1 = Qtot/(1 + sqrt(R1/R2)) = %.6f, Q2 = %.6f\n', Q1ex, Qtot - Q1ex);
xex = [20; 10];
fprintf('F(20, 10) = %s ; F(60, -30) = %s\n', mat2str(F(xex)'), mat2str(F([60; -30])'));
fprintf('JF au depart, det = %.0f, cond = %.2f\n', det(Jx), cond(Jx));
[F2, JF2] = pompage([2 8], 30);
fprintf('pompage([2 8], 30) contre F, JF ecrits a la main : ecarts %g et %g\n', norm(F2(x) - F(x)), norm(JF2(x) - JF(x)));

%% 1) Un pas de Newton a la main
disp('=== 1) un pas de Newton, a la main (x0 = (15, 15))');
m21 = Jx(2, 1) / Jx(1, 1);
U22 = Jx(2, 2) - m21 * Jx(1, 2);
c2  = -Fx(2) - m21 * (-Fx(1));
d2  = c2 / U22;
d1  = (-Fx(1) - Jx(1, 2) * d2) / Jx(1, 1);
fprintf('Gauss : m21 = %g ; U22 = %g ; second membre = %g ; delta2 = %g ; delta1 = %g\n', m21, U22, c2, d2, d1);
delta = -JF(x) \ F(x)
x1 = x + delta
fprintf('F(x1) = %s ; Q1 + Q2 = %g (la droite de conservation du debit)\n', mat2str(F(x1)', 8), x1(1) + x1(2));
fprintf('inv(J)*(-F) = %s ; ecart avec J\\(-F) = %g\n', mat2str((-inv(Jx) * Fx)', 6), norm(-inv(Jx)*Fx - delta));

%% 2) La fonction newton_systeme, depart (15, 15)
disp('=== 2) newton_systeme depuis (15, 15)');
[xs, k, X] = newton_systeme(F, JF, [15; 15], tol, nmax);
xs
k
fprintf('%2s %14s %14s %11s\n', 'k', 'Q1', 'Q2', '||F||');
for j = 0:k
  fprintf('%2d %14.8f %14.8f %11.3e\n', j, X(1, j+1), X(2, j+1), norm(F(X(:, j+1))));
end
inc = vecnorm(diff(X, 1, 2));
fprintf('pas ||delta|| : '); fprintf('%.3e ', inc); fprintf('\n');
writematrix(X', 'sorties/newton_15_15.csv');
disp('apres 1 et 2 iterations, ||x - xex|| et chiffres exacts de Q1 : ');
fprintf('Q1 : '); fprintf('%.10f  ', X(1, :)); fprintf('\n');

%% 3) Manipulation 1 : l'ordre de convergence
disp('=== 3) Manipulation 1 : erreurs et rapports');
e = vecnorm(X - xex)
rapport = e(2:end) ./ e(1:end-1).^2
fprintf('chiffres exacts -log10(e) : '); fprintf('%.2f ', -log10(e(1:5))); fprintf('\n');
p = polyfit(log(e(2:4)), log(e(3:5)), 1);
fprintf('pente (iterations 1 a 4) = %.4f, ordonnee = %.4f, C = exp(ordonnee) = %.5f\n', p(1), p(2), exp(p(2)));
fprintf('increment a l''arret = %.3e, erreur de l''iteree precedente = %.3e\n', inc(end), e(end-1));
fprintf('erreur apres arret = %.3e ; tol = %.0e\n', e(end), tol);
writematrix([(0:k)' e'], 'sorties/erreurs_newton.csv');
figure('Visible', 'off');
semilogy(0:k-1, e(1:k), 'o-', 'LineWidth', 1.5);  grid on;
xlabel('iteration k');  ylabel('erreur ||x(k) - x*||_2');
saveas(gcf, 'sorties/convergence_newton.png');

%% 4) Manipulation 2 : depuis (50, -20), puis la carte des bassins
disp('=== 4) Manipulation 2 : depuis (50, -20)');
[x2, k2, X2] = newton_systeme(F, JF, [50; -20], tol, nmax);
x2
k2
fprintf('%2s %14s %14s %11s\n', 'k', 'Q1', 'Q2', '||F||');
for j = 0:k2
  fprintf('%2d %14.8f %14.8f %11.3e\n', j, X2(1, j+1), X2(2, j+1), norm(F(X2(:, j+1))));
end
writematrix(X2', 'sorties/newton_50_m20.csv');
fprintf('x < 0 ? %s ; any(x < 0) = %d\n', mat2str((x2 < 0)'), any(x2 < 0));
disp('depart (50, -20) : le premier pas arrive en'); disp(X2(:, 2)');
disp('depart singulier (40, -10) : JF = '); disp(JF([40; -10])); fprintf('det = %g\n', det(JF([40; -10])));
% la carte : quelle racine Newton atteint-il depuis chaque point du plan ?
q1 = 0:1:70;  q2 = -40:1:40;
bassin = zeros(length(q2), length(q1));
warning('off', 'all');
for a = 1:length(q1)
  for b = 1:length(q2)
    [xr, kr] = newton_systeme(F, JF, [q1(a); q2(b)], 1e-9, 60);
    if kr < 60 && norm(xr - [20; 10]) < 1e-6, bassin(b, a) = 1;
    elseif kr < 60 && norm(xr - [60; -30]) < 1e-6, bassin(b, a) = 2;
    end
  end
end
warning('on', 'all');
writematrix(bassin, 'sorties/bassins.csv');
fprintf('carte des bassins (%d x %d points de depart) : racine physique %d, racine negative %d, aucune %d\n', ...
    numel(q1), numel(q2), nnz(bassin == 1), nnz(bassin == 2), nnz(bassin == 0));
% prevision : le premier pas tombe sur la droite Q1 + Q2 = 30 en  Q1' = (Q1^2 - 4 Q2^2 + 240 Q2) / (2 Q1 + 8 Q2) ;
% la racine atteinte est 20 si Q1' < 40, 60 si Q1' > 40 (parabole symetrique autour de 40)
[QQ1, QQ2] = meshgrid(q1, q2);
Qp = (QQ1.^2 - 4*QQ2.^2 + 240*QQ2) ./ (2*QQ1 + 8*QQ2);
prevu = zeros(size(Qp));  prevu(Qp < 40) = 1;  prevu(Qp > 40) = 2;
ok = isfinite(Qp);
fprintf('prevision par la formule du premier pas : %d points mal classes sur %d\n', nnz(bassin(ok) ~= prevu(ok)), nnz(ok));
fprintf('depart (15,15) : racine %d ; depart (50,-20) : racine %d ; depart (0,0) : %d\n', bassin(q2 == 15, q1 == 15), bassin(q2 == -20, q1 == 50), bassin(q2 == 0, q1 == 0));
% la frontiere : pour l'essentiel la droite ou la jacobienne est singuliere, det(JF) = -4 (Q1 + 4 Q2) = 0
sgn = QQ1 + 4*QQ2;
pred2 = zeros(size(sgn));  pred2(sgn > 0) = 1;  pred2(sgn < 0) = 2;
masque = QQ1 >= 6 & sgn ~= 0;
fprintf('droite Q1 + 4 Q2 = 0 (det JF = 0) : au-dessus racine (20,10), au-dessous racine (60,-30) : %d points mal classes sur %d (Q1 >= 6)\n', ...
    nnz(bassin(masque) ~= pred2(masque)), nnz(masque));
positifs = QQ1 >= 0 & QQ2 >= 0 & ~(QQ1 == 0 & QQ2 == 0);
fprintf('departs a debits positifs (Q1 >= 0, Q2 >= 0, hors (0,0)) : %d sur %d menent a la racine physique\n', nnz(bassin(positifs) == 1), nnz(positifs));
fprintf('det(JF) en (15,15) = %g ; en (50,-20) = %g ; en (40,-10) = %g ; JF singuliere sur la droite Q1 + 4 Q2 = 0 qui passe par (40,-10)\n', det(JF([15; 15])), det(JF([50; -20])), det(JF([40; -10])));
% la regle pratique : partir d'un partage egal du debit total, puis controler le signe de la solution
n = 2;
x0 = (Qtot / n) * ones(n, 1);
[x, k] = newton_systeme(F, JF, x0, tol, nmax);
if any(x < 0), warning('Debit negatif.'); end
fprintf('depart Qtot/n = %s : x = %s, k = %d, any(x < 0) = %d\n', mat2str(x0'), mat2str(x', 6), k, any(x < 0));
figure('Visible', 'off');
imagesc(q1, q2, bassin);  axis xy;  colormap([0.8 0.8 0.8; 0.4 0.6 0.9; 0.95 0.6 0.3]);
xlabel('Q_1');  ylabel('Q_2');  title('racine atteinte par Newton (1 = (20,10), 2 = (60,-30))');
saveas(gcf, 'sorties/bassins.png');

%% 5) Manipulation 3 : trois conduites, par la fonction pompage
disp('=== 5) Manipulation 3 : trois conduites');
R = [2 8 4];
[F3, JF3] = pompage(R, 30);
x0 = (30/3) * ones(3, 1);
F30 = F3(x0)
JF30 = JF3(x0)
[x3, k3, X3] = newton_systeme(F3, JF3, x0, tol, nmax);
x3
k3
fprintf('%2s %11s %11s %11s %11s\n', 'k', 'Q1', 'Q2', 'Q3', '||F||');
for j = 0:k3
  fprintf('%2d %11.6f %11.6f %11.6f %11.3e\n', j, X3(1, j+1), X3(2, j+1), X3(3, j+1), norm(F3(X3(:, j+1))));
end
xform = 30 * (1 ./ sqrt(R)) / sum(1 ./ sqrt(R));
fprintf('formule Qi = Qtot*(1/sqrt(Ri))/somme : %s ; ecart avec Newton = %.2e\n', mat2str(xform, 6), norm(x3' - xform));
fprintf('Q1 + Q2 + Q3 = %.6f ; R1*Q1^2 = %.4f, R2*Q2^2 = %.4f, R3*Q3^2 = %.4f\n', sum(x3), R(1)*x3(1)^2, R(2)*x3(2)^2, R(3)*x3(3)^2);
[~, ordre] = sort(x3, 'descend');
fprintf('ordre des debits (du plus grand au plus petit) : conduites %s ; resistances %s\n', mat2str(ordre'), mat2str(R(ordre)));
fprintf('4 conduites, R = [2 8 4 1] : ');
[F4, JF4] = pompage([2 8 4 1], 30);
[x4, k4] = newton_systeme(F4, JF4, 7.5*ones(4, 1), tol, nmax);
fprintf('x = %s, k = %d\n', mat2str(x4', 6), k4);

%% 6) Manipulation 4 : la descente de gradient
disp('=== 6) Manipulation 4 : descente de gradient');
gradG = @(x) JF(x)' * F(x);
g0 = gradG([15; 15]);
fprintf('gradient en (15,15) : %s, norme = %.4e ; G = %.1f\n', mat2str(g0', 8), norm(g0), 0.5 * norm(F([15; 15]))^2);
fprintf('cond(JF''*JF) en (15,15) = %.3g ; a la solution = %.3g\n', cond(JF([15; 15])' * JF([15; 15])), cond(JF(xex)' * JF(xex)));
alpha = 3e-5;  tolg = 1e-6;
xg = [15; 15];
fprintf('alpha = 3e-5, premier pas : %s\n', mat2str((xg - alpha * gradG(xg))', 6));
warning('off', 'all');
[xg, kg] = descente_gradient(F, JF, [15; 15], alpha, tolg, 500000);
warning('on', 'all');
xg
kg
fprintf('Newton : %d iterations ; descente de gradient : %d iterations (rapport %.0f)\n', k, kg, kg / k);
% quelques points de la trajectoire (alpha = 3e-5)
cibles = [1 2 3 5 10 100 1000 5000 10000 20000 50000 100000 200000 295000];
fprintf('k, x(k) : \n');
xt = [15; 15];  pas = 0;  traj = [0 xt'];
for kk = 1:max(cibles)
  xt = xt - alpha * gradG(xt);
  if ismember(kk, cibles), fprintf('  k = %6d : (%.4f, %.4f)\n', kk, xt(1), xt(2)); end
  if kk <= 10 || mod(kk, 1000) == 0, traj(end+1, :) = [kk xt']; end %#ok<SAGROW>
end
writematrix(traj, 'sorties/gradient_3e5.csv');
% alpha = 5e-5 : le cycle
alpha2 = 5e-5;
xt = [15; 15];
fprintf('alpha = 5e-5, premier pas : %s\n', mat2str((xt - alpha2 * gradG(xt))', 6));
traj2 = [0 xt'];
cib2 = [1:12, 20 50 100 500 1000 2000 5000 10000 20000 50000 100000 200000 499999 500000];
for kk = 1:500000
  xt = xt - alpha2 * gradG(xt);
  if ismember(kk, cib2), traj2(end+1, :) = [kk xt']; end %#ok<SAGROW>
  if ismember(kk, cib2(13:end)), fprintf('  alpha = 5e-5, k = %6d : (%.4f, %.4f), ||F|| = %.4f\n', kk, xt(1), xt(2), norm(F(xt))); end
  if kk == 499999, xa = xt; end
end
fprintf('alpha = 5e-5, apres 499999 iterations : (%.6f, %.6f) ; apres 500000 : (%.6f, %.6f)\n', xa(1), xa(2), xt(1), xt(2));
fprintf('||F|| = %.4f (en 499999) et %.4f (en 500000) ; Q1 + Q2 = %.4f\n', norm(F(xa)), norm(F(xt)), xt(1) + xt(2));
writematrix(traj2, 'sorties/gradient_5e5.csv');
for aa = [4.5e-5 4.8e-5 1e-3]
  warning('off', 'all');
  [xa2, ka2] = descente_gradient(F, JF, [15; 15], aa, tolg, 500000);
  warning('on', 'all');
  fprintf('alpha = %.1e : %d iterations, x = (%.4f, %.4f), ||F|| = %.4e\n', aa, ka2, xa2(1), xa2(2), norm(F(xa2)));
end
xt = [15; 15];
fprintf('alpha = 1e-3, premieres iterations :\n');
for kk = 1:3
  xt = xt - 1e-3 * gradG(xt);
  fprintf('  k = %d : x = (%.4g, %.4g), ||grad G|| = %.3g\n', kk, xt(1), xt(2), norm(gradG(xt)));
end

%% 7) Mesurer, verifier, deboguer
disp('=== 7) deboguer');
x = [15; 15];
Jfd = jacobienne_fd(F, x)
fprintf('norm(JF(x) - jacobienne_fd(F, x)) = %.2e\n', norm(JF(x) - Jfd));
JFfaux = @(x) [1, 1; R1*x(1), -R2*x(2)];
fprintf('avec le facteur 2 oublie : norm(JFfaux(x) - jacobienne_fd(F, x)) = %.2e\n', norm(JFfaux(x) - Jfd));
JFfd = @(x) jacobienne_fd(F, x);
[xfd, kfd, Xfd] = newton_systeme(F, JFfd, [15; 15], tol, nmax);
fprintf('Newton avec jacobienne_fd : k = %d, x = (%.10f, %.10f)\n', kfd, xfd(1), xfd(2));
efd = vecnorm(Xfd - xex);
fprintf('erreurs avec jacobienne_fd : '); fprintf('%.3e ', efd(1:5)); fprintf('\n');
fprintf('erreurs avec JF exacte      : '); fprintf('%.3e ', e(1:5)); fprintf('\n');
disp('--- piege 1 : facteur 2 oublie dans la jacobienne');
warning('off', 'all');
[xf, kf, Xf] = newton_systeme(F, JFfaux, [15; 15], tol, 200);
warning('on', 'all');
fprintf('k = %d ; x(%d) = %s ; x(%d) = %s ; x(%d) = %s\n', kf, 0, mat2str(Xf(:, 1)'), 1, mat2str(Xf(:, 2)'), 2, mat2str(Xf(:, 3)'));
fprintf('x(199) = %s ; x(200) = %s\n', mat2str(Xf(:, 200)'), mat2str(Xf(:, 201)'));
disp('--- piege 2 : signe oublie');
warning('off', 'all');
[xsg, ksg, Xsg] = newton_signe_faux(F, JF, [15; 15], tol, 20);
warning('on', 'all');
for j = 0:5
  fprintf('  k = %d : x = (%.4f, %.4f), ||F|| = %.4e\n', j, Xsg(1, j+1), Xsg(2, j+1), norm(F(Xsg(:, j+1))));
end
fprintf('apres %d iterations : ||F|| = %.3e\n', ksg, norm(F(Xsg(:, end))));
disp('--- piege 3 : depart singulier (0, 0)');
lastwarn('');
warning('off', 'MATLAB:nearlySingularMatrix');
[x0s, k0s, X0s] = newton_systeme(F, JF, [0; 0], tol, 5);
warning('on', 'MATLAB:nearlySingularMatrix');
[msg, id] = lastwarn;
fprintf('x apres 5 iterations = %s ; dernier warning : %s\n', mat2str(x0s'), msg);
fprintf('JF(0,0) = %s, det = %g\n', mat2str(JF([0; 0])), det(JF([0; 0])));
disp('--- piege 4 : parametre capture a la creation de la fonction');
R2 = 4;
xc = newton_systeme(F, JF, [15; 15], tol, nmax);
fprintf('apres R2 = 4, SANS recreer F : x = (%.6f, %.6f)\n', xc(1), xc(2));
[Fn, JFn] = pompage([2 4], 30);
[xn, kn] = newton_systeme(Fn, JFn, [15; 15], tol, nmax);
fprintf('avec F recree, R2 = 4 : x = (%.6f, %.6f), k = %d ; formule Qtot/(1 + sqrt(R1/R2)) = %.6f\n', xn(1), xn(2), kn, 30/(1 + sqrt(2/4)));
R2 = 8;
disp('--- depart donne en ligne : x0(:) le remet en colonne');
[xl, kl] = newton_systeme(F, JF, [15, 15], tol, nmax);
fprintf('newton_systeme(F, JF, [15, 15], ...) : x = %s, k = %d (meme resultat)\n', mat2str(xl', 6), kl);
[F3b, JF3b] = pompage([2 8 4], 30);
xl3 = newton_systeme(F3b, JF3b, [10, 10, 10], tol, nmax);
fprintf('trois conduites, depart en ligne [10, 10, 10] : x = %s\n', mat2str(xl3', 6));
diary off;
