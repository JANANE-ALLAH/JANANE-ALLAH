function [x, k, X] = newton_systeme(F, JF, x0, tol, nmax)
% NEWTON_SYSTEME  Methode de Newton-Raphson multivariee pour F(x) = 0.
%   Chaque iteration resout le systeme LINEAIRE  JF(x) * delta = -F(x), puis pose x = x + delta.
%   Arret quand ||delta|| < tol ; k = nombre d'iterations effectuees.
%   X(:, j+1) = x^(j) : toutes les iterees, de x^(0) a x^(k).
  x = x0(:);
  X = zeros(length(x), nmax + 1);
  X(:, 1) = x;
  for k = 1:nmax
    delta = -JF(x) \ F(x);
    x = x + delta;
    X(:, k + 1) = x;
    if norm(delta) < tol, break; end
  end
  if ~(norm(delta) < tol)
    warning('Pas de convergence.');
  end
  X = X(:, 1:k + 1);
end
