function [x, k, X] = newton_signe_faux(F, JF, x0, tol, nmax)
% NEWTON_SIGNE_FAUX  Le bug du signe : on resout JF(x)*delta = +F(x) au lieu de -F(x).
%   Aucune erreur de syntaxe : le programme tourne, mais x s'eloigne de la solution a chaque iteration.
%   Seul le warning 'Pas de convergence.' (ou une inspection de ||F||) trahit l'oubli.
  x = x0(:);
  X = zeros(length(x), nmax + 1);
  X(:, 1) = x;
  for k = 1:nmax
    delta = JF(x) \ F(x);
    x = x + delta;
    X(:, k + 1) = x;
    if norm(delta) < tol, break; end
  end
  if ~(norm(delta) < tol)
    warning('Pas de convergence.');
  end
  X = X(:, 1:k + 1);
end
