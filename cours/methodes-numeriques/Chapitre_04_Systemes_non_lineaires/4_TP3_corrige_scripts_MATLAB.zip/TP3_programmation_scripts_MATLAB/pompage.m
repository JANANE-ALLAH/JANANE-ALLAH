function [F, JF] = pompage(R, Qtot)
% POMPAGE  Systeme de pompage (TP3) : n conduites en parallele, debit total Qtot.
%   Equations : conservation du debit, puis meme perte de charge  R(1)*Q1^2 = R(i)*Qi^2  (i = 2..n).
%   Rend deux fonctions : F(x) = residu (n x 1) et JF(x) = sa jacobienne (n x n) ; x est un vecteur COLONNE.
  R = R(:);
  n = length(R);
  r = R(2:n);
  F  = @(x) [sum(x) - Qtot; R(1)*x(1)^2 - r .* x(2:n).^2];
  JF = @(x) jacobienne_pompage(x, R);
end

function J = jacobienne_pompage(x, R)
% Jacobienne, par blocs : premiere ligne de uns (conservation du debit), premiere colonne 2*R1*Q1,
% puis une diagonale -2*Ri*Qi (la perte de charge de la conduite i ne depend que de Q1 et de Qi).
  n = length(R);
  J = zeros(n);
  J(1, :) = 1;
  J(2:n, 1) = 2*R(1)*x(1);
  J(2:n, 2:n) = -2*diag(R(2:n) .* x(2:n));
end
