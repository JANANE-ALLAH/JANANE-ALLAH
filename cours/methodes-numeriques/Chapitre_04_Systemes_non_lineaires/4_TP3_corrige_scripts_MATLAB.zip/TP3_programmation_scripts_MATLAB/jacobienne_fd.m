function J = jacobienne_fd(F, x)
% JACOBIENNE_FD  Jacobienne de F en x par differences finies centrees, colonne par colonne.
%   La colonne j est  (F(x + h*ej) - F(x - h*ej)) / (2*h) : on fait varier UNE seule inconnue a la fois.
%   Sert a TESTER une jacobienne ecrite a la main, ou a la remplacer quand elle est trop penible a deriver.
  x = x(:);
  n = length(x);
  J = zeros(length(F(x)), n);
  for j = 1:n
    h = 1e-6 * max(1, abs(x(j)));
    e = zeros(n, 1);
    e(j) = h;
    J(:, j) = (F(x + e) - F(x - e)) / (2*h);
  end
end
