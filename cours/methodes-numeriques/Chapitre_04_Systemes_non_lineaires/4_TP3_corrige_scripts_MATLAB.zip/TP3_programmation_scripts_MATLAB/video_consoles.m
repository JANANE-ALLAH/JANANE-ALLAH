%% video_consoles.m
% Les " fenetres de commandes " de la video : chaque commande est rejouee telle qu'elle apparait a l'ecran,
% avec les memes noms de variables, et sa sortie est celle de MATLAB.
% Les lignes vides de MATLAB et les en-tetes " ### " ne sont pas affiches dans la video.
% Lancement (depuis ce dossier) :  matlab -batch "video_consoles"      (sortie : sorties/video_consoles.txt)
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_consoles.txt', 'file'), delete('sorties/video_consoles.txt'); end
diary('sorties/video_consoles.txt');
warning('off', 'backtrace');

disp('### 2b) F et JF');
R1 = 2;  R2 = 8;  Qtot = 30;
F  = @(x) [x(1) + x(2) - Qtot; R1*x(1)^2 - R2*x(2)^2];
JF = @(x) [1, 1; 2*R1*x(1), -2*R2*x(2)];
disp('>> x = [15; 15];'); x = [15; 15];
disp('>> F(x)'); F(x)
disp('>> JF(x)'); JF(x)

disp('### 2c) un pas de Newton');
disp('>> delta = -JF(x) \ F(x)'); delta = -JF(x) \ F(x)
disp('>> x = x + delta'); x = x + delta
disp('>> F(x)'); F(x)

disp('### 2d) le test avec NaN');
disp('>> double([NaN < 1e-10, NaN >= 1e-10, ~(NaN < 1e-10)])'); double([NaN < 1e-10, NaN >= 1e-10, ~(NaN < 1e-10)])

disp('### 2e) newton_systeme');
disp('>> [x, k, X] = newton_systeme(F, JF, [15; 15], 1e-10, 20);');
[x, k, X] = newton_systeme(F, JF, [15; 15], 1e-10, 20);
disp('>> x'''); x'
disp('>> k'); k
disp('>> size(X)'); size(X)

disp('### 3a) l''erreur et le rapport');
disp('>> format short e');  format short e
disp('>> xex = [20; 10];'); xex = [20; 10];
disp('>> e = vecnorm(X - xex)'''); e = vecnorm(X - xex)'
disp('>> rap = e(2:end) ./ e(1:end-1).^2'); rap = e(2:end) ./ e(1:end-1).^2
disp('### 3c) la pente');
disp('>> p = polyfit(log(e(2:4)), log(e(3:5)), 1)'); p = polyfit(log(e(2:4)), log(e(3:5)), 1)
disp('>> C = exp(p(2))'); C = exp(p(2))
format short;

disp('### 4a) depart (50, -20)');
disp('>> [x2, k2] = newton_systeme(F, JF, [50; -20], 1e-10, 20);');
[x2, k2] = newton_systeme(F, JF, [50; -20], 1e-10, 20);
disp('>> x2'''); x2'
disp('>> k2'); k2
disp('>> F([60; -30])'''); F([60; -30])'
disp('>> any(x2 < 0)'); any(x2 < 0)

disp('### 5b) trois conduites');
disp('>> R = [2 8 4];'); R = [2 8 4];
disp('>> [F3, JF3] = pompage(R, 30);'); [F3, JF3] = pompage(R, 30);
disp('>> x0 = (30/3) * ones(3, 1);'); x0 = (30/3) * ones(3, 1);
disp('>> F3(x0)'); F3(x0)
disp('>> JF3(x0)'); JF3(x0)
disp('>> [x, k] = newton_systeme(F3, JF3, x0, 1e-10, 20);'); [x, k] = newton_systeme(F3, JF3, x0, 1e-10, 20);
disp('>> x'''); x'
disp('>> k'); k
disp('>> 30 * (1./sqrt(R)) / sum(1./sqrt(R))'); 30 * (1./sqrt(R)) / sum(1./sqrt(R))

disp('### 6) descente de gradient');
disp('>> x0 = [15; 15];'); x0 = [15; 15];
disp('>> [xg, kg] = descente_gradient(F, JF, x0, 3e-5, 1e-6, 5e5);');
[xg, kg] = descente_gradient(F, JF, x0, 3e-5, 1e-6, 5e5);
disp('>> xg'''); xg'
disp('>> kg'); kg
disp('>> [xg, kg] = descente_gradient(F, JF, x0, 5e-5, 1e-6, 5e5);');
[xg, kg] = descente_gradient(F, JF, x0, 5e-5, 1e-6, 5e5);
disp('>> xg'''); xg'
disp('>> norm(F(xg))'); norm(F(xg))

disp('### 7a) tester la jacobienne');
format short e;
disp('>> x = [15; 15];'); x = [15; 15];
disp('>> norm(JF(x) - jacobienne_fd(F, x))'); norm(JF(x) - jacobienne_fd(F, x))
disp('>> JFfaux = @(x) [1, 1; R1*x(1), -R2*x(2)];'); JFfaux = @(x) [1, 1; R1*x(1), -R2*x(2)];
disp('>> norm(JFfaux(x) - jacobienne_fd(F, x))'); norm(JFfaux(x) - jacobienne_fd(F, x))
format short;

disp('### 7b) piege 1 : facteur 2 oublie');
disp('>> [xf, kf, Xf] = newton_systeme(F, JFfaux, [15; 15], 1e-10, 200);');
[xf, kf, Xf] = newton_systeme(F, JFfaux, [15; 15], 1e-10, 200);
disp('>> Xf(:, 1:4)'''); Xf(:, 1:4)'

disp('### 7c) piege 2 : signe oublie');
disp('>> [xs, ks, Xs] = newton_signe_faux(F, JF, [15; 15], 1e-10, 20);');
[xs, ks, Xs] = newton_signe_faux(F, JF, [15; 15], 1e-10, 20);
format short e;
disp('>> norm(F(Xs(:, 3)))'); norm(F(Xs(:, 3)))
disp('>> norm(F(Xs(:, end)))'); norm(F(Xs(:, end)))
format short;

disp('### 7d) piege 3 : depart singulier');
disp('>> xz = newton_systeme(F, JF, [0; 0], 1e-10, 5);');
warning('off', 'MATLAB:nearlySingularMatrix');
xz = newton_systeme(F, JF, [0; 0], 1e-10, 5);
warning('on', 'MATLAB:nearlySingularMatrix');
disp('>> xz'''); xz'

disp('### 7e) piege 4 : parametre capture');
disp('>> R2 = 4;'); R2 = 4;
disp('>> x = newton_systeme(F, JF, [15; 15], 1e-10, 20);'); x = newton_systeme(F, JF, [15; 15], 1e-10, 20);
disp('>> x'''); x'
disp('>> [F, JF] = pompage([2 4], 30);'); [F, JF] = pompage([2 4], 30);
disp('>> x = newton_systeme(F, JF, [15; 15], 1e-10, 20);'); x = newton_systeme(F, JF, [15; 15], 1e-10, 20);
disp('>> x'''); x'
diary off;
