%% video_essais.m
% TP5 -- video "programmer Poisson 2D sous MATLAB" (salle de sport, chapitre 9).
% Tous les nombres et toutes les sorties affichees dans la video viennent de ce script.
% Lancement (depuis ce dossier) :  matlab -batch "video_essais"      (sortie : sorties/video_essais.txt)
% Les fonctions poisson2d, poisson2d_isole, poisson2d_isole_faux et sor sont dans ce dossier.
% Duree : environ 20 secondes.
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_essais.txt', 'file'), delete('sorties/video_essais.txt'); end
diary('sorties/video_essais.txt');

%% 0) La salle et son maillage
disp('=== 0) la salle de sport et son maillage');
Lx = 4;  Ly = 3;  Nx = 8;  Ny = 6;
hx = Lx / Nx;  hy = Ly / Ny;
bc = [25 10 10 10];                      % gauche (mur chauffant), droite, bas, haut
nx = Nx - 1;  ny = Ny - 1;  n = nx * ny;
idx = @(i, j) (j - 1) * nx + i;
fprintf('hx = %g m, hy = %g m ; noeuds interieurs : %d x %d = %d inconnues\n', hx, hy, nx, ny, n);
fprintf('idx(1,1) = %d ; idx(7,1) = %d ; idx(1,2) = %d ; idx(2,2) = %d ; idx(7,5) = %d\n', ...
    idx(1,1), idx(7,1), idx(1,2), idx(2,2), idx(7,5));
fprintf('coefficients : 1/hx^2 = %g ; diagonale 2/hx^2 + 2/hy^2 = %g\n', 1/hx^2, 2/hx^2 + 2/hy^2);

%% 1) Assemblage
disp('=== 1) assemblage de A et de b (cas de base)');
[A, b] = poisson2d(Nx, Ny, hx, hy, bc);
fprintf('size(A) = %d x %d ; nnz(A) = %d sur %d (%.1f %%)\n', size(A, 1), size(A, 2), nnz(A), n^2, 100*nnz(A)/n^2);
fprintf('ligne k = 1 (coin bas gauche)   : A(1,1) = %g, A(1,2) = %g, A(1,8) = %g ; b(1) = %g\n', full(A(1,1)), full(A(1,2)), full(A(1,8)), b(1));
fprintf('ligne k = 2 (mur du bas)        : b(2) = %g\n', b(2));
fprintf('ligne k = 8 (mur de gauche)     : b(8) = %g\n', b(8));
fprintf('ligne k = idx(2,2) = 9 (interieur) : b(9) = %g ; 5 coefficients non nuls : %s\n', b(9), mat2str(full(A(9, [1 8 9 10 17])), 4));
fprintf('valeurs de b distinctes : %s\n', mat2str(unique(b)', 6));
fprintf('symetrie : norm(A - A'', 1) = %g ; plus petite valeur propre = %.4f ; plus grande = %.4f ; cond(A) = %.2f\n', ...
    norm(A - A', 1), min(eig(full(A))), max(eig(full(A))), cond(full(A)));

%% 2) Resolution et principe du maximum
disp('=== 2) resolution T = A \ b');
T = A \ b;
fprintf('T min = %.4f C ; T max = %.4f C ; moyenne = %.4f C\n', min(T), max(T), mean(T));
fprintf('residu norm(A*T - b) = %.3e\n', norm(A*T - b));
fprintf('principe du maximum : tous les T dans [10, 25] ? %d\n', all(T >= 10 & T <= 25));
Tgrille = reshape(T, nx, ny)';
disp('Tgrille = reshape(T, nx, ny)'' (ligne 1 = y = hy, le bas de la salle) :');
disp(Tgrille);
fprintf('T au centre de la salle, noeud (4, 3) : %.4f C ; noeud (1, 3) pres du radiateur : %.4f C ; noeud (7, 3) : %.4f C\n', ...
    Tgrille(3, 4), Tgrille(3, 1), Tgrille(3, 7));
csvwrite('sorties/tgrille.csv', Tgrille);
[Ip, Jp] = find(A);
csvwrite('sorties/motif.csv', [Ip Jp]);
Tfaux = reshape(T, ny, nx);
fprintf('piege reshape(T, ny, nx) : Tfaux(1, 1) = %.4f contre %.4f ; Tfaux(1, 7) = %.4f contre %.4f\n', ...
    Tfaux(1, 1), Tgrille(1, 1), Tfaux(1, 7), Tgrille(1, 7));
fprintf('donnees : max |Tfaux - Tgrille| = %.4f C\n', max(max(abs(Tfaux - Tgrille))));

%% 3) Solution manufacturee et ordre 2
disp('=== 3) solution manufacturee u = (x^2-1)^2 (y^2-1)^2 sur [-1, 1]^2');
uex  = @(x, y) (x.^2 - 1).^2 .* (y.^2 - 1).^2;
fman = @(x, y) (12*x.^2 - 4) .* (y.^2 - 1).^2 + (x.^2 - 1).^2 .* (12*y.^2 - 4);
fprintf('u sur le bord : u(-1, 0.3) = %g ; u(1, -0.7) = %g ; u(0.2, 1) = %g ; u(-0.5, -1) = %g\n', ...
    uex(-1, 0.3), uex(1, -0.7), uex(0.2, 1), uex(-0.5, -1));
Ns = [10 20 40 80];
errs = arrayfun(@erreur_manufacturee, Ns);
for m = 1:length(Ns)
  fprintf('N = %2d : h = %.4f ; %5d inconnues ; erreur max = %.4e\n', Ns(m), 2/Ns(m), (Ns(m)-1)^2, errs(m));
end
rap = errs(1:end-1) ./ errs(2:end);
fprintf('rapports err(N)/err(2N) : %s\n', mat2str(rap, 5));
p = polyfit(log(2 ./ Ns), log(errs), 1);
fprintf('pente log-log : %.4f ; constante C = %.4f (err ~ C h^p)\n', p(1), exp(p(2)));
fprintf('erreur en ordre 1 pour comparaison : err(10) ~ %.2e\n', errs(1));
csvwrite('sorties/erreurs.csv', [Ns' (2 ./ Ns)' errs']);

%% 4) Mur du bas isole (Neumann)
disp('=== 4) mur du bas isole (Neumann homogene)');
[A3, b3] = poisson2d_isole(Nx, Ny, hx, hy, bc);
T3 = A3 \ b3;
n3 = length(b3);
fprintf('inconnues : %d -> %d ; size(A3) = %d x %d ; nnz = %d\n', n, n3, size(A3, 1), size(A3, 2), nnz(A3));
fprintf('T min = %.4f C ; T max = %.4f C ; moyenne = %.4f C (cas de base : %.4f C)\n', min(T3), max(T3), mean(T3), mean(T));
fprintf('ecart des moyennes : %.4f C\n', mean(T3) - mean(T));
T3grille = reshape(T3, nx, Ny)';
disp('T3grille (ligne 1 = le mur du bas, devenu inconnu) :');
disp(T3grille);
fprintf('temperature du mur du bas (isole) : de %.4f a %.4f C ; au milieu %.4f C\n', min(T3grille(1,:)), max(T3grille(1,:)), T3grille(1,4));
fprintf('symetrie : norm(A3 - A3'', 1) = %g\n', norm(A3 - A3', 1));
fprintf('valeurs propres de A3 : %.4f a %.4f (toutes reelles et positives : %d)\n', min(real(eig(full(A3)))), max(real(eig(full(A3)))), ...
    all(abs(imag(eig(full(A3)))) < 1e-10) && all(real(eig(full(A3))) > 0));
fprintf('principe du maximum : T dans [10, 25] ? %d ; T3 >= T partout sur les noeuds communs ? %d\n', ...
    all(T3 >= 10 & T3 <= 25), all(all(T3grille(2:end, :) >= Tgrille - 1e-12)));
csvwrite('sorties/t3grille.csv', T3grille);
[Af, bf] = poisson2d_isole_faux(Nx, Ny, hx, hy, bc);
Tf = Af \ bf;
fprintf('piege (doublement sur la mauvaise rangee) : %d inconnues ; T min = %.4f ; T max = %.4f ; moyenne = %.4f C\n', ...
    length(bf), min(Tf), max(Tf), mean(Tf));
fprintf('vraie moyenne du mur isole : %.4f C ; moyenne du piege : %.4f C ; ecart %.4f C\n', mean(T3), mean(Tf), mean(Tf) - mean(T3));
% ordre de la condition de Neumann : u = cos(pi*y/2)*sin(pi*x) sur [0, 1]^2, u_y = 0 sur y = 0, u = 0 ailleurs
disp('--- ordre de la condition de Neumann (u = cos(pi y/2) sin(pi x), mur du bas isole)');
uN = @(x, y) cos(pi*y/2) .* sin(pi*x);
for N = [8 16 32 64]
  hh = 1 / N;
  gN  = @(i, j) (5*pi^2/4) * uN(i*hh, (j-1)*hh);
  gNf = @(i, j) (5*pi^2/4) * uN(i*hh, j*hh);
  [Ai, bi] = poisson2d_isole(N, N, hh, hh, [0 0 0 0], gN);
  Ti = Ai \ bi;
  [X, Y] = meshgrid(hh*(1:N-1), hh*(0:N-1));
  e1 = max(abs(Ti - reshape(uN(X, Y)', [], 1)));
  [Aj, bj] = poisson2d_isole_faux(N, N, hh, hh, [0 0 0 0], gNf);
  Tj = Aj \ bj;
  [X, Y] = meshgrid(hh*(1:N-1), hh*(1:N-1));
  e2 = max(abs(Tj - reshape(uN(X, Y)', [], 1)));
  fprintf('N = %2d : erreur noeud fictif sur le mur = %.3e ; erreur doublement sur la mauvaise rangee = %.3e\n', N, e1, e2);
  eN(N == [8 16 32 64]) = e1;  eF(N == [8 16 32 64]) = e2;
end
fprintf('rapports (noeud fictif sur le mur) : %s\n', mat2str(eN(1:3) ./ eN(2:4), 4));
fprintf('rapports (mauvaise rangee)         : %s\n', mat2str(eF(1:3) ./ eF(2:4), 4));

%% 5) Direct contre iteratif
disp('=== 5) resolution directe contre SOR');
w = 1.5;  tol = 1e-8;  nmax = 2000;
[xs, ks] = sor(A, b, w, tol, nmax);
fprintf('SOR (w = %g, tol = %g) : %d balayages ; erreur par rapport a A\\b = %.3e\n', w, tol, ks, max(abs(xs - T)));
[xg, kg] = sor(A, b, 1, tol, nmax);
fprintf('Gauss-Seidel (w = 1) : %d balayages ; erreur par rapport a A\\b = %.3e\n', kg, max(abs(xg - T)));
Ap = full(A);  D = diag(diag(Ap));
BJ = -D \ (Ap - D);
rhoJ = max(abs(eig(BJ)));
rhoJ_formule = (cos(pi/Nx) + cos(pi/Ny)) / 2;
wopt = 2 / (1 + sqrt(1 - rhoJ^2));
fprintf('rayon spectral de Jacobi : %.6f (formule (cos(pi/Nx) + cos(pi/Ny))/2 = %.6f)\n', rhoJ, rhoJ_formule);
fprintf('omega optimal 2/(1 + sqrt(1 - rho^2)) = %.4f\n', wopt);
ws = 1.0:0.1:1.9;
its = zeros(size(ws));
for m = 1:length(ws)
  [~, its(m)] = sor(A, b, ws(m), tol, nmax);
end
[~, mmin] = min(its);
fprintf('balayage de omega (pas 0,1) : %s\n', mat2str([ws; its], 4));
fprintf('meilleur omega du balayage : %.1f avec %d balayages\n', ws(mmin), its(mmin));
[~, kopt] = sor(A, b, wopt, tol, nmax);
fprintf('avec omega optimal %.4f : %d balayages\n', wopt, kopt);
[~, kj] = sor(A, b, 0.5, tol, nmax);
csvwrite('sorties/omega.csv', [ws' its']);

fprintf('A\\b : %d inconnues, residu %.2e ; SOR : residu %.2e\n', n, norm(A*T - b), norm(A*xs - b));
diary off;
