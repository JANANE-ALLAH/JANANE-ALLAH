function [A, b] = poisson2d_isole(Nx, Ny, hx, hy, bc, g)
% POISSON2D_ISOLE  Comme poisson2d, mais le mur du BAS est isole (Neumann homogene dT/dn = 0).
%   La rangee j = 1 (y = 0) n'est plus donnee : elle devient une rangee d'INCONNUES (nx*Ny inconnues).
%   Noeud fictif sous le mur : T(i, -1) = T(i, 1), donc le coefficient du voisin du dessus est DOUBLE.
%   bc = [gauche droite (inutilise) haut].
  if nargin < 6, g = @(i, j) 0; end
  nx = Nx - 1;  ny = Ny;
  n = nx * ny;
  idx = @(i, j) (j - 1) * nx + i;
  ax = 1 / hx^2;  ay = 1 / hy^2;
  A = spalloc(n, n, 5 * n);
  b = zeros(n, 1);
  for j = 1:ny
    for i = 1:nx
      k = idx(i, j);
      A(k, k) = 2*ax + 2*ay;
      b(k) = g(i, j);
      if i > 1,  A(k, idx(i-1, j)) = -ax; else, b(k) = b(k) + bc(1)*ax; end
      if i < nx, A(k, idx(i+1, j)) = -ax; else, b(k) = b(k) + bc(2)*ax; end
      if j == 1
        A(k, idx(i, j+1)) = -2*ay;
      else
        A(k, idx(i, j-1)) = -ay;
        if j < ny, A(k, idx(i, j+1)) = -ay; else, b(k) = b(k) + bc(4)*ay; end
      end
    end
  end
end
