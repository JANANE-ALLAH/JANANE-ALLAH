function [A, b] = poisson2d(Nx, Ny, hx, hy, bc, g)
% POISSON2D  Systeme lineaire de -(T_xx + T_yy) = g sur un rectangle, Dirichlet sur les quatre murs.
%   Nx, Ny : nombres de pas ; hx, hy : pas d'espace ; les inconnues sont les (Nx-1)*(Ny-1) noeuds interieurs.
%   bc = [gauche droite bas haut] : temperatures des murs.  g(i, j) : second membre au noeud (i, j), nul par defaut.
%   Numerotation : k = (j - 1)*nx + i  (on parcourt les lignes, de gauche a droite, de bas en haut).
  if nargin < 6, g = @(i, j) 0; end
  nx = Nx - 1;  ny = Ny - 1;
  n = nx * ny;
  idx = @(i, j) (j - 1) * nx + i;
  ax = 1 / hx^2;  ay = 1 / hy^2;
  A = spalloc(n, n, 5 * n);
  b = zeros(n, 1);
  for j = 1:ny
    for i = 1:nx
      k = idx(i, j);
      A(k, k) = 2*ax + 2*ay;
      b(k) = g(i, j);
      if i > 1,  A(k, idx(i-1, j)) = -ax; else, b(k) = b(k) + bc(1)*ax; end
      if i < nx, A(k, idx(i+1, j)) = -ax; else, b(k) = b(k) + bc(2)*ax; end
      if j > 1,  A(k, idx(i, j-1)) = -ay; else, b(k) = b(k) + bc(3)*ay; end
      if j < ny, A(k, idx(i, j+1)) = -ay; else, b(k) = b(k) + bc(4)*ay; end
    end
  end
end
