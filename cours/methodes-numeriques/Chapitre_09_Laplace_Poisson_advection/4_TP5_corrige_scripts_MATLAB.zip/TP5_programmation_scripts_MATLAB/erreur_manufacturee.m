function err = erreur_manufacturee(N)
% ERREUR_MANUFACTUREE  Erreur maximale sur le carre [-1, 1]^2 avec u = (x^2-1)^2 (y^2-1)^2 (Dirichlet nul).
%   On fabrique le second membre : -(u_xx + u_yy) = -f avec f = laplacien de u, puis on compare a u.
  uex  = @(x, y) (x.^2 - 1).^2 .* (y.^2 - 1).^2;
  fman = @(x, y) (12*x.^2 - 4) .* (y.^2 - 1).^2 + (x.^2 - 1).^2 .* (12*y.^2 - 4);
  h = 2 / N;
  xg = -1 + (1:N-1) * h;
  g = @(i, j) -fman(xg(i), xg(j));
  [A, b] = poisson2d(N, N, h, h, [0 0 0 0], g);
  T = A \ b;
  [X, Y] = meshgrid(xg, xg);
  err = max(abs(T - reshape(uex(X, Y), [], 1)));
end
