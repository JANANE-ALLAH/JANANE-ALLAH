%% video_consoles.m
% Les " fenetres de commandes " de la video : chaque commande est rejouee telle qu'elle apparait a l'ecran,
% avec les memes noms de variables, et sa sortie est celle de MATLAB.
% Les lignes vides de MATLAB et les en-tetes " ### " ne sont pas affiches dans la video.
% Lancement (depuis ce dossier) :  matlab -batch "video_consoles"      (sortie : sorties/video_consoles.txt)
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_consoles.txt', 'file'), delete('sorties/video_consoles.txt'); end
diary('sorties/video_consoles.txt');
warning('off', 'backtrace');

disp('### 1b) la numerotation');
disp('>> nx = 7;  ny = 5;'); nx = 7;  ny = 5;
disp('>> idx = @(i, j) (j - 1)*nx + i;'); idx = @(i, j) (j - 1)*nx + i;
disp('>> [idx(1,1)  idx(7,1)  idx(1,2)  idx(7,5)]'); [idx(1,1)  idx(7,1)  idx(1,2)  idx(7,5)]

disp('### 2b) assemblage du cas de base');
disp('>> bc = [25 10 10 10];'); bc = [25 10 10 10];
disp('>> [A, b] = poisson2d(8, 6, 0.5, 0.5, bc);'); [A, b] = poisson2d(8, 6, 0.5, 0.5, bc);
disp('>> size(A)'); size(A)
disp('>> nnz(A)'); nnz(A)
disp('>> full(A(1, [1 2 8]))'); full(A(1, [1 2 8]))
disp('>> b([1 2 8 9])'''); b([1 2 8 9])'
disp('>> full(A(9, [1 8 9 10 17]))'); full(A(9, [1 8 9 10 17]))
disp('>> norm(A - A'', 1)'); norm(A - A', 1)

disp('### 3a) resolution et principe du maximum');
disp('>> T = A \ b;'); T = A \ b;
disp('>> [min(T)  max(T)]'); [min(T)  max(T)]
disp('>> all(T >= 10 & T <= 25)'); all(T >= 10 & T <= 25)
disp('>> Tgrille = reshape(T, nx, ny)'''); Tgrille = reshape(T, nx, ny)'
disp('>> Tfaux = reshape(T, ny, nx);'); Tfaux = reshape(T, ny, nx);
disp('>> [Tfaux(1, 7)  Tgrille(1, 7)]'); [Tfaux(1, 7)  Tgrille(1, 7)]

disp('### 4a) solution manufacturee');
disp('>> Ns = [10 20 40 80];'); Ns = [10 20 40 80];
disp('>> format short e'); format short e
disp('>> err = arrayfun(@erreur_manufacturee, Ns)'); err = arrayfun(@erreur_manufacturee, Ns)
disp('>> format short'); format short
disp('>> rap = err(1:end-1) ./ err(2:end)'); rap = err(1:end-1) ./ err(2:end)
disp('>> p = polyfit(log(2 ./ Ns), log(err), 1)'); p = polyfit(log(2 ./ Ns), log(err), 1)

disp('### 5b) le mur du bas isole');
disp('>> [A3, b3] = poisson2d_isole(8, 6, 0.5, 0.5, bc);'); [A3, b3] = poisson2d_isole(8, 6, 0.5, 0.5, bc);
disp('>> size(A3)'); size(A3)
disp('>> T3 = A3 \ b3;'); T3 = A3 \ b3;
disp('>> [min(T3)  max(T3)  mean(T3)]'); [min(T3)  max(T3)  mean(T3)]
disp('>> mean(T)'); mean(T)
disp('>> norm(A3 - A3'', 1)'); norm(A3 - A3', 1)

disp('### 5d) le piege du doublement');
disp('>> [Af, bf] = poisson2d_isole_faux(8, 6, 0.5, 0.5, bc);'); [Af, bf] = poisson2d_isole_faux(8, 6, 0.5, 0.5, bc);
disp('>> size(Af)'); size(Af)
disp('>> Tf = Af \ bf;'); Tf = Af \ bf;
disp('>> [mean(Tf)  mean(T3)]'); [mean(Tf)  mean(T3)]

disp('### 6a) SOR contre l''operateur \');
disp('>> [xs, k] = sor(A, b, 1.5, 1e-8, 2000);'); [xs, k] = sor(A, b, 1.5, 1e-8, 2000);
disp('>> k'); k
disp('>> max(abs(xs - T))'); max(abs(xs - T))
disp('>> [xg, kgs] = sor(A, b, 1, 1e-8, 2000);'); [xg, kgs] = sor(A, b, 1, 1e-8, 2000);
disp('>> kgs'); kgs

disp('### 6b) omega optimal');
disp('>> Ap = full(A);  D = diag(diag(Ap));'); Ap = full(A);  D = diag(diag(Ap));
disp('>> BJ = -D \ (Ap - D);'); BJ = -D \ (Ap - D);
disp('>> rho = max(abs(eig(BJ)))'); rho = max(abs(eig(BJ)))
disp('>> wopt = 2 / (1 + sqrt(1 - rho^2))'); wopt = 2 / (1 + sqrt(1 - rho^2))
disp('>> [~, kopt] = sor(A, b, wopt, 1e-8, 2000);'); [~, kopt] = sor(A, b, wopt, 1e-8, 2000);
disp('>> kopt'); kopt
diary off;
