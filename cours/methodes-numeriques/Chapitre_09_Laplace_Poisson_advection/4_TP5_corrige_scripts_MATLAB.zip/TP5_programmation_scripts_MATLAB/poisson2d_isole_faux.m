function [A, b] = poisson2d_isole_faux(Nx, Ny, hx, hy, bc, g)
% POISSON2D_ISOLE_FAUX  Le piege : on double le coefficient sur la premiere rangee INTERIEURE (y = hy)
%   au lieu du mur lui-meme. Le mur bas reste un mur de Dirichlet (qui disparait des inconnues) et le
%   mur "isole" se retrouve decale d'un pas de maillage. Le systeme garde 35 inconnues : rien ne previent.
  if nargin < 6, g = @(i, j) 0; end
  nx = Nx - 1;  ny = Ny - 1;
  n = nx * ny;
  idx = @(i, j) (j - 1) * nx + i;
  ax = 1 / hx^2;  ay = 1 / hy^2;
  A = spalloc(n, n, 5 * n);
  b = zeros(n, 1);
  for j = 1:ny
    for i = 1:nx
      k = idx(i, j);
      A(k, k) = 2*ax + 2*ay;
      b(k) = g(i, j);
      if i > 1,  A(k, idx(i-1, j)) = -ax; else, b(k) = b(k) + bc(1)*ax; end
      if i < nx, A(k, idx(i+1, j)) = -ax; else, b(k) = b(k) + bc(2)*ax; end
      if j == 1
        A(k, idx(i, j+1)) = -2*ay;
      else
        A(k, idx(i, j-1)) = -ay;
        if j < ny, A(k, idx(i, j+1)) = -ay; else, b(k) = b(k) + bc(4)*ay; end
      end
    end
  end
end
