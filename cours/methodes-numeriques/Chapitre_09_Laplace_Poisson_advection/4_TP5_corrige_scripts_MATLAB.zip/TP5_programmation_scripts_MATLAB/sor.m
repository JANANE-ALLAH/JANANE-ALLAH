function [x, k] = sor(A, b, w, tol, nmax)
% SOR  Sur-relaxation successive pour A*x = b ; w = 1 donne Gauss-Seidel.
%   Un balayage = n mises a jour, chacune utilisant les composantes deja mises a jour.
%   Arret quand ||x - xancien|| < tol ; k = nombre de balayages effectues.
  n = length(b);
  x = zeros(n, 1);
  for k = 1:nmax
    xancien = x;
    for i = 1:n
      s = b(i) - A(i, :) * x + A(i, i) * x(i);
      x(i) = (1 - w) * x(i) + w * s / A(i, i);
    end
    if norm(x - xancien) < tol, break; end
  end
  if ~(norm(x - xancien) < tol)
    warning('Pas de convergence.');
  end
end
