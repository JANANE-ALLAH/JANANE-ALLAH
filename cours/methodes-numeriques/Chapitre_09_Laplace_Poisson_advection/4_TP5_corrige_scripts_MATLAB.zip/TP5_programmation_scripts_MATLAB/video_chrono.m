%% video_chrono.m
% TP5 : cout de la resolution directe (A\b creux et plein) et de SOR sur des grilles de plus en plus fines
% (un seul coeur, mediane de plusieurs essais). Les secondes dependent de la machine : comparez les RAPPORTS.
% Lancement (depuis ce dossier, machine au repos) :  matlab -batch "video_chrono"      (sortie : sorties/video_chrono.txt)
% Duree : une a deux minutes.
clear; clc;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_chrono.txt', 'file'), delete('sorties/video_chrono.txt'); end
diary('sorties/video_chrono.txt');

maxNumCompThreads(1);
fprintf('salle de sport 4 m x 3 m, bc = [25 10 10 10], un seul coeur, tol = 1e-8\n');
fprintf('%9s %7s %10s %12s %12s %12s %9s %12s\n', 'maillage', 'n', 'octets plein', 'assemblage s', 'A\b creux s', 'A\b plein s', 'SOR bal.', 'SOR s');
tailles = [8 6; 16 12; 32 24; 64 48; 128 96];
bc = [25 10 10 10];
res = zeros(size(tailles, 1), 6);
for m = 1:size(tailles, 1)
  Nx = tailles(m, 1);  Ny = tailles(m, 2);
  hx = 4 / Nx;  hy = 3 / Ny;
  n = (Nx - 1) * (Ny - 1);
  ta = median(arrayfun(@(r) timeit(@() poisson2d(Nx, Ny, hx, hy, bc)), 1:3));
  [A, b] = poisson2d(Nx, Ny, hx, hy, bc);
  tc = median(arrayfun(@(r) timeit(@() A \ b), 1:5));
  if n <= 3000
    Ap = full(A);
    tp = median(arrayfun(@(r) timeit(@() Ap \ b), 1:3));
  else
    tp = NaN;
  end
  if n <= 3000
    rho = (cos(pi / Nx) + cos(pi / Ny)) / 2;
    w = 2 / (1 + sqrt(1 - rho^2));
    tic;  [xs, ks] = sor(A, b, w, 1e-8, 5000);  ts = toc;
    erreur = max(abs(xs - A \ b));
  else
    ks = NaN;  ts = NaN;
  end
  fprintf('%4d x %-3d %7d %12.3g %12.3g %12.3g %12.3g %9g %12.3g\n', Nx, Ny, n, 8 * n^2, ta, tc, tp, ks, ts);
  res(m, :) = [n ta tc tp ks ts];
end
csvwrite('sorties/chrono.csv', res);
fprintf('rapport plein / creux pour n = 2961 : %.1f\n', res(4, 4) / res(4, 3));
fprintf('memoire de la matrice pleine pour 128 x 96 : %.2f Go ; pour 256 x 192 : %.1f Go\n', 8 * res(5, 1)^2 / 1e9, 8 * (255*191)^2 / 1e9);
diary off;
