function [x, k, incr, err] = tp2_sor(A, b, omega, tol, nmax, xex)
% TP2_SOR  Sur-relaxation successive (SOR) pour A x = b (TP2, chapitre 3).
%   [x, k, incr, err] = tp2_sor(A, b, omega, tol, nmax, xex)
%
%   On calcule la valeur de Gauss-Seidel x_i^GS, puis on la sur-corrige :
%       x_i <- (1 - omega) x_i + omega x_i^GS,   0 < omega < 2.
%   omega = 1 redonne exactement Gauss-Seidel.
%   Depart x(0) = 0 ; arret des que ||x(k) - x(k-1)||_2 < tol ou apres nmax.
%   Sorties : voir tp2_jacobi.

n  = length(b);
d  = full(diag(A));
At = A.';
x  = zeros(n, 1);
incr = zeros(nmax, 1);
err  = zeros(nmax, 1);
for k = 1:nmax
    xold = x;
    for i = 1:n
        s = b(i) - At(:, i).'*x + d(i)*x(i);
        x(i) = (1 - omega)*x(i) + omega*s/d(i);   % relaxation
    end
    incr(k) = norm(x - xold);
    if nargin > 5, err(k) = norm(x - xex); end
    if incr(k) < tol, break; end
end
incr = incr(1:k);
err  = err(1:k);
end
