%% tp2_manip2.m -- TP2, Manipulation 2 : effet du raffinement du maillage
% Meme paroi (T0 = 100 C, T_{n+1} = 0 C) discretisee avec n noeuds internes.
% Utilise tp2_jacobi.m, tp2_gauss_seidel.m, tp2_sor.m (meme dossier).
clear; clc;
tol = 1e-8;
lap = @(n) 2*eye(n) - diag(ones(n-1,1),1) - diag(ones(n-1,1),-1);

%% 1) n = 9 : la solution exacte reste un profil lineaire
n = 9;  A = lap(n);  b = zeros(n,1);  b(1) = 100;
xex  = A\b;
xlin = 100*(1 - (1:n)'/(n+1));      % T(x) = 100 (1 - x/L) aux noeuds x_i = i L/(n+1)
fprintf('n = 9 : A\\b = %s\n', mat2str(xex', 6));
fprintf('ecart maximal au profil lineaire : %.1e\n\n', max(abs(xex - xlin)));

%% 2) et 3) Iterations mesurees et predites, n = 4, 9, puis maillages plus fins
% Prediction : l'erreur part de ||x(0) - x*|| = ||x*|| et est multipliee par
% rho a chaque iteration  =>  k ~ ln(tol / ||x*||) / ln(rho).
ns = [4 9 19 49 99];
res = zeros(numel(ns), 11);
fprintf('%4s %8s %8s %7s | %6s %6s %4s | %6s %6s %4s | %s\n', 'n', 'rho_J', ...
    'rho_GS', 'omega*', 'Jacobi', 'GS', 'SOR', 'J pr.', 'GS pr.', 'SOR', ...
    'nmax ok ?');
for m = 1:numel(ns)
    n = ns(m);  A = sparse(lap(n));  b = zeros(n,1);  b(1) = 100;
    xex = A\b;
    rhoJ = cos(pi/(n+1));  rhoGS = rhoJ^2;
    wopt = 2/(1 + sin(pi/(n+1)));  rhoS = wopt - 1;
    nmax = 1e6;                                    % assez grand pour tout voir
    [~, kJ] = tp2_jacobi(A, b, tol, nmax);
    [~, kG] = tp2_gauss_seidel(A, b, tol, nmax);
    [~, kS] = tp2_sor(A, b, wopt, tol, nmax);
    pred = @(rho) ceil(log(tol/norm(xex))/log(rho));
    ok = {'non', 'oui'};
    fprintf('%4d %8.5f %8.5f %7.4f | %6d %6d %4d | %6d %6d %4d | %s %s %s\n', ...
        n, rhoJ, rhoGS, wopt, kJ, kG, kS, pred(rhoJ), pred(rhoGS), pred(rhoS), ...
        ok{1+(kJ<=2000)}, ok{1+(kG<=2000)}, ok{1+(kS<=2000)});
    res(m,:) = [n rhoJ rhoGS wopt kJ kG kS pred(rhoJ) pred(rhoGS) pred(rhoS) norm(xex)];
end

%% Erreur frequente : garder pour n = 9 le omega optimal de n = 4
n = 9;  A = sparse(lap(n));  b = zeros(n,1);  b(1) = 100;
w4 = 2/(1 + sin(pi/5));
[~, k4] = tp2_sor(A, b, w4, tol, 2000);
fprintf('\nn = 9 avec omega = %.4f (optimal pour n = 4) : %d iterations au lieu de %d\n', ...
    w4, k4, res(2,7));

%% Rapports n = 9 / n = 4 et lois d'echelle
r = res(2,5:7)./res(1,5:7);
fprintf('\nRapport des iterations n=9 / n=4 : Jacobi %.2f, GS %.2f, SOR %.2f\n', r);
fprintf('Rapport (10/5)^2 = %.0f attendu pour J et GS, 10/5 = %.0f pour SOR\n', (10/5)^2, 10/5);
pJ = polyfit(log(res(:,1)+1), log(res(:,5)), 1);
pS = polyfit(log(res(:,1)+1), log(res(:,7)), 1);
fprintf('Pentes log-log (iterations vs n+1) : Jacobi %.2f, SOR %.2f\n', pJ(1), pS(1));

%% Donnees de la figure (seulement dans l'arborescence du cours)
dossier = fullfile('..', 'figures', 'tp2');
if exist(fullfile('..', 'figures'), 'dir')
    if ~exist(dossier, 'dir'), mkdir(dossier); end
    writematrix(res(:, [1 5 6 7]), fullfile(dossier, 'iter_vs_n.csv'));
end
