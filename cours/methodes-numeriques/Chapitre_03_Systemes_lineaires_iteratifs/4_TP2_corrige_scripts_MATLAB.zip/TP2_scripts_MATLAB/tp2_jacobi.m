function [x, k, incr, err] = tp2_jacobi(A, b, tol, nmax, xex)
% TP2_JACOBI  Methode de Jacobi pour A x = b (TP2, chapitre 3).
%   [x, k, incr, err] = tp2_jacobi(A, b, tol, nmax, xex)
%
%   Iteration : x(k+1) = D^(-1) * ( b - (A - D) * x(k) ),  D = diag(A).
%   Toutes les composantes de x(k+1) sont calculees avec l'ANCIEN vecteur x(k).
%   Depart x(0) = 0 ; arret des que ||x(k) - x(k-1)||_2 < tol (critere sur
%   l'increment du cours) ou apres nmax iterations.
%
%   Sorties : x    derniere iteree x(k)
%             k    nombre d'iterations effectuees
%             incr historique des increments ||x(j) - x(j-1)||_2, j = 1..k
%             err  historique des erreurs ||x(j) - xex||_2 (si xex est fourni ;
%                  xex ne sert qu'a l'analyse, JAMAIS au critere d'arret)

n = length(b);
d = full(diag(A));            % diagonale de A (vecteur colonne)
R = A - diag(sparse(d));      % partie hors diagonale : R = A - D
x = zeros(n, 1);
incr = zeros(nmax, 1);
err  = zeros(nmax, 1);
for k = 1:nmax
    xnew = (b - R*x) ./ d;    % une seule ligne : c'est tout Jacobi
    incr(k) = norm(xnew - x);
    x = xnew;
    if nargin > 4, err(k) = norm(x - xex); end
    if incr(k) < tol, break; end
end
incr = incr(1:k);
err  = err(1:k);
end
