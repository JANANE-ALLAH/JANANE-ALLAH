%% tp2_manip3.m -- TP2, Manipulation 3 : recherche experimentale du omega optimal
% Cas n = 4 : nombre d'iterations SOR (tolerance 1e-8 sur l'increment) en
% fonction de omega, compare a la formule de Young et au rayon spectral.
% Utilise tp2_sor.m (meme dossier).
clear; clc;

n = 4;
A = 2*eye(n) - diag(ones(n-1,1),1) - diag(ones(n-1,1),-1);
b = zeros(n,1);  b(1) = 100;
tol = 1e-8;  nmax = 2000;
D = diag(diag(A));  E = -tril(A,-1);  F = -triu(A,1);
rhoJ = cos(pi/(n+1));
wopt = 2/(1 + sqrt(1 - rhoJ^2));            % formule de Young : 1.2596

nb_iter = @(w) nthout(2, @tp2_sor, A, b, w, tol, nmax);
rho_sor = @(w) max(abs(eig((D - w*E) \ ((1 - w)*D + w*F))));

%% 1) Balayage demande : omega = 1.0 : 0.05 : 1.9
om1 = 1.0:0.05:1.9;
it1 = arrayfun(nb_iter, om1);
for part = {1:10, 11:numel(om1)}                  % affichage en deux lignes
    fprintf('omega : '); fprintf('%6.2f', om1(part{1}));
    fprintf('\niter  : '); fprintf('%6d', it1(part{1})); fprintf('\n');
end
[m1, i1] = min(it1);
fprintf('Pas 0.05 : minimum %d iterations, atteint pour omega = %s\n', m1, mat2str(om1(it1 == m1)));

%% 2) Balayage fin : omega = 1.00 : 0.01 : 1.99
om2 = 1.00:0.01:1.99;
it2 = arrayfun(nb_iter, om2);
rh2 = arrayfun(rho_sor, om2);
[m2, i2] = min(it2);
fprintf('Pas 0.01 : minimum %d iterations, atteint pour omega = %s\n', m2, mat2str(om2(it2 == m2)));
fprintf('Young    : omega* = %.4f, rho(SOR) = omega* - 1 = %.4f, %d iterations\n', ...
    wopt, wopt - 1, nb_iter(wopt));

%% 3) Asymetrie autour de omega* : memes ecarts de part et d'autre
fprintf('\n%8s %10s %8s | %10s %8s\n', 'ecart', 'rho(w*-e)', 'iter', 'rho(w*+e)', 'iter');
for e = [0.02 0.05 0.10 0.20]
    fprintf('%8.2f %10.4f %8d | %10.4f %8d\n', e, rho_sor(wopt - e), nb_iter(wopt - e), ...
        rho_sor(wopt + e), nb_iter(wopt + e));
end
fprintf('Pente de rho a gauche (w* - 0.001) : %.1f   a droite (w* + 0.001) : %.2f\n', ...
    (rho_sor(wopt) - rho_sor(wopt - 1e-3))/1e-3, (rho_sor(wopt + 1e-3) - rho_sor(wopt))/1e-3);
fprintf('Extremites : omega = 1 (Gauss-Seidel) : %d it. ; 1.9 : %d ; 1.99 : %d\n', ...
    nb_iter(1), nb_iter(1.9), nb_iter(1.99));

%% Donnees des figures (seulement dans l'arborescence du cours)
dossier = fullfile('..', 'figures', 'tp2');
if exist(fullfile('..', 'figures'), 'dir')
    if ~exist(dossier, 'dir'), mkdir(dossier); end
    writematrix([om1' it1'], fullfile(dossier, 'omega_pas005.csv'));
    writematrix([om2' it2' rh2'], fullfile(dossier, 'omega_pas001.csv'));
end

function y = nthout(k, f, varargin)
% Renvoie la k-ieme sortie de f(varargin{:}) (ici : le nombre d'iterations).
[s{1:k}] = f(varargin{:});
y = s{k};
end
