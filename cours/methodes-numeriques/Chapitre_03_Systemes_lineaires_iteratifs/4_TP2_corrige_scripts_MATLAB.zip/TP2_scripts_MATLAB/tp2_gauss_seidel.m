function [x, k, incr, err] = tp2_gauss_seidel(A, b, tol, nmax, xex)
% TP2_GAUSS_SEIDEL  Methode de Gauss-Seidel pour A x = b (TP2, chapitre 3).
%   [x, k, incr, err] = tp2_gauss_seidel(A, b, tol, nmax, xex)
%
%   Pour i = 1..n :  x_i <- ( b_i - sum_{j~=i} a_ij x_j ) / a_ii
%   en lisant le vecteur x LUI-MEME : les composantes j < i sont deja celles
%   de l'iteration k+1 (c'est la seule difference avec Jacobi).
%   Depart x(0) = 0 ; arret des que ||x(k) - x(k-1)||_2 < tol ou apres nmax.
%   Sorties : voir tp2_jacobi.

n  = length(b);
d  = full(diag(A));
At = A.';                     % ligne i de A = colonne i de A.' (acces rapide)
x  = zeros(n, 1);
incr = zeros(nmax, 1);
err  = zeros(nmax, 1);
for k = 1:nmax
    xold = x;
    for i = 1:n
        s = b(i) - At(:, i).'*x + d(i)*x(i);   % b_i - sum_{j~=i} a_ij x_j
        x(i) = s / d(i);
    end
    incr(k) = norm(x - xold);
    if nargin > 4, err(k) = norm(x - xex); end
    if incr(k) < tol, break; end
end
incr = incr(1:k);
err  = err(1:k);
end
