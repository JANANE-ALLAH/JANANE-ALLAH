%% tp2_manip1.m -- TP2, Manipulation 1 : verification sur le cas n = 4
% Paroi de four : T0 = 100 C cote four, T5 = 0 C cote exterieur,
% n = 4 temperatures internes inconnues, A x = b (laplacien discret 1D).
% Utilise tp2_jacobi.m, tp2_gauss_seidel.m, tp2_sor.m (meme dossier).
clear; clc;

n = 4;
A = 2*eye(n) - diag(ones(n-1,1),1) - diag(ones(n-1,1),-1);
b = zeros(n,1);  b(1) = 100;
tol = 1e-8;  nmax = 2000;

%% 1) Solution de reference (methode directe)
xex = A\b;
fprintf('Solution exacte A\\b : %s\n', mat2str(xex', 6));

%% 2) Matrices d'iteration et rayons spectraux (decoupage A = D - E - F)
D = diag(diag(A));  E = -tril(A,-1);  F = -triu(A,1);
TJ   = D \ (E + F);                            % Jacobi
TGS  = (D - E) \ F;                            % Gauss-Seidel
rhoJ  = max(abs(eig(TJ)));
rhoGS = max(abs(eig(TGS)));
wopt  = 2/(1 + sqrt(1 - rhoJ^2));              % formule de Young
TSOR  = (D - wopt*E) \ ((1 - wopt)*D + wopt*F);
rhoSOR = max(abs(eig(TSOR)));

fprintf('\n              calcule (eig)   theorie\n');
fprintf('rho_J   = %12.6f   %12.6f  (cos(pi/5))\n', rhoJ, cos(pi/(n+1)));
fprintf('rho_GS  = %12.6f   %12.6f  (rho_J^2)\n', rhoGS, cos(pi/(n+1))^2);
fprintf('omega*  = %12.6f   %12.6f  (2/(1+sin(pi/5)))\n', wopt, 2/(1 + sin(pi/(n+1))));
fprintf('rho_SOR = %12.6f   %12.6f  (omega* - 1)\n', rhoSOR, wopt - 1);

%% 3) Les trois methodes
[xJ, kJ, incJ, errJ] = tp2_jacobi(A, b, tol, nmax, xex);
[xG, kG, incG, errG] = tp2_gauss_seidel(A, b, tol, nmax, xex);
[xS, kS, incS, errS] = tp2_sor(A, b, wopt, tol, nmax, xex);

fprintf('\nSolutions obtenues (colonnes : Jacobi, Gauss-Seidel, SOR) :\n');
disp([xJ xG xS]);

fprintf('%-13s %5s %11s %13s %11s %11s %9s\n', 'Methode', 'iter', ...
    'increment', 'erreur reelle', 'err/incr', 'residu rel', 'rho/(1-rho)');
ligne = @(nom, x, k, inc, err, rho) fprintf( ...
    '%-13s %5d %11.2e %13.2e %11.2f %11.2e %9.2f\n', nom, k, inc(end), ...
    err(end), err(end)/inc(end), norm(b - A*x)/norm(b), rho/(1 - rho));
ligne('Jacobi',       xJ, kJ, incJ, errJ, rhoJ);
ligne('Gauss-Seidel', xG, kG, incG, errG, rhoGS);
ligne('SOR optimal',  xS, kS, incS, errS, rhoSOR);

%% 4) Taux de convergence observe : rapport de deux erreurs successives
taux = @(err) err(end)/err(end-1);
fprintf('\nTaux observe e(k)/e(k-1) en fin de calcul : J %.4f  GS %.4f  SOR %.4f\n', ...
    taux(errJ), taux(errG), taux(errS));

%% 5) Donnees de la figure du corrige (seulement dans l'arborescence du cours)
dossier = fullfile('..', 'figures', 'tp2');
if exist(fullfile('..', 'figures'), 'dir')
    if ~exist(dossier, 'dir'), mkdir(dossier); end
    writematrix([(1:kJ)' errJ], fullfile(dossier, 'conv_n4_jacobi.csv'));
    writematrix([(1:kG)' errG], fullfile(dossier, 'conv_n4_gs.csv'));
    writematrix([(1:kS)' errS], fullfile(dossier, 'conv_n4_sor.csv'));
end
