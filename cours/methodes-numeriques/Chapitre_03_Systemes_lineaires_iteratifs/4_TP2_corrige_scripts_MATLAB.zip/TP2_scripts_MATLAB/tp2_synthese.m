%% tp2_synthese.m -- TP2, questions de synthese
% Q1 : A_n symetrique definie positive pour tout n ?
% Q2 : maillage tres fin (n = 1000) : Gauss-Seidel contre SOR optimal.
% Q3 : methode directe (TP1) contre methode iterative (TP2) : quand basculer ?
% Utilise tp2_jacobi.m, tp2_gauss_seidel.m, tp2_sor.m (meme dossier).
clear; clc;
lap = @(n) spdiags(ones(n,1)*[-1 2 -1], -1:1, n, n);   % laplacien 1D creux

%% Q1 -- A_n est SDP pour tout n
fprintf('Q1 : %5s %11s %13s %9s %8s %7s\n', 'n', 'lambda_min', '4sin^2(..)', ...
    '||A-A''||', 'chol ok', 'domin.');
for n = [4 9 100 1000]
    A = lap(n);
    lmin = min(eig(full(A)));
    [~, p] = chol(A);                          % p = 0 <=> A est SDP
    marge = full(2*abs(diag(A)) - sum(abs(A), 2));   % |a_ii| - sum_{j~=i} |a_ij|
    fprintf('     %5d %11.3e %13.3e %9.1e %8s %7s\n', n, lmin, ...
        4*sin(pi/(2*(n+1)))^2, norm(A - A', 1), mat2str(p == 0), ...
        sprintf('%g..%g', min(marge), max(marge)));
end
fprintf('     domin. = |a_ii| - somme |a_ij| : 0 sur les lignes internes (dominance FAIBLE)\n');

%% Q2 -- n = 1000 : Gauss-Seidel contre SOR optimal
n = 1000;  A = lap(n);  b = zeros(n,1);  b(1) = 100;  tol = 1e-8;
xex = A\b;
rhoJ = cos(pi/(n+1));  rhoGS = rhoJ^2;
wopt = 2/(1 + sin(pi/(n+1)));  rhoS = wopt - 1;
pred = @(rho) log(tol/norm(xex))/log(rho);
fprintf('\nQ2 : n = %d : 1 - rho_J = %.2e, 1 - rho_GS = %.2e\n', n, 1 - rhoJ, 1 - rhoGS);
fprintf('     omega* = %.4f, rho_SOR = omega* - 1 = %.4f\n', wopt, rhoS);
fprintf('     iterations predites : Jacobi %.2e, Gauss-Seidel %.2e, SOR %.0f\n', ...
    pred(rhoJ), pred(rhoGS), pred(rhoS));
tic;  [xS, kS, incS, errS] = tp2_sor(A, b, wopt, tol, 1e5, xex);  tS = toc;
fprintf('     SOR optimal mesure : %d iterations en %.1f s\n', kS, tS);
fprintf('     a l''arret : increment = %.1e, erreur reelle = %.1e\n', incS(end), errS(end));
tic;  tp2_gauss_seidel(A, b, 0, 500);  tGS = toc/500;     % 500 iterations chronometrees
fprintf('     Gauss-Seidel : %.2f ms/iteration -> %.1f h pour %.2e iterations\n', ...
    1e3*tGS, tGS*pred(rhoGS)/3600, pred(rhoGS));
fprintf('     facteur rho/(1-rho) (erreur/increment) : GS %.1e, SOR %.0f\n', ...
    rhoGS/(1 - rhoGS), rhoS/(1 - rhoS));

%% Q2 bis -- le piege du critere sur l'increment quand rho -> 1 (n = 99)
n = 99;  A = lap(n);  b = zeros(n,1);  b(1) = 100;  xex = A\b;
wopt = 2/(1 + sin(pi/(n+1)));
[~, kJ, iJ, eJ] = tp2_jacobi(A, b, 1e-8, 1e6, xex);
[~, kG, iG, eG] = tp2_gauss_seidel(A, b, 1e-8, 1e6, xex);
[~, kS, iS, eS] = tp2_sor(A, b, wopt, 1e-8, 1e6, xex);
fprintf('\n     n = 99, arret a incr < 1e-8 : %10s %10s %10s\n', 'iterations', 'increment', 'erreur');
fprintf('     Jacobi                        %10d %10.1e %10.1e\n', kJ, iJ(end), eJ(end));
fprintf('     Gauss-Seidel                  %10d %10.1e %10.1e\n', kG, iG(end), eG(end));
fprintf('     SOR optimal                   %10d %10.1e %10.1e\n', kS, iS(end), eS(end));

%% Q3 -- direct contre iteratif
% 1D (ce TP) : A tridiagonale, la factorisation est en O(n) sans remplissage.
fprintf('\nQ3 : 1D, A\\b creux :');
for n = [1e4 1e5 1e6]
    A = lap(n);  b = zeros(n,1);  b(1) = 100;
    tic;  x = A\b;  t = toc;                                   %#ok<NASGU>
    fprintf('  n = %.0e : %.3f s', n, t);
end
% 2D (salle de sport, TP5) : laplacien sur une grille N x N, n = N^2 inconnues.
fprintf('\n     2D, grille N x N : %6s %9s %11s %11s %9s\n', 'N', 'n', 'nnz(A)', 'nnz(chol)', 'rapport');
for N = [50 100 200]
    T = lap(N);  I = speye(N);
    A2 = kron(I, T) + kron(T, I);                   % laplacien 2D a 5 points
    R = chol(A2);                                   % ordre naturel, sans renumerotation
    fprintf('                          %6d %9d %11d %11d %9.1f\n', N, N^2, nnz(A2), nnz(R), nnz(R)/nnz(A2));
end
