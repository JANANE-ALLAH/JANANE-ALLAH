%% video_chrono.m
% TP2 : cout d'une iteration et duree de SOR pour n = 1000 (un seul coeur, mediane de plusieurs essais).
% Les secondes dependent de la machine ; ce qui compte, c'est le RAPPORT entre deux ecritures du meme calcul.
% Lancement (depuis ce dossier) :  matlab -batch "video_chrono"      (sortie : sorties/video_chrono.txt)
% Duree : environ 1 minute.
clear; clc;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_chrono.txt', 'file'), delete('sorties/video_chrono.txt'); end
diary('sorties/video_chrono.txt');

nthreads_avant = maxNumCompThreads;
maxNumCompThreads(1);
tol = 1e-8;  n = 1000;
[Ad, b] = paroi(n);                      % matrice pleine
As = sparse(Ad);                         % matrice creuse (3 diagonales)
w = 2 / (1 + sin(pi/(n+1)));
fprintf('n = %d, omega* = %.4f, un seul coeur\n', n, w);

warning('off', 'all');                   % on s'arrete volontairement apres 100 iterations
nit = 100;  nrep = 5;
essai = @(f) median(arrayfun(@(r) timeit_simple(f, nit), 1:nrep));
t_pl = essai(@() sor(Ad, b, w, 0, nit));
t_cl = essai(@() sor(As, b, w, 0, nit));
t_cc = essai(@() sor_colonnes(As, b, w, 0, nit));
fprintf('cout d''une iteration de SOR (mediane de %d essais de %d iterations) :\n', nrep, nit);
fprintf('  sor,          A pleine, lignes de A     : %5.2f ms\n', 1e3 * t_pl / nit);
fprintf('  sor,          A creuse, lignes de A     : %5.2f ms\n', 1e3 * t_cl / nit);
fprintf('  sor_colonnes, A creuse, colonnes de A.'' : %5.2f ms\n', 1e3 * t_cc / nit);
warning('on', 'all');

xex = As \ b;
tic;  [x1, k1] = sor(As, b, w, tol, 1e5);           t1 = toc;
tic;  [x2, k2] = sor_colonnes(As, b, w, tol, 1e5);  t2 = toc;
fprintf('SOR complet, A creuse :\n');
fprintf('  sor          : %d iterations en %5.1f s, erreur %.2e\n', k1, t1, norm(x1 - xex));
fprintf('  sor_colonnes : %d iterations en %5.1f s, erreur %.2e   (rapport %.1f)\n', k2, t2, norm(x2 - xex), t1 / t2);
tic;  xd = As \ b;  td_creux = toc;
tic;  xd = Ad \ b;  td_plein = toc;
fprintf('solveur direct A\\b : %.1e s (creux), %.1e s (plein)\n', td_creux, td_plein);

rj = cos(pi/(n+1));
pred = @(r) log(tol / norm(xex)) / log(r);
fprintf('Gauss-Seidel : %.2e iterations prevues x %.2f ms = %.2f h\n', pred(rj^2), 1e3 * t_cc / nit, pred(rj^2) * t_cc / nit / 3600);
fprintf('Jacobi       : %.2e iterations prevues x %.2f ms = %.2f h\n', pred(rj),   1e3 * t_cc / nit, pred(rj)   * t_cc / nit / 3600);
maxNumCompThreads(nthreads_avant);
diary off;

function t = timeit_simple(f, ~)
  tic;  f();  t = toc;
end
