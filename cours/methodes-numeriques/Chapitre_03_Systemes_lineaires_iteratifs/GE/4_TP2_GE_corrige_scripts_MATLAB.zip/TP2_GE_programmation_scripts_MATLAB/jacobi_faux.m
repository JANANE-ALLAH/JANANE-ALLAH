function [x, k, incr] = jacobi_faux(A, b, tol, nmax)
% JACOBI_FAUX  Le bug silencieux : on a copie xancien (pour le critere d'arret) mais on LIT x dans la formule.
%   Ce programme n'est plus Jacobi : c'est Gauss-Seidel. Aucune erreur, la solution est juste ;
%   seul le NOMBRE D'ITERATIONS trahit la confusion.
  n = length(b);
  if any(diag(A) == 0), error('Diagonale nulle.'); end
  x = zeros(n, 1);
  incr = zeros(nmax, 1);
  for k = 1:nmax
    xancien = x;
    for i = 1:n
      gauche = A(i, 1:i-1) * x(1:i-1);
      droite = A(i, i+1:n) * x(i+1:n);
      x(i) = (b(i) - gauche - droite) / A(i, i);
    end
    incr(k) = norm(x - xancien);
    if incr(k) < tol, break; end
  end
  if incr(k) >= tol, warning('Pas de convergence.'); end
  incr = incr(1:k);
end
