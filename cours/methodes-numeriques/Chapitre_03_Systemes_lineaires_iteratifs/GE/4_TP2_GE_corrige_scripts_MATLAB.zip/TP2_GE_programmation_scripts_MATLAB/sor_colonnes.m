function [x, k, incr] = sor_colonnes(A, b, omega, tol, nmax)
% SOR_COLONNES  Le meme SOR que sor.m, plus rapide sur les grandes matrices.
%   MATLAB range les matrices PAR COLONNES : lire la ligne i de A est lent (tres lent si A est creuse),
%   lire la colonne i de A.' donne les memes nombres, d'un seul bloc de memoire.
%   somme = (ligne i de A) * x - a(i,i) * x(i)  : tout le produit, puis on retire le terme diagonal.
  n = length(b);
  d = full(diag(A));
  At = A.';
  if any(d == 0), error('Diagonale nulle.'); end
  x = zeros(n, 1);
  incr = zeros(nmax, 1);
  for k = 1:nmax
    xancien = x;
    for i = 1:n
      somme = At(:, i).' * x - d(i) * x(i);
      xgs = (b(i) - somme) / d(i);
      x(i) = (1 - omega) * x(i) + omega * xgs;
    end
    incr(k) = norm(x - xancien);
    if incr(k) < tol, break; end
  end
  if incr(k) >= tol, warning('Pas de convergence.'); end
  incr = incr(1:k);
end
