function [x, k, incr] = jacobi(A, b, tol, nmax)
% JACOBI  Methode de Jacobi pour A x = b.
%   Chaque composante est recalculee avec l'ANCIEN vecteur xancien : on lit xancien, jamais x.
%   Depart x = 0 ; arret quand ||x(k) - x(k-1)|| < tol ; k = nombre d'iterations effectuees.
%   incr(k) = ||x(k) - x(k-1)|| : l'historique des increments.
  n = length(b);
  if any(diag(A) == 0), error('Diagonale nulle.'); end
  x = zeros(n, 1);
  incr = zeros(nmax, 1);
  for k = 1:nmax
    xancien = x;
    for i = 1:n
      gauche = A(i, 1:i-1) * xancien(1:i-1);
      droite = A(i, i+1:n) * xancien(i+1:n);
      x(i) = (b(i) - gauche - droite) / A(i, i);
    end
    incr(k) = norm(x - xancien);
    if incr(k) < tol, break; end
  end
  if incr(k) >= tol, warning('Pas de convergence.'); end
  incr = incr(1:k);
end
