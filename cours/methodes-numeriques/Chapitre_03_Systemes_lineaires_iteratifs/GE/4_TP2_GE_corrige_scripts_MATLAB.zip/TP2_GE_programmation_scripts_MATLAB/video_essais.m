%% video_essais.m
% TP2 -- video "programmer Jacobi, Gauss-Seidel et SOR sous MATLAB".
% Tous les nombres et toutes les sorties affichees dans la video viennent de ce script.
% Lancement (depuis ce dossier) :  matlab -batch "video_essais"      (sortie : sorties/video_essais.txt)
% Les fonctions paroi, jacobi, gauss_seidel, sor, jacobi_compact, gauss_seidel_compact, jacobi_faux,
% gauss_seidel_criteres et sor_colonnes sont dans ce dossier.
% Duree : environ 1 minute.
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_essais.txt', 'file'), delete('sorties/video_essais.txt'); end
diary('sorties/video_essais.txt');
tol = 1e-8;  nmax = 2000;

%% 0) Le systeme de la paroi d'etuve, n = 4
disp('=== 0) le systeme (n = 4)');
[A, b] = paroi(4)
xex = A\b
D = diag(diag(A));  E = -tril(A, -1);  F = -triu(A, 1);

%% 1) Jacobi : la trace de la boucle, puis le programme
disp('=== 1) Jacobi : trace de la boucle (k = 1 et 2)');
x = zeros(4, 1);
for k = 1:2
  xold = x;
  for i = 1:4
    somme = A(i, 1:i-1) * xold(1:i-1) + A(i, i+1:4) * xold(i+1:4);
    x(i) = (b(i) - somme) / A(i, i);
    fprintf('k = %d, i = %d : somme = %g ; x(%d) = (%g - (%g)) / %g = %g\n', k, i, somme, i, b(i), somme, A(i, i), x(i));
  end
end
disp('=== 1) Jacobi : les 4 premieres iterations (x0 = 0)');
warning('off', 'all');                               % on coupe volontairement avant la convergence
fprintf('%3s %9s %9s %9s %9s\n', 'k', 'T1', 'T2', 'T3', 'T4');
fprintf('%3d %9.4f %9.4f %9.4f %9.4f\n', 0, zeros(1, 4));
for m = 1:4
  xm = jacobi(A, b, tol, m);
  fprintf('%3d %9.4f %9.4f %9.4f %9.4f\n', m, xm);
end
warning('on', 'all');
disp('=== 1) Jacobi : le programme complet');
[x, kJ, incr] = jacobi(A, b, tol, nmax);
x
kJ
fprintf('norm(x - A\\b) = %.2e\n', norm(x - xex));
fprintf('dernier increment = %.2e\n', incr(end));
disp('=== 1) Jacobi : forme compacte');
[xc, kc] = jacobi_compact(A, b, tol, nmax);
fprintf('jacobi_compact : k = %d, norm(x - xc) = %g\n', kc, norm(x - xc));
xJ = x;

%% 2) Gauss-Seidel
disp('=== 2) Gauss-Seidel : trace de la boucle (k = 1)');
x = zeros(4, 1);
for k = 1:1
  xold = x;
  for i = 1:4
    somme = A(i, 1:i-1) * x(1:i-1) + A(i, i+1:4) * x(i+1:4);
    x(i) = (b(i) - somme) / A(i, i);
    fprintf('k = %d, i = %d : somme = %g ; x(%d) = (%g - (%g)) / %g = %g\n', k, i, somme, i, b(i), somme, A(i, i), x(i));
  end
end
disp('=== 2) Gauss-Seidel : les 4 premieres iterations (x0 = 0)');
warning('off', 'all');
fprintf('%3s %9s %9s %9s %9s\n', 'k', 'T1', 'T2', 'T3', 'T4');
fprintf('%3d %9.4f %9.4f %9.4f %9.4f\n', 0, zeros(1, 4));
for m = 1:4
  xm = gauss_seidel(A, b, tol, m);
  fprintf('%3d %9.4f %9.4f %9.4f %9.4f\n', m, xm);
end
warning('on', 'all');
disp('=== 2) Gauss-Seidel : le programme complet');
[xg, kg, histg] = gauss_seidel(A, b, tol, nmax);
xg
kg
fprintf('norm(xg - A\\b) = %.2e\n', norm(xg - xex));
disp('=== 2) Gauss-Seidel : forme compacte (un systeme triangulaire par iteration)');
[xt, kt] = gauss_seidel_compact(A, b, tol, nmax);
fprintf('gauss_seidel_compact : k = %d, norm(xg - xt) = %g\n', kt, norm(xg - xt));
disp('=== 2) le piege : jacobi_faux');
[xf, kf] = jacobi_faux(A, b, tol, nmax);
fprintf('jacobi_faux : k = %d (jacobi : %d, gauss_seidel : %d), norm(xf - xg) = %g, norm(xf - A\\b) = %.2e\n', ...
    kf, kJ, kg, norm(xf - xg), norm(xf - xex));

%% 3) SOR
disp('=== 3) SOR');
[x1, k1] = sor(A, b, 1, tol, nmax);
fprintf('sor avec omega = 1 : k = %d, norm(x - xg) = %g\n', k1, norm(x1 - xg));
rhoJ = cos(pi/(4+1));
wopt = 2 / (1 + sqrt(1 - rhoJ^2))
fprintf('2/(1 + sin(pi/5)) = %.6f\n', 2/(1 + sin(pi/5)));
[xs, ks, hists] = sor(A, b, wopt, tol, nmax);
xs
ks
fprintf('norm(xs - A\\b) = %.2e\n', norm(xs - xex));
disp('trace de la boucle SOR, k = 1, i = 1 et 2 :');
x = zeros(4, 1);
for i = 1:2
  somme = A(i, 1:i-1) * x(1:i-1) + A(i, i+1:4) * x(i+1:4);
  xgs = (b(i) - somme) / A(i, i);
  avant = x(i);
  x(i) = (1 - wopt) * x(i) + wopt * xgs;
  fprintf('i = %d : valeur de Gauss-Seidel = %g ; x(%d) = (1 - %.4f) * %g + %.4f * %g = %.4f\n', i, xgs, i, wopt, avant, wopt, xgs, x(i));
end
disp('les 3 premieres iterations de SOR (omega optimal) :');
warning('off', 'all');
fprintf('%3s %9s %9s %9s %9s\n', 'k', 'T1', 'T2', 'T3', 'T4');
for m = 1:3
  xm = sor(A, b, wopt, tol, m);
  fprintf('%3d %9.4f %9.4f %9.4f %9.4f\n', m, xm);
end
warning('on', 'all');

%% 4) Manipulation 3 : balayage de omega (n = 4)
disp('=== 4) balayage de omega');
figure('Visible', 'off');
omegas = 1.0:0.05:1.9;
iters = zeros(size(omegas));
for m = 1:length(omegas)
  [~, iters(m)] = sor(A, b, omegas(m), tol, nmax);
end
plot(omegas, iters, 'o-');
grid on;  xlabel('\omega');  ylabel('iterations SOR (n = 4)');
saveas(gcf, 'sorties/omega_n4.png');
fprintf('omega : '); fprintf('%6.2f', omegas(1:10));  fprintf('\n');
fprintf('iter  : '); fprintf('%6d', iters(1:10));     fprintf('\n');
fprintf('omega : '); fprintf('%6.2f', omegas(11:end)); fprintf('\n');
fprintf('iter  : '); fprintf('%6d', iters(11:end));    fprintf('\n');
[kmin, im] = min(iters);
fprintf('minimum : %d iterations, atteint pour omega = %.2f\n', kmin, omegas(im));
fprintf('formule de Young : omega = %.4f -> %d iterations\n', wopt, ks);
warning('off', 'all');
[~, k199] = sor(A, b, 1.99, tol, nmax);
warning('on', 'all');
fprintf('omega = 1.99 : %d iterations (plafond nmax = %d)\n', k199, nmax);
writematrix([omegas' iters'], 'sorties/omega_pas005.csv');
om2 = 1.00:0.01:1.99;  it2 = zeros(size(om2));
warning('off', 'all');
for m = 1:length(om2), [~, it2(m)] = sor(A, b, om2(m), tol, nmax); end
warning('on', 'all');
fprintf('pas 0.01 : minimum %d iterations pour omega = %s\n', min(it2), mat2str(om2(it2 == min(it2))));
writematrix([om2' it2'], 'sorties/omega_pas001.csv');
% omega optimal de n = 4 utilise pour n = 9
[A9, b9] = paroi(9);
w9 = 2 / (1 + sin(pi/10));
[~, k9] = sor(A9, b9, w9, tol, nmax);
[~, k9b] = sor(A9, b9, wopt, tol, nmax);
fprintf('n = 9 : omega* = %.4f -> %d iterations ; avec omega = %.4f (celui de n = 4) -> %d iterations\n', w9, k9, wopt, k9b);

%% 5) Rayons spectraux (n = 4) et courbes de convergence
disp('=== 5) rayons spectraux');
D = diag(diag(A));  E = -tril(A, -1);  F = -triu(A, 1);
TJ  = D \ (E + F);
TGS = (D - E) \ F;
TS  = (D - wopt*E) \ ((1 - wopt)*D + wopt*F);
rho = @(T) max(abs(eig(T)));
fprintf('rho(Jacobi)       = %.6f   cos(pi/5)     = %.6f\n', rho(TJ),  cos(pi/5));
fprintf('rho(Gauss-Seidel) = %.6f   rho(J)^2      = %.6f\n', rho(TGS), rho(TJ)^2);
fprintf('rho(SOR, omega*)  = %.6f   omega* - 1    = %.6f\n', rho(TS),  wopt - 1);
pred = @(r) ceil(log(tol / norm(xex)) / log(r));
fprintf('iterations prevues  : Jacobi %d, Gauss-Seidel %d, SOR %d\n', pred(rho(TJ)), pred(rho(TGS)), pred(rho(TS)));
fprintf('iterations mesurees : Jacobi %d, Gauss-Seidel %d, SOR %d\n', kJ, kg, ks);
% erreurs reelles a chaque iteration (pour les courbes de la video)
warning('off', 'all');
errJ = zeros(kJ, 1);  errG = zeros(kg, 1);  errS = zeros(ks, 1);
for m = 1:kJ, errJ(m) = norm(jacobi(A, b, tol, m) - xex); end
for m = 1:kg, errG(m) = norm(gauss_seidel(A, b, tol, m) - xex); end
for m = 1:ks, errS(m) = norm(sor(A, b, wopt, tol, m) - xex); end
warning('on', 'all');
writematrix([(1:kJ)' errJ], 'sorties/conv_n4_jacobi.csv');
writematrix([(1:kg)' errG], 'sorties/conv_n4_gs.csv');
writematrix([(1:ks)' errS], 'sorties/conv_n4_sor.csv');
fprintf('erreur reelle apres 1, 10, 20 iterations : Jacobi %.2e %.2e %.2e ; GS %.2e %.2e %.2e ; SOR %.2e %.2e %.2e\n', ...
    errJ([1 10 20]), errG([1 10 20]), errS([1 10 20]));
figure('Visible', 'off');
semilogy(1:kJ, errJ, 1:kg, errG, 1:ks, errS, 'LineWidth', 1.5);
legend('Jacobi', 'Gauss-Seidel', 'SOR optimal'); grid on;
xlabel('iteration k'); ylabel('erreur ||x(k) - x*||_2');
saveas(gcf, 'sorties/convergence_n4.png');

%% 6) Tests
disp('=== 6) tests');
[x, k2] = jacobi(eye(3), [1; 2; 3], tol, nmax);
fprintf('jacobi(eye(3), [1;2;3]) : x = %s, k = %d\n', mat2str(x'), k2);
A22 = [4 1; 1 3];  b22 = [9; 8];
warning('off', 'all');                                                   % une seule iteration : on coupe avant la convergence
xj1 = jacobi(A22, b22, tol, 1);  xg1 = gauss_seidel(A22, b22, tol, 1);
warning('on', 'all');
fprintf('exemple du cours, 1 iteration : Jacobi %s, Gauss-Seidel %s, exact %s\n', ...
    mat2str(xj1', 5), mat2str(xg1', 5), mat2str((A22\b22)', 5));
[~, kj22] = jacobi(A22, b22, tol, nmax);  [~, kg22] = gauss_seidel(A22, b22, tol, nmax);
fprintf('exemple du cours : Jacobi %d iterations, Gauss-Seidel %d iterations\n', kj22, kg22);
rng(1);  n = 6;  Am = rand(n) + n*eye(n);
xe = (1:n)';  bm = Am * xe;
[xm, km] = gauss_seidel(Am, bm, 1e-10, nmax);
fprintf('solution manufacturee (Gauss-Seidel, n = 6, tol = 1e-10) : k = %d, erreur = %.2e, residu = %.2e\n', ...
    km, norm(xm - xe), norm(Am*xm - bm));
[xm2, km2] = jacobi(Am, bm, 1e-10, nmax);
fprintf('solution manufacturee (Jacobi) : k = %d, erreur = %.2e, residu = %.2e\n', km2, norm(xm2 - xe), norm(Am*xm2 - bm));
try
  jacobi([0 1; 1 0], [1; 2], tol, nmax);
catch ME
  fprintf('jacobi([0 1; 1 0], [1; 2]) -> erreur : %s\n', ME.message);
end

%% 7) Criteres d'arret : n = 99
disp('=== 7) criteres d''arret, n = 99');
n = 99;  [A99, b99] = paroi(n);  xex99 = A99\b99;
rhoJ99 = cos(pi/(n+1));  rhoG99 = rhoJ99^2;  w99 = 2/(1 + sin(pi/(n+1)));  rhoS99 = w99 - 1;
fprintf('cond(A) = %.1f ; rho_GS = %.6f ; rho/(1 - rho) = %.1f\n', cond(A99), rhoG99, rhoG99/(1 - rhoG99));
[xj, kj, hj] = jacobi(A99, b99, tol, 1e6);
[xg99, kg99, hg] = gauss_seidel(A99, b99, tol, 1e6);
[xs99, ks99, hs] = sor(A99, b99, w99, tol, 1e6);
fprintf('%-13s %7s %10s %10s %10s %12s\n', 'methode', 'iter', 'increment', 'erreur', 'residu rel', 'rho/(1-rho)');
fprintf('%-13s %7d %10.2e %10.2e %10.2e %12.1f\n', 'Jacobi',       kj,   hj(end), norm(xj - xex99),    norm(b99 - A99*xj)/norm(b99),    rhoJ99/(1 - rhoJ99));
fprintf('%-13s %7d %10.2e %10.2e %10.2e %12.1f\n', 'Gauss-Seidel', kg99, hg(end), norm(xg99 - xex99), norm(b99 - A99*xg99)/norm(b99), rhoG99/(1 - rhoG99));
fprintf('%-13s %7d %10.2e %10.2e %10.2e %12.1f\n', 'SOR optimal',  ks99, hs(end), norm(xs99 - xex99), norm(b99 - A99*xs99)/norm(b99), rhoS99/(1 - rhoS99));
disp('trois regles d''arret pour Gauss-Seidel (n = 99, tol = 1e-8) :');
for c = {'increment', 'residu', 'borne'}
  [xc, kc] = gauss_seidel_criteres(A99, b99, tol, 1e6, c{1});
  fprintf('  %-10s : %6d iterations, erreur reelle = %.2e\n', c{1}, kc, norm(xc - xex99));
end

%% 8) Les pieges
disp('=== 8) pieges');
n = 49;  [A49, b49] = paroi(n);  xex49 = A49\b49;
[x49, k49, h49] = jacobi(A49, b49, tol, 2000);                 % nmax trop petit : le warning s'affiche
fprintf('Jacobi, n = 49, nmax = 2000 : k = %d, dernier increment = %.2e, erreur = %.2f\n', k49, h49(end), norm(x49 - xex49));
[x21, k21, h21] = sor(A, b, 2.1, tol, 100);
fprintf('SOR, omega = 2.1, nmax = 100 : erreur = %.2e\n', norm(x21 - xex));
warning('off', 'all');
fprintf('SOR, omega = 2.1 : erreur apres 10, 30, 100 iterations : ');
for m = [10 30 100], x = sor(A, b, 2.1, 0, m); fprintf('%.1e  ', norm(x - xex)); end
fprintf('\n');
A2 = [1 2 -2; 1 1 1; 2 2 1];  xs2 = [1; 2; 3];  b2 = A2 * xs2;
D2 = diag(diag(A2));  E2 = -tril(A2, -1);  F2 = -triu(A2, 1);
fprintf('matrice A2 : rho(Jacobi) = %.4f, rho(Gauss-Seidel) = %.4f\n', rho(D2 \ (E2 + F2)), rho((D2 - E2) \ F2));
[xj2, kj2] = jacobi(A2, b2, 1e-10, 50);
fprintf('A2 : Jacobi converge en %d iterations (x = %s)\n', kj2, mat2str(xj2'));
fprintf('A2 : erreur de Jacobi apres 2 et 3 iterations : %.3g  %.3g\n', norm(jacobi(A2, b2, 0, 2) - xs2), norm(jacobi(A2, b2, 0, 3) - xs2));
fprintf('A2 : erreur de Gauss-Seidel apres 1, 2, 3, 5, 10, 20 iterations : ');
for m = [1 2 3 5 10 20], x = gauss_seidel(A2, b2, 0, m); fprintf('%.3g  ', norm(x - xs2)); end
fprintf('\n');
warning('on', 'all');

%% 9) Maillages plus fins (Manipulation 2)
disp('=== 9) maillages fins');
ns = [4 9 19 49 99];  res = zeros(numel(ns), 7);
fprintf('%4s %8s %8s %7s | %6s %6s %5s\n', 'n', 'rho_J', 'rho_GS', 'omega*', 'Jacobi', 'GS', 'SOR');
for m = 1:numel(ns)
  n = ns(m);  [An, bn] = paroi(n);  wn = 2 / (1 + sin(pi/(n+1)));
  [~, k1] = jacobi(An, bn, tol, 1e6);  [~, k2] = gauss_seidel(An, bn, tol, 1e6);  [~, k3] = sor(An, bn, wn, tol, 1e6);
  res(m, :) = [n cos(pi/(n+1)) cos(pi/(n+1))^2 wn k1 k2 k3];
  fprintf('%4d %8.5f %8.5f %7.4f | %6d %6d %5d\n', n, res(m, 2), res(m, 3), wn, k1, k2, k3);
end
writematrix(res(:, [1 5 6 7]), 'sorties/iter_vs_n.csv');
pJ = polyfit(log(ns + 1), log(res(:, 5))', 1);
pS = polyfit(log(ns + 1), log(res(:, 7))', 1);
fprintf('pentes log-log (iterations en fonction de n+1) : Jacobi %.2f, SOR %.2f\n', pJ(1), pS(1));
fprintf('rapport des iterations n = 9 / n = 4 : Jacobi %.2f, Gauss-Seidel %.2f, SOR %.2f\n', res(2, 5:7) ./ res(1, 5:7));
[A9, b9] = paroi(9);
fprintf('n = 9 : solution exacte A\\b = %s\n', mat2str((A9 \ b9)', 6));

%% 10) n = 1000 et remplissage en 2D
disp('=== 10) n = 1000 : iterations prevues');
n = 1000;  A1 = spdiags(ones(n, 1) * [-1 2 -1], -1:1, n, n);  b1 = zeros(n, 1);  b1(1) = 100;
xex1 = A1 \ b1;  rj = cos(pi/(n+1));  w1 = 2/(1 + sin(pi/(n+1)));
pred1 = @(r) log(tol / norm(xex1)) / log(r);
fprintf('omega* = %.4f ; iterations prevues : Jacobi %.2e, Gauss-Seidel %.2e, SOR %.0f\n', w1, pred1(rj), pred1(rj^2), pred1(w1 - 1));
disp('=== 10) remplissage de la factorisation, Laplacien 2D (grille N x N, n = N^2)');
lap = @(m) spdiags(ones(m, 1) * [-1 2 -1], -1:1, m, m);
fprintf('%6s %9s %11s %11s %9s\n', 'N', 'n', 'nnz(A)', 'nnz(chol)', 'rapport');
for N = [50 100 200]
  T = lap(N);  I = speye(N);  A2d = kron(I, T) + kron(T, I);
  R = chol(A2d);
  fprintf('%6d %9d %11d %11d %9.1f\n', N, N^2, nnz(A2d), nnz(R), nnz(R)/nnz(A2d));
end
%% 11) GE : densite de flux de chaleur a travers la paroi de l'etuve
disp('=== 11) flux de chaleur (e = 0.5 m, lambda = 1 W/(m K))');
e = 0.5;  lambda = 1.0;  S = 10;
for n = [4 9]
  [An, bn] = paroi(n);  h = e/(n+1);
  T = [100; An\bn; 0];
  q = lambda * (T(1:end-1) - T(2:end)) / h;
  fprintf('n = %d : h = %.3f m ; q (W/m2) = %s\n', n, h, mat2str(q', 6));
end
[A4, b4] = paroi(4);  h = e/5;
[xj4, kj4] = jacobi(A4, b4, tol, nmax);  [xg4, kg4] = gauss_seidel(A4, b4, tol, nmax);  [xs4, ks4] = sor(A4, b4, wopt, tol, nmax);
qj = lambda * (100 - xj4(1)) / h;  qg = lambda * (100 - xg4(1)) / h;  qs = lambda * (100 - xs4(1)) / h;
fprintf('n = 4, flux d''entree lambda*(T0 - T1)/h : Jacobi %.6f, Gauss-Seidel %.6f, SOR %.6f W/m2 (exact 200)\n', qj, qg, qs);
fprintf('pertes de la paroi pour S = %d m2 : %.0f W\n', S, 200 * S);
n = 99;  [A99, b99] = paroi(n);  h = e/(n+1);
[xg99, kg99] = gauss_seidel(A99, b99, tol, 1e6);
T = [100; xg99; 0];  q = lambda * (T(1:end-1) - T(2:end)) / h;
fprintf('n = 99, Gauss-Seidel (increment 1e-8, %d iterations) : erreur sur T = %.2e K ; q entre %.4f et %.4f W/m2 ; ecart max a 200 = %.2e W/m2\n', ...
    kg99, norm(xg99 - A99\b99, inf), min(q), max(q), max(abs(q - 200)));
diary off;

