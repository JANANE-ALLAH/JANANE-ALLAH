%% video_consoles.m
% Les « fenetres de commandes » de la video : chaque commande est rejouee telle qu'elle apparait a l'ecran,
% avec les memes noms de variables, et sa sortie est celle de MATLAB (format short).
% Les lignes vides de MATLAB et les en-tetes « ### » ne sont pas affiches dans la video.
% Lancement (depuis ce dossier) :  matlab -batch "video_consoles"      (sortie : sorties/video_consoles.txt)
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_consoles.txt', 'file'), delete('sorties/video_consoles.txt'); end
diary('sorties/video_consoles.txt');

disp('### 2d) jacobi');
disp('>> [A, b] = paroi(4);');
[A, b] = paroi(4);
disp('>> [x, k, incr] = jacobi(A, b, 1e-8, 2000);');
[x, k, incr] = jacobi(A, b, 1e-8, 2000);
disp('>> x'''); x'
disp('>> k'); k
disp('>> norm(x - A\b)'); norm(x - A\b)
disp('### 2d) jacobi_compact');
disp('>> [xc, kc] = jacobi_compact(A, b, 1e-8, 2000);');
[xc, kc] = jacobi_compact(A, b, 1e-8, 2000);
disp('>> norm(x - xc)'); norm(x - xc)
disp('>> kc'); kc

disp('### 3d) gauss_seidel');
disp('>> [xg, kg] = gauss_seidel(A, b, 1e-8, 2000);');
[xg, kg] = gauss_seidel(A, b, 1e-8, 2000);
disp('>> kg'); kg
disp('>> norm(xg - A\b)'); norm(xg - A\b)
disp('### 3d) gauss_seidel_compact');
disp('>> [xt, kt] = gauss_seidel_compact(A, b, 1e-8, 2000);');
[xt, kt] = gauss_seidel_compact(A, b, 1e-8, 2000);
disp('>> kt'); kt
disp('>> norm(xg - xt)'); norm(xg - xt)
disp('### 3e) jacobi_faux');
disp('>> [xf, kf] = jacobi_faux(A, b, 1e-8, 2000);');
[xf, kf] = jacobi_faux(A, b, 1e-8, 2000);
disp('>> kf'); kf
disp('>> norm(xf - xg)'); norm(xf - xg)
disp('>> norm(xf - A\b)'); norm(xf - A\b)

disp('### 4b) sor avec omega = 1');
disp('>> [x1, k1] = sor(A, b, 1, 1e-8, 2000);');
[x1, k1] = sor(A, b, 1, 1e-8, 2000);
disp('>> k1'); k1
disp('>> norm(x1 - xg)'); norm(x1 - xg)
disp('### 4c) omega optimal');
disp('>> rhoJ = cos(pi/5);'); rhoJ = cos(pi/5);
disp('>> wopt = 2 / (1 + sqrt(1 - rhoJ^2))'); wopt = 2 / (1 + sqrt(1 - rhoJ^2))
disp('>> [xs, ks] = sor(A, b, wopt, 1e-8, 2000);');
[xs, ks] = sor(A, b, wopt, 1e-8, 2000);
disp('>> ks'); ks
disp('>> norm(xs - A\b)'); norm(xs - A\b)

disp('### 5a) rayons spectraux');
D = diag(diag(A));  E = -tril(A, -1);  F = -triu(A, 1);
TJ  = D \ (E + F);
TGS = (D - E) \ F;
TS  = (D - wopt*E) \ ((1 - wopt)*D + wopt*F);
rho = @(T) max(abs(eig(T)));
disp('>> rho(TJ)'); rho(TJ)
disp('>> rho(TGS)'); rho(TGS)
disp('>> rho(TS)'); rho(TS)

disp('### 5b) tests');
disp('>> [x, k] = jacobi(eye(3), [1; 2; 3], 1e-8, 100);'); [x, k] = jacobi(eye(3), [1; 2; 3], 1e-8, 100);
disp('>> x'''); x'
disp('>> k'); k
disp('>> jacobi([0 1; 1 0], [1; 2], 1e-8, 100)');
try
  jacobi([0 1; 1 0], [1; 2], 1e-8, 100);
catch ME
  fprintf('Error using %s (line %d)\n%s\n', ME.stack(1).name, ME.stack(1).line, ME.message);
end
warning('off', 'all');
disp('>> jacobi([4 1; 1 3], [9; 8], 1e-8, 1)'''); jacobi([4 1; 1 3], [9; 8], 1e-8, 1)'
disp('>> gauss_seidel([4 1; 1 3], [9; 8], 1e-8, 1)'''); gauss_seidel([4 1; 1 3], [9; 8], 1e-8, 1)'
disp('>> ([4 1; 1 3] \ [9; 8])'''); ([4 1; 1 3] \ [9; 8])'
warning('on', 'all');
disp('>> rng(1);  n = 6;  A = rand(n) + n*eye(n);');
rng(1);  n = 6;  A = rand(n) + n*eye(n);
disp('>> xe = (1:n)'';  b = A * xe;');
xe = (1:n)';  b = A * xe;
disp('>> [x, k] = gauss_seidel(A, b, 1e-10, 2000);');
[x, k] = gauss_seidel(A, b, 1e-10, 2000);
disp('>> k'); k
disp('>> erreur = norm(x - xe)'); erreur = norm(x - xe)
disp('>> residu = norm(A*x - b)'); residu = norm(A*x - b)

disp('### 5d) pieges');
disp('>> [A, b] = paroi(49);');
[A, b] = paroi(49);
disp('>> [x, k] = jacobi(A, b, 1e-8, 2000);');
[x, k] = jacobi(A, b, 1e-8, 2000);
disp('>> k'); k
disp('>> norm(x - A\b)'); norm(x - A\b)
disp('>> [A, b] = paroi(4);');
[A, b] = paroi(4);
disp('>> [x, k] = sor(A, b, 2.1, 1e-8, 100);');
[x, k] = sor(A, b, 2.1, 1e-8, 100);
disp('>> norm(x - A\b)'); norm(x - A\b)
disp('>> A = [1 2 -2; 1 1 1; 2 2 1];  b = A * [1; 2; 3];');
A = [1 2 -2; 1 1 1; 2 2 1];  b = A * [1; 2; 3];
D = diag(diag(A));  E = -tril(A, -1);  F = -triu(A, 1);
disp('>> rho((D - E) \ F)'); rho((D - E) \ F)
disp('>> rho(D \ (E + F))'); rho(D \ (E + F))
warning('off', 'all');
disp('>> [x, k] = jacobi(A, b, 1e-10, 50);');
[x, k] = jacobi(A, b, 1e-10, 50);
disp('>> x'''); x'
disp('>> k'); k
disp('>> [x, k] = gauss_seidel(A, b, 1e-10, 30);');
[x, k] = gauss_seidel(A, b, 1e-10, 30);
disp('>> norm(x - [1; 2; 3])'); norm(x - [1; 2; 3])
warning('on', 'all');
diary off;
