function [A, b] = paroi(n)
% PAROI  Systeme de la paroi d'etuve (TP2) : n temperatures internes inconnues.
%   Temperature imposee : 100 C cote etuve, 0 C cote exterieur.
%   Chaque noeud interne verifie  -T(i-1) + 2 T(i) - T(i+1) = 0.
  A = 2*eye(n) - diag(ones(n-1, 1), 1) - diag(ones(n-1, 1), -1);
  b = zeros(n, 1);
  b(1) = 100;
end
