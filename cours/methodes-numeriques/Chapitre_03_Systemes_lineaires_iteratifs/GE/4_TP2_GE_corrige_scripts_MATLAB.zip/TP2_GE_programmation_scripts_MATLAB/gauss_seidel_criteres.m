function [x, k] = gauss_seidel_criteres(A, b, tol, nmax, critere)
% GAUSS_SEIDEL_CRITERES  Gauss-Seidel avec trois regles d'arret au choix :
%   'increment' : ||x(k) - x(k-1)|| < tol
%   'residu'    : ||b - A x(k)|| < tol ||b||                (residu relatif)
%   'borne'     : r/(1 - r) * ||x(k) - x(k-1)|| < tol       avec r = rapport de deux increments successifs
%                 (la majoration ||x(k) - x*|| <= rho/(1 - rho) ||x(k) - x(k-1)|| du chapitre 3, rho estime)
  n = length(b);
  x = zeros(n, 1);
  hprev = NaN;
  for k = 1:nmax
    xancien = x;
    for i = 1:n
      gauche = A(i, 1:i-1) * x(1:i-1);
      droite = A(i, i+1:n) * x(i+1:n);
      x(i) = (b(i) - gauche - droite) / A(i, i);
    end
    h = norm(x - xancien);
    switch critere
      case 'increment', fini = h < tol;
      case 'residu',    fini = norm(b - A*x) < tol * norm(b);
      case 'borne',     r = h / hprev;  fini = r < 1 && r / (1 - r) * h < tol;
    end
    hprev = h;
    if fini, break; end
  end
end
