function [x, k, incr] = gauss_seidel_compact(A, b, tol, nmax)
% GAUSS_SEIDEL_COMPACT  Gauss-Seidel sans boucle sur i : un systeme TRIANGULAIRE par iteration.
%   (D - E) x(k+1) = b + F x(k)   avec   tril(A) = D - E   et   triu(A, 1) = -F.
  n = length(b);
  if any(diag(A) == 0), error('Diagonale nulle.'); end
  L = tril(A);
  U = triu(A, 1);
  x = zeros(n, 1);
  incr = zeros(nmax, 1);
  for k = 1:nmax
    xancien = x;
    x = L \ (b - U * xancien);
    incr(k) = norm(x - xancien);
    if incr(k) < tol, break; end
  end
  if incr(k) >= tol, warning('Pas de convergence.'); end
  incr = incr(1:k);
end
