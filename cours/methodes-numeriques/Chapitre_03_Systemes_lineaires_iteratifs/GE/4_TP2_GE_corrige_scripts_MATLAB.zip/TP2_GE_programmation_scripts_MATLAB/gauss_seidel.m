function [x, k, incr] = gauss_seidel(A, b, tol, nmax)
% GAUSS_SEIDEL  Methode de Gauss-Seidel pour A x = b.
%   On lit x LUI-MEME : les composantes j < i sont deja celles de l'iteration k+1.
%   xancien ne sert qu'au critere d'arret. Depart x = 0 ; arret quand ||x(k) - x(k-1)|| < tol.
  n = length(b);
  if any(diag(A) == 0), error('Diagonale nulle.'); end
  x = zeros(n, 1);
  incr = zeros(nmax, 1);
  for k = 1:nmax
    xancien = x;
    for i = 1:n
      gauche = A(i, 1:i-1) * x(1:i-1);
      droite = A(i, i+1:n) * x(i+1:n);
      x(i) = (b(i) - gauche - droite) / A(i, i);
    end
    incr(k) = norm(x - xancien);
    if incr(k) < tol, break; end
  end
  if incr(k) >= tol, warning('Pas de convergence.'); end
  incr = incr(1:k);
end
