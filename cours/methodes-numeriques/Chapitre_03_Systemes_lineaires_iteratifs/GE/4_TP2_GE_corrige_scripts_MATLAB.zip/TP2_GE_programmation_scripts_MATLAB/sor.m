function [x, k, incr] = sor(A, b, omega, tol, nmax)
% SOR  Sur-relaxation successive pour A x = b, 0 < omega < 2.
%   Meme boucle que Gauss-Seidel ; la valeur de Gauss-Seidel xgs est melangee a l'ancienne :
%       x(i) = (1 - omega) * x(i) + omega * xgs.     omega = 1 redonne Gauss-Seidel.
  n = length(b);
  if any(diag(A) == 0), error('Diagonale nulle.'); end
  x = zeros(n, 1);
  incr = zeros(nmax, 1);
  for k = 1:nmax
    xancien = x;
    for i = 1:n
      gauche = A(i, 1:i-1) * x(1:i-1);
      droite = A(i, i+1:n) * x(i+1:n);
      xgs = (b(i) - gauche - droite) / A(i, i);
      x(i) = (1 - omega) * x(i) + omega * xgs;
    end
    incr(k) = norm(x - xancien);
    if incr(k) < tol, break; end
  end
  if incr(k) >= tol, warning('Pas de convergence.'); end
  incr = incr(1:k);
end
