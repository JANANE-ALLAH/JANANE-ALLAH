function [x, k, incr] = jacobi_compact(A, b, tol, nmax)
% JACOBI_COMPACT  Jacobi sans boucle sur i : toutes les composantes d'un coup (seul Jacobi s'y prete).
  n = length(b);
  d = diag(A);
  if any(d == 0), error('Diagonale nulle.'); end
  R = A - diag(d);
  x = zeros(n, 1);
  incr = zeros(nmax, 1);
  for k = 1:nmax
    xancien = x;
    x = (b - R * xancien) ./ d;
    incr(k) = norm(x - xancien);
    if incr(k) < tol, break; end
  end
  if incr(k) >= tol, warning('Pas de convergence.'); end
  incr = incr(1:k);
end
