%% video_chrono.m
% TP1, Manipulation 3 appliquee a NOTRE fonction : temps de gauss_pivot et de l'operateur \
% (un seul coeur, mediane de plusieurs essais). Les secondes dependent de la machine ;
% c'est l'EXPOSANT qu'on compare a la theorie (3 pour une methode directe dense).
% Lancement (depuis ce dossier) :  matlab -batch "video_chrono"      (sortie : sorties/video_chrono.txt)
clear; clc;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_chrono.txt', 'file'), delete('sorties/video_chrono.txt'); end
diary('sorties/video_chrono.txt');

nthreads_avant = maxNumCompThreads;
maxNumCompThreads(1);
rng(1);
tailles = [100 200 400 800 1600];
nrep    = [  7   7   5   3    3];
t_gp = zeros(size(tailles));  t_bs = t_gp;  res = t_gp;
gauss_pivot(rand(5) + 5*eye(5), rand(5, 1));            % mise en route (compilation a la volee)
for k = 1:numel(tailles)
    n = tailles(k);
    A = rand(n) + n*eye(n);  b = rand(n, 1);
    e1 = zeros(1, nrep(k));  e2 = e1;
    for r = 1:nrep(k)
        tic; x = gauss_pivot(A, b); e1(r) = toc;
        tic; y = A \ b;             e2(r) = toc;
    end
    t_gp(k) = median(e1);  t_bs(k) = median(e2);  res(k) = norm(A*x - b);
    fprintf('n = %4d : gauss_pivot %.4e s ; A\\b %.4e s ; rapport %.1f ; residu %.2e ; ecart %.2e\n', ...
        n, t_gp(k), t_bs(k), t_gp(k)/t_bs(k), res(k), norm(x - y));
end
maxNumCompThreads(nthreads_avant);

disp('--- tableau (affiche dans la video) ---');
fprintf('%6s %13s %11s\n', 'n', 'gauss_pivot', 'A\b');
for k = 1:numel(tailles)
    fprintf('%6d %13.2e %11.2e\n', tailles(k), t_gp(k), t_bs(k));
end
disp('--- facteurs entre deux tailles successives (gauss_pivot) ---');
for k = 2:numel(tailles)
    fprintf('n = %4d -> %4d : x %.2f   (A\\b : x %.2f)\n', tailles(k-1), tailles(k), t_gp(k)/t_gp(k-1), t_bs(k)/t_bs(k-1));
end
sel = tailles >= 400;
p1 = polyfit(log(tailles(sel)), log(t_gp(sel)), 1);
p2 = polyfit(log(tailles(sel)), log(t_bs(sel)), 1);
fprintf('exposant empirique sur n >= 400 : gauss_pivot %.2f ; A\\b %.2f  (theorie : 3)\n', p1(1), p2(1));
diary off;

figure('Visible', 'off');
loglog(tailles, t_gp, 'o-', tailles, t_bs, 's-', tailles, t_gp(end)*(tailles/tailles(end)).^3, '--');
legend('gauss\_pivot', 'A\\b', 'n^3', 'Location', 'northwest'); grid on;
xlabel('taille n'); ylabel('temps (s)');
saveas(gcf, 'sorties/video_chrono.png');
