%% video_essais.m
% TP1 -- video "programmer Gauss avec pivot et Gauss-Jordan sous MATLAB".
% Tous les nombres et toutes les sorties affichees dans la video viennent de ce script.
% Lancement (depuis ce dossier) :  matlab -batch "video_essais"      (sortie : sorties/video_essais.txt)
% Les fonctions gauss_pivot, remontee, descente, triangularise, descente_gauss, gauss_jordan,
% gauss_sans_pivot sont dans ce dossier ; les variantes FAUSSES (bugs) sont des fonctions locales en bas.
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_essais.txt', 'file'), delete('sorties/video_essais.txt'); end
diary('sorties/video_essais.txt');

%% 0) Donnees du TP1
c0 = 200; c1 = 300; c2 = 100; c3 = 400;      % conductances en W/K
G = [c0+c1 -c1 0; -c1 c1+c2 -c2; 0 -c2 c2+c3];
Q = [500; 2000; 3500];                         % puissances en W
disp('=== 0) donnees'); G, Q

%% 1) La cible : v = G\Q et la solution du cours
disp('=== 1) solution de reference');
thref = G\Q
fprintf('cond(G) = %.4f\n', cond(G));

%% 2) La remontee, seule : le systeme triangulaire du cours
disp('=== 2) remontee (systeme triangulaire du cours)');
U = [2 1 -1; 0 3 2; 0 0 4];  y = [3; 7; 8];
x = remontee(U, y)
fprintf('residu norm(U*x-y) = %.4e\n', norm(U*x - y));
% trace de la boucle, ligne par ligne
n = 3; x = zeros(n, 1);
for i = n:-1:1
    somme = 0;
    for j = i+1:n
        somme = somme + U(i, j) * x(j);
        fprintf('  i = %d, j = %d : somme = %g\n', i, j, somme);
    end
    x(i) = (y(i) - somme) / U(i, i);
    fprintf('i = %d : somme = %g ; x(%d) = (%g - %g) / %g = %g\n', i, somme, i, y(i), somme, U(i, i), x(i));
end
% la forme compacte (produit d'un vecteur ligne par un vecteur colonne)
x2 = zeros(n, 1);
for i = n:-1:1
    x2(i) = (y(i) - U(i, i+1:n) * x2(i+1:n)) / U(i, i);
end
x2
fprintf('x identique a la double boucle : norm(x2-x) = %g\n', norm(x2 - x));
fprintf('U(3, 4:3) est de taille %s, x2(4:3) de taille %s, leur produit vaut %g\n', ...
    mat2str(size(U(3, 4:3))), mat2str(size(x2(4:3))), U(3, 4:3) * x2(4:3));
% la boucle descendante : trois ecritures
disp('boucles :');
disp(3:-1:1); fprintf('numel(3:1) = %d\n', numel(3:1));
% test de descente (triangulaire inferieure)
L = [1 0 0; 3 1 0; -2 4 1]; bb = [5; 4; 2];
yy = descente(L, bb)

%% 3) Gauss avec pivot sur le reseau : bloc du pivot a k = 2
disp('=== 3) pivot a k = 2 sur le reseau');
Aug = [G Q];
Aug(2, :) = Aug(2, :) - (Aug(2, 1) / Aug(1, 1)) * Aug(1, :);     % apres k = 1 (i = 2)
k = 2; n = 3;
bloc = Aug(k:n, k)
[valeur, idx] = max(abs(bloc))
p = idx + k - 1

%% 4) Trace complete de gauss_pivot sur le reseau
disp('=== 4) trace gauss_pivot(G, Q)');
trace_gauss(G, Q);
x = gauss_pivot(G, Q)
fprintf('residu norm(G*x-Q)       = %.4e\n', norm(G*x - Q));
fprintf('ecart  norm(x - G\\Q)     = %.4e\n', norm(x - G\Q));
fprintf('ecart  norm(x - [10;15;10]) = %.4e\n', norm(x - [10; 15; 10]));
help gauss_pivot

%% 5) Pourquoi pivoter : deux matrices 2 x 2
disp('=== 5) pivotage obligatoire / souhaitable');
A0 = [0 1; 1 0];  b0 = [1; 2];
disp('--- A0 = [0 1; 1 0], b0 = [1; 2]');
xs = gauss_sans_pivot(A0, b0)
xp = gauss_pivot(A0, b0)
Ae = [1e-17 1; 1 1];  be = [1; 2];
disp('--- Ae = [1e-17 1; 1 1], be = [1; 2]');
facteur = Ae(2, 1) / Ae(1, 1)
Aug = [Ae be];
Aug(2, :) = Aug(2, :) - facteur * Aug(1, :)
xs = gauss_sans_pivot(Ae, be)
xp = gauss_pivot(Ae, be)
fprintf('erreur relative max sans pivot : %.4e ; avec pivot : %.4e (solution presque (1,1))\n', ...
    max(abs(xs - [1; 1])), max(abs(xp - [1; 1])));
xe = Ae \ be

%% 6) Matrice d'essai a deux echanges de lignes
disp('=== 6) matrice a deux echanges');
A2 = [1 6 0; -2 0 -1; 5 6 6];  xex = [1; 2; 3];  b2 = A2 * xex
trace_gauss(A2, b2);
x2 = gauss_pivot(A2, b2)
fprintf('residu = %.4e ; erreur = %.4e\n', norm(A2*x2 - b2), norm(x2 - xex));
x2s = gauss_sans_pivot(A2, b2);
fprintf('sans pivot (ici le pivot 1 n''est pas nul) : erreur = %.4e\n', norm(x2s - xex));
[Lm, Um, Pm] = lu(A2);
disp('lu(A2) : U =' ); disp(Um); disp('P = '); disp(Pm);

%% 7) Les trois bugs
disp('=== 7) bugs');
xb1 = gauss_bug_p(G, Q)
fprintf('bug 1 (p = idx) : residu = %.4e\n', norm(G*xb1 - Q));
xb2 = gauss_bug_boucle(G, Q)
fprintf('bug 2 (for i = n:1) : residu = %.4f ; norm(Q) = %.4f\n', norm(G*xb2 - Q), norm(Q));
disp('bug 3 : sans pivotage sur [0 1; 1 0] -> voir section 5');

%% 8) Triangularise / descente_gauss : plusieurs seconds membres (Manipulation 2)
disp('=== 8) triangularise + descente_gauss');
[Uc, Mc, pc] = triangularise(G)
% --- le code AFFICHE dans la video (Manipulation 2), tel quel :
Qcas = [500 0 2500; 2000 5000 2500; 3500 0 2500];   % trois scenarios (W)
[U, M, p] = triangularise(G);
for k = 1:3
  y = descente_gauss(M, p, Qcas(:, k));
  Theta(:, k) = remontee(U, y);
end
Theta
Thcas = Theta;
fprintf('ecart avec G\\Qcas : %.4e\n', norm(Thcas - G\Qcas));
fprintf('G th2 = Q2 ?  residus : %s\n', mat2str(vecnorm(G*Thcas - Qcas), 3));
% --- la matrice d'essai a deux echanges : U, M, p, puis la descente
[U, M, p] = triangularise(A2);
U, M, p
y = descente_gauss(M, p, b2)
x2b = remontee(U, y)
L2 = eye(3) + M
fprintf('norm(A2(p,:) - L*U) = %.4e\n', norm(A2(p, :) - L2 * U));
fprintf('norm(A2(p,:) - (eye(3)+M)*U) = %g\n', norm(A2(p,:) - (eye(3)+M)*U));
y2 = y; M2 = M; p2 = p; U2 = U;
% couts (nombres d'operations, ordre de grandeur) : n = 1000, m = 100 seconds membres
nn = 1000; mm = 100;
fprintf('elimination ~ 2n^3/3 = %.3e ; une substitution (2 n^2) = %.3e\n', 2*nn^3/3, 2*nn^2);
fprintf('sans reutilisation : m * (2n^3/3 + 2n^2) = %.3e\n', mm * (2*nn^3/3 + 2*nn^2));
fprintf('avec reutilisation : 2n^3/3 + m * 2n^2   = %.3e   (rapport %.1f)\n', ...
    2*nn^3/3 + mm*2*nn^2, mm * (2*nn^3/3 + 2*nn^2) / (2*nn^3/3 + mm*2*nn^2));

%% 9) Gauss-Jordan
disp('=== 9) Gauss-Jordan');
trace_gj(G, Q);
X = gauss_jordan(G, Q)
Ginv = gauss_jordan(G, eye(3));
S = 1000 * Ginv
fprintf('norm(G*Ginv - I) = %.4e ; norm(Ginv - inv(G)) = %.4e ; norm(Ginv*Q - v) = %.4e\n', ...
    norm(G*Ginv - eye(3)), norm(Ginv - inv(G)), norm(Ginv*Q - thref));
Thgj = gauss_jordan(G, Qcas)
fprintf('gauss_jordan(G, Qcas) vs G\\Qcas : %.4e\n', norm(Thgj - G\Qcas));
Xe = gauss_jordan(A2, b2)
xjd = gauss_jordan([2 1; 4 3], [5; 11])
% le piege de l'ordre d'evaluation
disp('--- version "element par element" fausse :');
Xbug = gj_boucles_faux(G, Q)
fprintf('residu de la version fausse : %.4f\n', norm(G*Xbug - Q));
disp('x = gj_boucles_faux(G, Q);  x'''); xt = Xbug'
rr = norm(G*Xbug - Q)
Xok = gj_boucles_ok(G, Q)
fprintf('version corrigee (pivot et multiplicateur sauvegardes) : residu = %.4e\n', norm(G*Xok - Q));
rr_ok = norm(G*Xok - Q)
err_ok = norm(Xok - [10; 15; 10])
% singularite
try
    gauss_jordan([1 2; 2 4], [1; 2]);
catch ME
    disp(ME.message);
end
try
    gauss_pivot([1 2; 2 4], [1; 2]);
catch ME
    disp(ME.message);
end

%% 10) Cas de test
disp('=== 10) cas de test');
t1 = gauss_pivot(eye(3), [1; 2; 3])'
t2 = gauss_pivot([2 1 -1; 0 3 2; 0 0 4], [3; 7; 8])'
t3 = gauss_pivot([0 1; 1 0], [1; 2])'
rng(1); n = 6; A = rand(n) + n*eye(n);
x_exact = (1:n)';  b = A * x_exact;
x = gauss_pivot(A, b);
erreur = norm(x - x_exact)
residu = norm(A*x - b)
ecart_backslash = norm(x - A\b)
xg = gauss_jordan(A, b);
erreur_gj = norm(xg - x_exact)

diary off;

%% ----------------- fonctions locales (traces et variantes fausses) -----------------
function afficher(M)
    for i = 1:size(M, 1)
        fprintf('   %s\n', sprintf('%10.4f', M(i, :)));
    end
end

function trace_gauss(A, b)
    n = length(b);
    Aug = [A b];
    fprintf('depart :\n'); afficher(Aug);
    for k = 1:n-1
        [valeur, idx] = max(abs(Aug(k:n, k)));
        p = idx + k - 1;
        fprintf('k = %d : bloc = %s ; max = %g ; idx = %d ; p = idx + k - 1 = %d\n', k, mat2str(Aug(k:n, k)', 6), valeur, idx, p);
        Aug([k p], :) = Aug([p k], :);
        if p ~= k
            fprintf('   echange des lignes %d et %d :\n', k, p); afficher(Aug);
        end
        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
            fprintf('   i = %d : facteur = %.4f  ->  L%d <- L%d - (%.4f) L%d\n', i, facteur, i, i, facteur, k);
            afficher(Aug);
        end
    end
    fprintf('derniere matrice : pivots = %s\n', mat2str(diag(Aug(:, 1:n))', 6));
end

function trace_gj(A, b)
    n = length(b);
    Aug = [A b];
    fprintf('depart :\n'); afficher(Aug);
    for k = 1:n
        [~, idx] = max(abs(Aug(k:n, k)));
        p = idx + k - 1;
        Aug([k p], :) = Aug([p k], :);
        piv = Aug(k, k);
        Aug(k, :) = Aug(k, :) / Aug(k, k);
        fprintf('k = %d : pivot = %.4f ; normalisation L%d <- L%d / %.4f :\n', k, piv, k, k, piv); afficher(Aug);
        for i = 1:n
            if i ~= k
                m = Aug(i, k);
                Aug(i, :) = Aug(i, :) - Aug(i, k) * Aug(k, :);
                fprintf('   i = %d : multiplicateur = %.4f  ->  L%d <- L%d - (%.4f) L%d\n', i, m, i, i, m, k);
                afficher(Aug);
            end
        end
    end
end

function x = gauss_bug_p(A, b)       % BUG 1 : on oublie de corriger idx
    n = length(b); Aug = [A b];
    for k = 1:n-1
        [~, idx] = max(abs(Aug(k:n, k)));
        p = idx;                     % <-- devrait etre idx + k - 1
        Aug([k p], :) = Aug([p k], :);
        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
        end
    end
    x = remontee(Aug(:, 1:n), Aug(:, n+1));
end

function x = gauss_bug_boucle(A, b)  % BUG 2 : remontee avec for i = n:1
    n = length(b); Aug = [A b];
    for k = 1:n-1
        [~, idx] = max(abs(Aug(k:n, k)));
        p = idx + k - 1;
        Aug([k p], :) = Aug([p k], :);
        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
        end
    end
    U = Aug(:, 1:n); y = Aug(:, n+1);
    x = zeros(n, 1);
    for i = n:1                      % <-- liste vide : devrait etre n:-1:1
        somme = 0;
        for j = i+1:n
            somme = somme + U(i, j) * x(j);
        end
        x(i) = (y(i) - somme) / U(i, i);
    end
end

% (gj_boucles_faux et gj_boucles_ok sont des fichiers a part, dans ce dossier)
