function [U, M, p] = triangularise(A)
% TRIANGULARISE  Phase d'ELIMINATION de Gauss avec pivot partiel, faite sur A SEULE.
%   U : matrice triangulaire superieure obtenue
%   M : multiplicateurs de Gauss  m_ik = a_ik / a_kk  (ranges sous la diagonale)
%   p : permutation des lignes decidee par le pivotage
% Ces trois objets ne dependent que de A : on les reutilise pour N'IMPORTE QUEL second membre.
  n = size(A, 1);
  U = A;  M = zeros(n, n);  p = (1:n)';
  for k = 1:n-1
    [~, idx] = max(abs(U(k:n, k)));
    idx = idx + k - 1;
    U([k idx], :) = U([idx k], :);
    M([k idx], :) = M([idx k], :);
    p([k idx])    = p([idx k]);
    for i = k+1:n
      M(i, k) = U(i, k) / U(k, k);
      U(i, :) = U(i, :) - M(i, k) * U(k, :);
    end
  end
end
