function X = gj_boucles_faux(A, B)
% GJ_BOUCLES_FAUX  Gauss-Jordan ecrit ELEMENT PAR ELEMENT, sans sauvegarder le pivot ni le facteur : FAUX.
%   Illustre le piege de l'ordre d'evaluation (voir la video) ; ne pas l'utiliser.
%   (pas de pivotage non plus, pour isoler le bug)
  n = size(A, 1);  Aug = [A B];  m = size(Aug, 2);
  for k = 1:n
    for j = 1:m
      Aug(k, j) = Aug(k, j) / Aug(k, k);                   % Aug(k,k) vaut deja 1 des que j = k
    end
    for i = 1:n
      if i ~= k
        for j = 1:m
          Aug(i, j) = Aug(i, j) - Aug(i, k) * Aug(k, j);   % Aug(i,k) vaut deja 0 des que j = k
        end
      end
    end
  end
  X = Aug(:, n+1:end);
end
