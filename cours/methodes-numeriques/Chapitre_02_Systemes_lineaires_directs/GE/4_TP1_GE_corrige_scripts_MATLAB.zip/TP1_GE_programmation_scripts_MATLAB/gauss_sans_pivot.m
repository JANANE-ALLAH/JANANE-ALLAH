function x = gauss_sans_pivot(A, b)
% GAUSS_SANS_PIVOT  Version SANS pivotage : uniquement pour montrer ce qui se passe quand on l'oublie.
  n = length(b);
  Aug = [A b];
  for k = 1:n-1
    for i = k+1:n
      facteur = Aug(i, k) / Aug(k, k);
      Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
    end
  end
  x = remontee(Aug(:, 1:n), Aug(:, n+1));
end
