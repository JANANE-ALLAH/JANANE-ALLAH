function X = gj_boucles_ok(A, B)
% GJ_BOUCLES_OK  Gauss-Jordan ecrit element par element, CORRIGE : on sauvegarde le pivot et le facteur
%   avant la boucle sur les colonnes j. (pas de pivotage, pour comparer avec gj_boucles_faux)
  n = size(A, 1);  Aug = [A B];  m = size(Aug, 2);
  for k = 1:n
    pivot = Aug(k, k);
    for j = 1:m
      Aug(k, j) = Aug(k, j) / pivot;
    end
    for i = 1:n
      if i ~= k
        facteur = Aug(i, k);
        for j = 1:m
          Aug(i, j) = Aug(i, j) - facteur * Aug(k, j);
        end
      end
    end
  end
  X = Aug(:, n+1:end);
end
