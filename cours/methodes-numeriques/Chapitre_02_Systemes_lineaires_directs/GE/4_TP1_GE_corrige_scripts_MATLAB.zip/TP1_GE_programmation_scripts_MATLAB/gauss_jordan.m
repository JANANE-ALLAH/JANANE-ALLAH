function X = gauss_jordan(A, B)
% GAUSS_JORDAN  Resout A X = B par Gauss-Jordan avec pivot partiel.
%   B = b (vecteur colonne)  -> X est la solution de A x = b
%   B = eye(n)               -> X est l'INVERSE de A
%   B = [b1 b2 b3]           -> une colonne de X par second membre
  n = size(A, 1);
  Aug = [A B];                              % matrice augmentee [A | B]
  for k = 1:n                               % jusqu'a n : la derniere colonne aussi
    [~, idx] = max(abs(Aug(k:n, k)));
    p = idx + k - 1;
    if abs(Aug(p, k)) < 1e-14, error('Pivot nul.'); end
    Aug([k p], :) = Aug([p k], :);          % echange des lignes k et p
    Aug(k, :) = Aug(k, :) / Aug(k, k);      % normalisation : le pivot devient 1
    for i = 1:n                             % TOUTES les lignes ...
      if i ~= k                             % ... sauf la ligne du pivot
        Aug(i, :) = Aug(i, :) - Aug(i, k) * Aug(k, :);
      end
    end
  end
  X = Aug(:, n+1:end);                      % la solution se lit a droite de la barre
end
