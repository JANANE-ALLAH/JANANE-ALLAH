function y = descente_gauss(M, p, b)
% DESCENTE_GAUSS  Applique a b ce que l'elimination a fait sur A : permutation, puis multiplicateurs.
%   y = descente_gauss(M, p, b)   avec M et p renvoyes par triangularise
  n = length(b);
  y = b(p);
  for k = 1:n-1
    for i = k+1:n
      y(i) = y(i) - M(i, k) * y(k);
    end
  end
end
