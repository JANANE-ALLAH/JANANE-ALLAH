function x = gauss_pivot(A, b)
% GAUSS_PIVOT  Resout A x = b : elimination de Gauss avec pivot partiel, puis remontee.
%   x = gauss_pivot(A, b)      A : matrice carree n x n,   b : vecteur COLONNE n x 1
  n = length(b);
  Aug = [A b];                              % matrice augmentee [A | b]
  for k = 1:n-1                             % k = colonne du pivot
    [~, idx] = max(abs(Aug(k:n, k)));       % idx : position DANS le bloc k:n
    p = idx + k - 1;                        % p : numero REEL de la ligne
    if abs(Aug(p, k)) < 1e-14, error('Pivot nul.'); end
    Aug([k p], :) = Aug([p k], :);          % echange des lignes k et p
    for i = k+1:n                           % lignes SOUS le pivot
      facteur = Aug(i, k) / Aug(k, k);      % multiplicateur m_ik
      Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
    end
  end
  if abs(Aug(n, n)) < 1e-14, error('Pivot nul.'); end   % le dernier pivot aussi
  x = remontee(Aug(:, 1:n), Aug(:, n+1));   % U = bloc gauche, y = derniere colonne
end
