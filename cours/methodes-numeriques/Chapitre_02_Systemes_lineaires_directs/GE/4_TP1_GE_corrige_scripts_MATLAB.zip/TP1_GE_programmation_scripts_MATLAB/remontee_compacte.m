function x = remontee_compacte(U, y)
% REMONTEE_COMPACTE  Meme chose que remontee, avec un produit scalaire a la place de la boucle sur j.
%   Pour i = n, U(i, i+1:n) et x(i+1:n) sont VIDES : leur produit vaut 0, aucun cas particulier.
  n = length(y);
  x = zeros(n, 1);
  for i = n:-1:1
    x(i) = (y(i) - U(i, i+1:n) * x(i+1:n)) / U(i, i);
  end
end
