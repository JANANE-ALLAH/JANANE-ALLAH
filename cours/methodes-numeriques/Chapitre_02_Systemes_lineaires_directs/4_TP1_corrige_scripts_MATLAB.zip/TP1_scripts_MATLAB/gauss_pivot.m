function x = gauss_pivot(A, b)
% GAUSS_PIVOT  Resout A x = b par elimination de Gauss avec pivotage partiel.
%   x = gauss_pivot(A, b)
%   A : matrice carree n x n      b : second membre, vecteur COLONNE n x 1
%
% Deux phases, comme au chapitre 2 :
%   1) elimination : on fabrique des zeros sous la diagonale, colonne par colonne ;
%   2) remontee    : on calcule x_n, puis x_(n-1), ..., puis x_1.

    n = length(b);
    Aug = [A b];                            % matrice augmentee [A | b]

    % ---------- PHASE 1 : elimination ----------
    for k = 1:n-1                           % k = colonne du pivot

        % (a) pivotage partiel : plus grand |a_ik| pour i = k, ..., n
        [~, idx] = max(abs(Aug(k:n, k)));   % idx est RELATIF au bloc k:n
        p = idx + k - 1;                    % numero REEL de la ligne dans Aug
        if abs(Aug(p, k)) < 1e-14
            error('Pivot nul a la colonne %d : matrice singuliere.', k);
        end

        % (b) echange des lignes k et p
        Aug([k p], :) = Aug([p k], :);

        % (c) elimination sous le pivot
        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);            % multiplicateur m_ik
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);   % L_i <- L_i - m_ik L_k
        end
    end
    if abs(Aug(n, n)) < 1e-14
        error('Dernier pivot nul : matrice singuliere.');
    end

    % ---------- PHASE 2 : remontee ----------
    x = zeros(n, 1);
    for i = n:-1:1                          % on part de la derniere ligne
        somme = 0;
        for j = i+1:n
            somme = somme + Aug(i, j) * x(j);
        end
        x(i) = (Aug(i, n+1) - somme) / Aug(i, i);
    end
end
