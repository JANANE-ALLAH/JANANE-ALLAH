%% atelier6_verifications.m -- TP1, Atelier MATLAB, etape 5 (question A8) : verifier
% Un programme qui "tourne" n'est pas un programme JUSTE. Quelques habitudes.
clear; clc;

%% 1) Tester sur des cas dont on connait la reponse
x1 = gauss_pivot(eye(3), [1; 2; 3])                       % identite : x = b
x2 = gauss_pivot([2 1 -1; 0 3 2; 0 0 4], [3; 7; 8])       % triangulaire : (2, 1, 2)
x3 = gauss_pivot([0 1; 1 0], [1; 2])                      % pivot nul en (1,1) : (2, 1)

%% 2) Fabriquer un probleme dont on connait la solution ("solution manufacturee")
rng(1);  n = 6;
A = rand(n) + n*eye(n);                    % matrice aleatoire bien conditionnee
x_exact = (1:n)';                          % on CHOISIT la solution : (1,2,...,6)
b = A * x_exact;                           % ... et on en deduit le second membre
x = gauss_pivot(A, b);
erreur = norm(x - x_exact)                 % erreur sur la solution
residu = norm(A*x - b)                     % residu

%% 3) Comparer avec l'operateur natif
ecart_natif = norm(x - A\b)

%% 4) Une matrice singuliere doit donner un message CLAIR, pas un resultat faux
try
    gauss_pivot([1 2; 2 4], [1; 2]);
catch ME
    disp(ME.message)
end

%% 5) Le conditionnement dit si l'on peut se fier au resultat
C = [5 -3 0; -3 4 -1; 0 -1 5];
cond_C = cond(C)
