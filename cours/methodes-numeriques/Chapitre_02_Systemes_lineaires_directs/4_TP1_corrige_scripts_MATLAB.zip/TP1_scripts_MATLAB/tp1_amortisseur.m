%% tp1_amortisseur.m
% TP1 : reseau d'amortisseurs -- Gauss, plusieurs chargements,
% etude de complexite, descente/remontee et Gauss-Jordan
clear; close all; clc;

%% Manipulation 1 : elimination de Gauss sur le reseau a trois amortisseurs
c0=2; c1=3; c2=1; c3=4;
C = [c0+c1 -c1 0; -c1 c1+c2 -c2; 0 -c2 c2+c3];
F = [1;4;7];

v_gauss = gauss_pivot(C,F);
v_backslash = C\F;

fprintf('--- Manipulation 1 ---\n');
fprintf('v (Gauss pivot) = '); disp(v_gauss');
fprintf('v (C\\F)         = '); disp(v_backslash');
fprintf('residu Gauss    = %.3e\n', norm(C*v_gauss-F));

%% Manipulation 2 : plusieurs cas de chargement (triangularisation reutilisee)
Fcas = [1 0 5; 4 10 5; 7 0 5];  % colonnes = F(1), F(2), F(3)

% Phase d'elimination de Gauss : ne depend que de C -> faite UNE SEULE FOIS
[Uc, Mc, pc] = triangularise(C);
tic;
Vcas = zeros(3,3);
for k = 1:3
    y = descente_gauss(Mc, pc, Fcas(:,k));   % on applique les multiplicateurs deja calcules
    Vcas(:,k) = remontee(Uc, y);
end
t_reuse = toc;

tic;
Vcas2 = zeros(3,3);
for k = 1:3
    Vcas2(:,k) = C\Fcas(:,k);
end
t_backslash = toc;

fprintf('\n--- Manipulation 2 ---\n');
fprintf('v pour F1, F2, F3 (triangularisation reutilisee) :\n'); disp(Vcas);
fprintf('temps substitutions reutilisees : %.3e s\n', t_reuse);
fprintf('temps 3x C\\Fk (reference)       : %.3e s\n', t_backslash);

%% Manipulation 3 : etude de complexite (mediane sur plusieurs tirages)
% DEUX precautions sont indispensables pour que la loi O(n^3) soit visible :
%
%  1) FORCER UN SEUL COEUR. Les bibliotheques d'algebre lineaire de MATLAB
%     sont multithreadees : sur 8 coeurs, l'exposant mesure tombe a ~2,3 et
%     la loi cubique reste invisible quelle que soit la taille testee ici.
%     En monothread on retrouve ~2,8, proche des 3 attendus.
%  2) PARTIR DE n ASSEZ GRAND. En dessous de n = 400, le temps mesure est
%     domine par la surcharge d'appel (allocation, dispatch), pas par le
%     cout arithmetique : ces points ne disent rien de la complexite.
%
% Les temps absolus dependent de la machine ; c'est l'EXPOSANT qui doit etre
% compare a la theorie, pas les secondes.
nthreads_avant = maxNumCompThreads;
maxNumCompThreads(1);

tailles = [100 200 400 800 1600 3200];
nrep = 5;
temps = zeros(size(tailles));
for k = 1:length(tailles)
    n = tailles(k);
    Atest = rand(n) + n*eye(n);
    btest = rand(n,1);
    essais = zeros(1,nrep);
    for r = 1:nrep
        tic; Atest\btest; essais(r) = toc;
    end
    temps(k) = median(essais);
end

maxNumCompThreads(nthreads_avant);

fprintf('\n--- Manipulation 3 (monothread) ---\n');
for k = 1:length(tailles)
    if k == 1
        fprintf('n=%4d : temps=%.4e s\n', tailles(k), temps(k));
    else
        fprintf('n=%4d : temps=%.4e s   (x%.2f par rapport a n=%d)\n', ...
            tailles(k), temps(k), temps(k)/temps(k-1), tailles(k-1));
    end
end
% exposant empirique, estime sur les tailles ou le calcul domine (n >= 400)
sel = tailles >= 400;
pente = polyfit(log(tailles(sel)), log(temps(sel)), 1);
fprintf('exposant empirique sur n>=400 : %.2f   (theorie : 3)\n', pente(1));

figure;
loglog(tailles, temps, 'o-', 'LineWidth', 1.5); hold on;
loglog(tailles, temps(end)*(tailles/tailles(end)).^3, '--');
xlabel('taille n'); ylabel('temps (s)');
legend('mesure','reference n^3','Location','northwest');
title('Complexite empirique de la resolution directe (TP1)');
grid on;

%% Manipulation 4 : descente, remontee et Gauss-Jordan
[U4, M4, p4] = triangularise(C);
y4 = descente_gauss(M4, p4, F);
v_descrem = remontee(U4, y4);

v_gj  = gauss_jordan(C, F);
Cinv  = gauss_jordan(C, eye(3));

fprintf('\n--- Manipulation 4 ---\n');
fprintf('v (descente+remontee) = '); disp(v_descrem');
fprintf('v (Gauss-Jordan)       = '); disp(v_gj');
fprintf('C^-1 (Gauss-Jordan) :\n'); disp(Cinv);
fprintf('C^-1 (inv(C), reference) :\n'); disp(inv(C));
fprintf('||C*Cinv - I||_inf = %.3e\n', max(abs(C*Cinv - eye(3)),[],'all'));

function [U, M, p] = triangularise(A)
% Phase d'ELIMINATION de Gauss avec pivotage partiel, effectuee sur A seule
% (sans second membre). Renvoie :
%   U : la matrice triangulaire superieure obtenue,
%   M : les multiplicateurs de Gauss m(i,k) = a(i,k)/a(k,k),
%   p : la permutation des lignes effectuee par le pivotage.
% Ces trois objets ne dependent que de A : ils sont reutilisables pour
% n'importe quel second membre (cf. Manipulation 2).
    n = size(A,1);
    U = A; M = zeros(n,n); p = (1:n)';
    for k = 1:n-1
        [~,idx] = max(abs(U(k:n,k)));  idx = idx + k - 1;
        U([k idx],:) = U([idx k],:);
        M([k idx],:) = M([idx k],:);
        p([k idx])   = p([idx k]);
        for i = k+1:n
            M(i,k) = U(i,k)/U(k,k);
            U(i,:) = U(i,:) - M(i,k)*U(k,:);
        end
    end
end

function y = descente_gauss(M, p, b)
% Applique au second membre b les multiplicateurs deja calcules par
% triangularise : c'est la phase de "descente" de l'elimination de Gauss.
    n = length(b);
    y = b(p);
    for k = 1:n-1
        for i = k+1:n
            y(i) = y(i) - M(i,k)*y(k);
        end
    end
end

function x = gauss_pivot(A,b)
    n = length(b);
    Aug = [A b];
    for k = 1:n-1
        [~,idx] = max(abs(Aug(k:n,k)));
        idx = idx + k - 1;
        Aug([k idx],:) = Aug([idx k],:);
        for i = k+1:n
            m = Aug(i,k)/Aug(k,k);
            Aug(i,:) = Aug(i,:) - m*Aug(k,:);
        end
    end
    x = zeros(n,1);
    x(n) = Aug(n,end)/Aug(n,n);
    for i = n-1:-1:1
        x(i) = (Aug(i,end) - Aug(i,i+1:n)*x(i+1:n)) / Aug(i,i);
    end
end

function y = descente(L,b)
    n = length(b); y = zeros(n,1);
    y(1) = b(1)/L(1,1);
    for i = 2:n
        y(i) = (b(i) - L(i,1:i-1)*y(1:i-1)) / L(i,i);
    end
end

function x = remontee(U,y)
    n = length(y); x = zeros(n,1);
    x(n) = y(n)/U(n,n);
    for i = n-1:-1:1
        x(i) = (y(i) - U(i,i+1:n)*x(i+1:n)) / U(i,i);
    end
end

function X = gauss_jordan(A,B)
    n = size(A,1);
    Aug = [A B];
    for k = 1:n
        [~,idx] = max(abs(Aug(k:n,k)));
        idx = idx + k - 1;
        Aug([k idx],:) = Aug([idx k],:);
        Aug(k,:) = Aug(k,:)/Aug(k,k);
        for i = 1:n
            if i ~= k
                Aug(i,:) = Aug(i,:) - Aug(i,k)*Aug(k,:);
            end
        end
    end
    X = Aug(:, n+1:end);
end
