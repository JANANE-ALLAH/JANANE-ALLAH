%% atelier5_bugs.m -- TP1, Atelier MATLAB, etape 5 (question A7) : trois bugs classiques
% Les trois programmes ci-dessous tournent SANS message d'erreur.
% Le seul moyen de les prendre en defaut : verifier le residu ||C x - F||.
% (Les fonctions locales d'un script se placent a la FIN du fichier.)
clear; clc;

C = [5 -3 0; -3 4 -1; 0 -1 5];
F = [1; 4; 7];

fprintf('Programme correct (gauss_pivot) :\n');
x = gauss_pivot(C, F);
fprintf('   x = (%.4f, %.4f, %.4f)   residu = %.2e\n\n', x, norm(C*x - F));

fprintf('Bug 1 : on oublie le "+ k - 1" apres max\n');
x = gauss_bug1(C, F);
fprintf('   x = (%.4f, %.4f, %.4f)   residu = %.2e\n\n', x, norm(C*x - F));

fprintf('Bug 2 : la remontee est ecrite for i = n:1 au lieu de for i = n:-1:1\n');
x = gauss_bug2(C, F);
fprintf('   x = (%.4f, %.4f, %.4f)   residu = %.2e\n\n', x, norm(C*x - F));

fprintf('Bug 3 : on supprime le pivotage, sur A = [0 1; 1 0], b = [1; 2]\n');
A = [0 1; 1 0];  b = [1; 2];
x = gauss_bug3(A, b);
fprintf('   sans pivotage : x = (%g, %g)\n', x);
x = gauss_pivot(A, b);
fprintf('   avec pivotage : x = (%g, %g)\n', x);

%% ------------------------------------------------------------------
function x = gauss_bug1(A, b)
    n = length(b);  Aug = [A b];
    for k = 1:n-1
        [~, idx] = max(abs(Aug(k:n, k)));
        p = idx;                                   % <-- BUG : idx est RELATIF au bloc k:n
        Aug([k p], :) = Aug([p k], :);
        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
        end
    end
    x = remontee(Aug(:, 1:n), Aug(:, n+1));
end

function x = gauss_bug2(A, b)
    n = length(b);  Aug = [A b];
    for k = 1:n-1
        [~, idx] = max(abs(Aug(k:n, k)));
        p = idx + k - 1;
        Aug([k p], :) = Aug([p k], :);
        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
        end
    end
    x = zeros(n, 1);
    for i = n:1                                    % <-- BUG : n:1 est une liste VIDE
        somme = 0;
        for j = i+1:n
            somme = somme + Aug(i, j) * x(j);
        end
        x(i) = (Aug(i, n+1) - somme) / Aug(i, i);
    end
end

function x = gauss_bug3(A, b)
    n = length(b);  Aug = [A b];
    for k = 1:n-1                                  % <-- BUG : plus de recherche de pivot
        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);       % Aug(k,k) = 0 : division par zero
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
        end
    end
    x = remontee(Aug(:, 1:n), Aug(:, n+1));
end
