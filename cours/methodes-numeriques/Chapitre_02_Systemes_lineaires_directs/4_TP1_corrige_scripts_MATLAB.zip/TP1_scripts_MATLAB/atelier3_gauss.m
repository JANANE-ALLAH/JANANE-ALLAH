%% atelier3_gauss.m -- TP1, Atelier MATLAB, etape 3 (question A5) : de l'algorithme aux boucles
% On regarde gauss_pivot TRAVAILLER, etape par etape, sur le reseau d'amortisseurs,
% et on compare avec le calcul a la main du chapitre 2.
clear; clc;

C = [5 -3 0; -3 4 -1; 0 -1 5];
F = [1; 4; 7];

%% La version qui parle : matrice augmentee apres chaque colonne
x = gauss_pivot_pas_a_pas(C, F);

%% Verification : trois reflexes
v_ref   = C \ F;                            % 1) comparer a MATLAB
ecart   = norm(x - v_ref)                   %    ecart avec C\F
residu  = norm(C*x - F)                     % 2) le residu doit etre ~ 1e-15
x_cours = [2; 3; 2];                        % 3) la solution trouvee a la main
ecart_cours = norm(x - x_cours)

%% La version propre (celle que l'on rend)
x2 = gauss_pivot(C, F)
