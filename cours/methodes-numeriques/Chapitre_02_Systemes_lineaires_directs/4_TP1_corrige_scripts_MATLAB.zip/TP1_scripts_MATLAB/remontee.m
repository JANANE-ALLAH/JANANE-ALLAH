function x = remontee(U, y)
% REMONTEE  Resout U x = y, U triangulaire SUPERIEURE (substitution arriere).
%   x_i = ( y_i - somme_{j>i} u_ij x_j ) / u_ii,   en partant de i = n.

    n = length(y);
    x = zeros(n, 1);
    for i = n:-1:1
        somme = 0;
        for j = i+1:n
            somme = somme + U(i, j) * x(j);
        end
        x(i) = (y(i) - somme) / U(i, i);
    end
end
