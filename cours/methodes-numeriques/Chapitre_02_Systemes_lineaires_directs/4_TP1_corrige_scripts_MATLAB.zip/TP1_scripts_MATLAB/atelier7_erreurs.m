%% atelier7_erreurs.m -- TP1, Atelier MATLAB, etape 5 : les messages d'erreur, ca se lit
% Chaque bloc provoque VOLONTAIREMENT une erreur et affiche le message de MATLAB.
% (La langue du message depend de l'installation : anglais ou francais.)
clear; clc;

C = [5 -3 0; -3 4 -1; 0 -1 5];
F = [1; 4; 7];
Aug = [C F];                                   % 3 lignes, 4 colonnes

fprintf('1) indice trop grand : x = Aug(4,1)\n');
try, x = Aug(4,1);         catch ME, fprintf('   -> %s\n\n', ME.message); end

fprintf('2) variable inconnue (faute de frappe) : y = Auug + 1\n');
try, y = Auug + 1;         catch ME, fprintf('   -> %s\n\n', ME.message); end

fprintf('3) concatenation mal dimensionnee : B = [C; F]   (au lieu de [C F])\n');
try, B = [C; F];           catch ME, fprintf('   -> %s\n\n', ME.message); end

fprintf('4) produit mal dimensionne : w = C*[1 2 3]   (vecteur LIGNE)\n');
try, w = C*[1 2 3];        catch ME, fprintf('   -> %s\n\n', ME.message); end

fprintf('5) affectation de taille incorrecte : Aug(2,:) = [1 2]\n');
try, Aug(2,:) = [1 2];     catch ME, fprintf('   -> %s\n\n', ME.message); end

fprintf('6) fonction definie au MILIEU d''un script\n');
try, run('exemple_fonction_au_milieu.m');
catch ME
    msg = ME.message;  msg = msg(strfind(msg, 'Function definitions'):end);   % sans le chemin du fichier
    fprintf('   -> %s\n\n', strrep(msg, newline, [newline '      ']));
end

fprintf('7) division par zero : pas d''erreur, mais Inf ou NaN\n');
a = 1/0
b = 0/0
