function x = gauss_pivot_pas_a_pas(A, b)
% GAUSS_PIVOT_PAS_A_PAS  Comme gauss_pivot, mais AFFICHE la matrice augmentee
% apres chaque etape : pour comparer avec le calcul fait a la main.

    n = length(b);
    Aug = [A b];
    fprintf('Matrice augmentee de depart :\n');
    disp(Aug);

    for k = 1:n-1
        [~, idx] = max(abs(Aug(k:n, k)));
        p = idx + k - 1;
        fprintf('--- k = %d : pivot cherche dans les lignes %d a %d -> ligne %d, |pivot| = %.4f\n', ...
                k, k, n, p, abs(Aug(p, k)));
        if p ~= k
            fprintf('    echange des lignes %d et %d\n', k, p);
        end
        Aug([k p], :) = Aug([p k], :);

        for i = k+1:n
            facteur = Aug(i, k) / Aug(k, k);
            Aug(i, :) = Aug(i, :) - facteur * Aug(k, :);
            fprintf('    L%d <- L%d - (%.4f) * L%d\n', i, i, facteur, k);
        end
        fprintf('Apres elimination de la colonne %d :\n', k);
        disp(Aug);
    end

    x = zeros(n, 1);
    for i = n:-1:1
        somme = 0;
        for j = i+1:n
            somme = somme + Aug(i, j) * x(j);
        end
        x(i) = (Aug(i, n+1) - somme) / Aug(i, i);
        fprintf('remontee : x(%d) = %.4f\n', i, x(i));
    end
end
