function y = descente(L, b)
% DESCENTE  Resout L y = b, L triangulaire INFERIEURE (substitution avant).
%   y_i = ( b_i - somme_{j<i} l_ij y_j ) / l_ii,   en partant de i = 1.

    n = length(b);
    y = zeros(n, 1);
    for i = 1:n
        somme = 0;
        for j = 1:i-1
            somme = somme + L(i, j) * y(j);
        end
        y(i) = (b(i) - somme) / L(i, i);
    end
end
