function X = gauss_jordan(A, B)
% GAUSS_JORDAN  Resout A X = B par Gauss-Jordan avec pivotage partiel.
%   B = b (vecteur)   -> X est la solution du systeme A x = b
%   B = eye(n)        -> X est l'INVERSE de A
% Chaque colonne k : on choisit le pivot, on normalise la ligne k (pivot = 1),
% puis on elimine la colonne k dans TOUTES les autres lignes (au-dessus ET en dessous).

    n = size(A, 1);
    Aug = [A B];                            % matrice augmentee [A | B]

    for k = 1:n
        [~, idx] = max(abs(Aug(k:n, k)));
        p = idx + k - 1;
        Aug([k p], :) = Aug([p k], :);      % echange de lignes

        Aug(k, :) = Aug(k, :) / Aug(k, k);  % normalisation : le pivot devient 1

        for i = 1:n
            if i ~= k                       % toutes les lignes SAUF la ligne du pivot
                Aug(i, :) = Aug(i, :) - Aug(i, k) * Aug(k, :);
            end
        end
    end
    X = Aug(:, n+1:end);                    % on lit la solution a droite de la barre
end
