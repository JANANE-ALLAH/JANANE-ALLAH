%% atelier1_bases.m -- TP1, Atelier MATLAB, etape 1 : la boite a outils
% Tapez ces lignes UNE PAR UNE dans la fenetre de commandes (ou executez le
% script) et comparez avec ce que vous aviez prevu. Pas de ';' a la fin : on
% VEUT voir le resultat.
clear; clc;

%% 1) Creer une matrice et un vecteur
C = [5 -3 0; -3 4 -1; 0 -1 5]       % ';' separe les LIGNES
F = [1; 4; 7]                       % vecteur COLONNE (avec des ';')
size(C)                             % [nombre de lignes, nombre de colonnes]
length(F)                           % nombre d'elements du vecteur

%% 2) Lire une partie de la matrice (les indices commencent a 1)
C(2,3)                              % UN element : ligne 2, colonne 3
C(2,:)                              % toute la ligne 2   (':' = tout)
C(:,3)                              % toute la colonne 3
C(2:3,1)                            % lignes 2 a 3 de la colonne 1

%% 3) Le bloc du pivotage : de la ligne k a la ligne n, dans la colonne k
k = 2;  n = 3;
bloc = C(k:n, k)                    % [4; -1]
[valeur, idx] = max(abs(bloc))      % plus grand |element| ET sa position DANS le bloc
p = idx + k - 1                     % position dans C : on ajoute k-1 (decalage du bloc)

%% 4) Assembler la matrice augmentee, agir sur une ligne entiere
Aug = [C F]                         % colle F a droite de C : matrice augmentee
Aug(2,:) = Aug(2,:) + 0.6*Aug(1,:)  % L2 <- L2 + 0.6 L1 : UNE ligne de code par operation
Aug([1 3],:) = Aug([3 1],:)         % echanger les lignes 1 et 3 (liste d'indices)

%% 5) Calculer : produit matrice-vecteur, resolution, norme
v = [2; 3; 2];
C*v                                 % produit matrice x vecteur
C*v - F                             % residu : doit etre le vecteur nul
norm(C*v - F)                       % sa taille (norme 2)
C\F                                 % la resolution native de MATLAB

%% 6) Repeter : for k = debut:pas:fin
for i = 1:3
    fprintf('i = %d\n', i);
end
for i = 3:-1:1                      % a l'ENVERS : pas = -1
    fprintf('i = %d\n', i);
end
for i = 3:1                         % ATTENTION : 3:1 est VIDE (pas par defaut = +1)
    fprintf('cette ligne ne s''affiche jamais\n');
end
numel(3:1)                          % 0 element : la boucle ne tourne pas

%% 7) Decider : if
if abs(C(1,1)) < 1e-12
    disp('pivot nul !');
else
    disp('pivot acceptable');
end
