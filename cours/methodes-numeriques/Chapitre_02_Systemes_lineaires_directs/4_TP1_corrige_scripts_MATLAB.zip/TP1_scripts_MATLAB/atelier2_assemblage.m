%% atelier2_assemblage.m -- TP1, Atelier MATLAB, etape 2 (questions A2, A3, A4)
% De l'equation d'equilibre d'un noeud a la matrice C, puis au code.
%
% Equation du noeud i :  c_(i-1) (v_i - v_(i-1)) + c_i (v_i - v_(i+1)) = F_i
% soit :  -c_(i-1) v_(i-1) + (c_(i-1) + c_i) v_i - c_i v_(i+1) = F_i
%
% ATTENTION AU DECALAGE D'INDICE : MATLAB numerote a partir de 1.
% On range donc c_0, c_1, c_2, c_3 dans c(1), c(2), c(3), c(4) :
%       c_(i-1) s'ecrit c(i)      et      c_i s'ecrit c(i+1).
clear; clc;

c = [2 3 1 4];                      % c(1)=c0, c(2)=c1, c(3)=c2, c(4)=c3  (N.s/m)
F = [1; 4; 7];
N = 3;                              % nombre de noeuds (= nombre d'inconnues)

%% (a) A LA MAIN : on ecrit les trois equations, ligne par ligne
Cmain = [ c(1)+c(2),  -c(2),       0     ;
          -c(2),      c(2)+c(3),  -c(3)  ;
           0,         -c(3),       c(3)+c(4) ]

%% (b) PAR BOUCLE : la meme regle locale, repetee pour chaque noeud i
C = zeros(N, N);                    % on part d'une matrice de zeros
for i = 1:N
    C(i, i) = c(i) + c(i+1);        % diagonale       : c_(i-1) + c_i
    if i > 1                        % le voisin de gauche existe-t-il ?
        C(i, i-1) = -c(i);          % sous-diagonale  : -c_(i-1)
    end
    if i < N                        % le voisin de droite existe-t-il ?
        C(i, i+1) = -c(i+1);        % sur-diagonale   : -c_i
    end
end
C
ecart = norm(C - Cmain)             % 0 : les deux constructions coincident

%% (c) SANS BOUCLE : diag(vecteur, decalage)
Cdiag = diag(c(1:N) + c(2:N+1)) - diag(c(2:N), 1) - diag(c(2:N), -1);
ecart_diag = norm(C - Cdiag)

%% Resolution et verification
v = C \ F
residu = norm(C*v - F)

%% La boucle marche pour N quelconque : il suffit de changer N et c
N = 8;
c = linspace(1, 3, N+1);            % 9 amortisseurs, de 1 a 3 N.s/m
C8 = zeros(N, N);
for i = 1:N
    C8(i, i) = c(i) + c(i+1);
    if i > 1,  C8(i, i-1) = -c(i);    end
    if i < N,  C8(i, i+1) = -c(i+1);  end
end
C8(1:4, 1:4)                        % coin haut-gauche : structure tridiagonale
sym = norm(C8 - C8')                % 0 : C est symetrique
F8 = ones(N, 1);                    % un chargement de 1 N sur chaque masse
v8 = C8 \ F8

%% Conditions aux limites : que devient le noeud 1 si le batis se deplace ?
% Noeud 1 : c_0 (v_1 - v_0) + c_1 (v_1 - v_2) = F_1  avec v_0 = 0.5 m/s CONNU.
% Le terme c_0 v_0 est connu : il passe dans le SECOND MEMBRE.
c = [2 3 1 4];  N = 3;
C = [5 -3 0; -3 4 -1; 0 -1 5];
v0 = 0.5;
b = F;                              % on part du chargement F = (1;4;7)
b(1) = F(1) + c(1)*v0               % b_1 = F_1 + c_0 v_0
vcl = C \ b
% verification : l'equation du noeud 1, ecrite avec v_0, doit redonner F_1
verif_noeud1 = c(1)*(vcl(1) - v0) + c(2)*(vcl(1) - vcl(2))
