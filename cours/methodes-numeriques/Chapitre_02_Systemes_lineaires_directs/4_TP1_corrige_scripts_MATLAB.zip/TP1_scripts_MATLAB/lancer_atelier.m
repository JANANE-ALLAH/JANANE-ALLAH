function lancer_atelier()
% LANCER_ATELIER  Execute les 7 scripts de l'atelier et range leur sortie dans sorties/.
% Utile pour verifier que tout tourne (a lancer depuis ce dossier).

    scripts = {'atelier1_bases', 'atelier2_assemblage', 'atelier3_gauss', 'atelier4_gauss_jordan', ...
               'atelier5_bugs', 'atelier6_verifications', 'atelier7_erreurs'};
    if ~exist('sorties', 'dir'), mkdir('sorties'); end
    for s = 1:numel(scripts)
        fichier = fullfile('sorties', [scripts{s} '.txt']);
        if exist(fichier, 'file'), delete(fichier); end     % diary AJOUTE a un fichier existant
        diary(fichier);
        executer(scripts{s});
        diary off;
        fprintf('%-26s termine\n', scripts{s});
    end
end

function executer(nom)
% Un script s'execute dans l'espace de travail de celui qui l'appelle, et les
% scripts de l'atelier commencent par 'clear' : on les lance donc DEPUIS cette
% fonction, pour ne pas effacer les variables de la boucle ci-dessus.
    try
        feval(nom);
    catch ME
        disp(['ECHEC : ' ME.message]);
    end
end
