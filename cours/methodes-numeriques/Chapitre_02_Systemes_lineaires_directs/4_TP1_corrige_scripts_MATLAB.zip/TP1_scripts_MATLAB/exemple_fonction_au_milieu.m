x = 1;

function y = carre(t)
    y = t^2;
end

z = carre(3)
