%% atelier4_gauss_jordan.m -- TP1, Atelier MATLAB, etape 4 (question A6)
% Chaque operation sur les lignes du cours = UNE ligne de code MATLAB.
clear; clc;

%% (a) L'exemple du cours, 2 x 2 :   2 x1 + x2 = 5,   4 x1 + 3 x2 = 11
Aug = [2 1 5; 4 3 11]                          % matrice augmentee de depart
Aug(1,:) = Aug(1,:) / Aug(1,1)                 % L1 <- L1 / 2      (normaliser le pivot)
Aug(2,:) = Aug(2,:) - Aug(2,1)*Aug(1,:)        % L2 <- L2 - 4 L1  (annuler SOUS le pivot)
Aug(2,:) = Aug(2,:) / Aug(2,2)                 % L2 <- L2 / 1     (normaliser : deja 1)
Aug(1,:) = Aug(1,:) - Aug(1,2)*Aug(2,:)        % L1 <- L1 - 0.5 L2 (annuler AU-DESSUS)
x = Aug(:, 3)                                  % on LIT la solution dans la colonne de droite

%% (b) Les memes operations, ecrites une seule fois dans une boucle
X = gauss_jordan([2 1; 4 3], [5; 11])

%% (c) Reseau d'amortisseurs : solution, puis inverse
C = [5 -3 0; -3 4 -1; 0 -1 5];
F = [1; 4; 7];
v    = gauss_jordan(C, F)                      % B = vecteur : on obtient la solution
Cinv = gauss_jordan(C, eye(3))                 % B = identite : on obtient l'inverse
verif_inverse = norm(C*Cinv - eye(3))          % C * C^-1 doit valoir l'identite
ecart_inv     = norm(Cinv - inv(C))            % comparaison avec la fonction native
