function [t, T] = euler_explicite(f, T0, tf, h)
% Euler explicite : T(n+1) = T(n) + h f(t(n), T(n)).
N = round(tf/h);
t = (0:N)'*h;
T = zeros(N+1, 1);
T(1) = T0;
for n = 1:N
    T(n+1) = T(n) + h*f(t(n), T(n));
end
end
