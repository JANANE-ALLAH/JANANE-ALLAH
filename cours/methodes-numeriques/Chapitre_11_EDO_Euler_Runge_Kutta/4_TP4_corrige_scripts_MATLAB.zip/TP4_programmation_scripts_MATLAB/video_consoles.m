%% video_consoles.m
% Les " fenetres de commandes " de la video : chaque commande est rejouee telle qu'elle apparait a l'ecran,
% avec les memes noms de variables, et sa sortie est celle de MATLAB.
% Les lignes vides de MATLAB et les en-tetes " ### " ne sont pas affiches dans la video.
% Lancement (depuis ce dossier) :  matlab -batch "video_consoles"      (sortie : sorties/video_consoles.txt)
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_consoles.txt', 'file'), delete('sorties/video_consoles.txt'); end
diary('sorties/video_consoles.txt');
warning('off', 'backtrace');

disp('### 2a) le modele');
disp('>> [f, dfdT] = modele_four();'); [f, dfdT] = modele_four();
disp('>> f(0, 1200)'); f(0, 1200)
disp('>> dfdT(0, 1200)'); dfdT(0, 1200)

disp('### 3a) Euler explicite');
disp('>> [t, Te] = euler_explicite(f, 1200, 1200, 5);'); [t, Te] = euler_explicite(f, 1200, 1200, 5);
disp('>> fprintf(''%.4f\n'', Te(2))'); fprintf('%.4f\n', Te(2))
disp('>> Te(end)'); Te(end)

disp('### 4a) RK4');
disp('>> [t, Tr] = rk4(f, 1200, 1200, 5);'); [t, Tr] = rk4(f, 1200, 1200, 5);
disp('>> fprintf(''%.4f\n'', Tr(2))'); fprintf('%.4f\n', Tr(2))
disp('>> Tr(end)'); Tr(end)
disp('>> abs(Te(end) - Tr(end))'); abs(Te(end) - Tr(end))

disp('### 5a) Euler implicite');
disp('>> [t, Ti, nit] = euler_implicite(f, dfdT, 1200, 1200, 5);'); [t, Ti, nit] = euler_implicite(f, dfdT, 1200, 1200, 5);
disp('>> fprintf(''%.4f\n'', Ti(2))'); fprintf('%.4f\n', Ti(2))
disp('>> Ti(end)'); Ti(end)
disp('>> [min(nit)  max(nit)  mean(nit)]'); [min(nit)  max(nit)  mean(nit)]
disp('>> abs(Ti(end) - Tr(end))'); abs(Ti(end) - Tr(end))

disp('### 6a) ordre de convergence');
disp('>> hs = [40 20 10 5 2.5];'); hs = [40 20 10 5 2.5];
disp('>> format short e'); format short e
disp('>> eE = arrayfun(@(h) erreur_finale(''euler'', h), hs)'); eE = arrayfun(@(h) erreur_finale('euler', h), hs)
disp('>> eR = arrayfun(@(h) erreur_finale(''rk4'', h), hs)'); eR = arrayfun(@(h) erreur_finale('rk4', h), hs)
disp('>> eI = arrayfun(@(h) erreur_finale(''implicite'', h), hs)'); eI = arrayfun(@(h) erreur_finale('implicite', h), hs)
disp('>> format short'); format short
disp('>> eE(1:end-1) ./ eE(2:end)'); eE(1:end-1) ./ eE(2:end)
disp('>> eR(1:end-1) ./ eR(2:end)'); eR(1:end-1) ./ eR(2:end)
disp('>> eI(1:end-1) ./ eI(2:end)'); eI(1:end-1) ./ eI(2:end)

disp('### 7a) grand pas');
disp('>> [t, Tg] = euler_explicite(f, 1200, 1200, 300);'); [t, Tg] = euler_explicite(f, 1200, 1200, 300);
disp('>> round(Tg'')'); round(Tg')
disp('>> min(Tg)'); min(Tg)
disp('>> [t, Tk] = euler_implicite(f, dfdT, 1200, 1200, 300);'); [t, Tk] = euler_implicite(f, dfdT, 1200, 1200, 300);
disp('>> round(Tk'')'); round(Tk')
disp('>> min(Tk)'); min(Tk)

disp('### 7b) derivee fausse');
disp('>> dfdT_faux = @(t, T) -dfdT(t, T);'); dfdT_faux = @(t, T) -dfdT(t, T);
disp('>> [t, Tf, nf] = euler_implicite(f, dfdT_faux, 1200, 1200, 5);'); [t, Tf, nf] = euler_implicite(f, dfdT_faux, 1200, 1200, 5);
disp('>> Tf(end)'); Tf(end)
disp('>> [max(nf)  mean(nf)]'); [max(nf)  mean(nf)]

disp('### 8a) le rayonnement');
disp('>> [fc, dfc] = modele_four(false);'); [fc, dfc] = modele_four(false);
disp('>> [t, Tc] = rk4(fc, 1200, 1200, 5);'); [t, Tc] = rk4(fc, 1200, 1200, 5);
disp('>> [Tr(end)  Tc(end)]'); [Tr(end)  Tc(end)]
disp('>> 5*(find(Tr <= 600, 1) - 1)'); 5*(find(Tr <= 600, 1) - 1)
disp('>> 5*(find(Tc <= 600, 1) - 1)'); 5*(find(Tc <= 600, 1) - 1)

disp('### 8b) ode45');
disp('>> opts = odeset(''RelTol'', 1e-8, ''AbsTol'', 1e-10);'); opts = odeset('RelTol', 1e-8, 'AbsTol', 1e-10);
disp('>> [t45, T45] = ode45(f, [0 1200], 1200, opts);'); [t45, T45] = ode45(f, [0 1200], 1200, opts);
disp('>> [numel(t45) - 1  T45(end)]'); [numel(t45) - 1  T45(end)]
diary off;
