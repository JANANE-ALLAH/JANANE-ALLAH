function [t, T, nit] = euler_implicite(f, dfdT, T0, tf, h)
% Euler implicite : T(n+1) = T(n) + h f(t(n+1), T(n+1)).
% A chaque pas, on resout F(x) = x - T(n) - h f(t(n+1), x) = 0 par Newton.
N = round(tf/h);
t = (0:N)'*h;
T = zeros(N+1, 1);
T(1) = T0;
nit = zeros(N, 1);
for n = 1:N
    x = T(n);
    for k = 1:20
        F  = x - T(n) - h*f(t(n+1), x);
        dF = 1 - h*dfdT(t(n+1), x);
        delta = -F/dF;
        x = x + delta;
        if abs(delta) < 1e-10, break; end
    end
    T(n+1) = x;
    nit(n) = k;
end
end
