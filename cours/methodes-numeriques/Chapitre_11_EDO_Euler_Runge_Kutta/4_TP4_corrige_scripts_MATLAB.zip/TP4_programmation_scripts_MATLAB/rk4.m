function [t, T] = rk4(f, T0, tf, h)
% Runge-Kutta d'ordre 4 : quatre pentes par pas.
N = round(tf/h);
t = (0:N)'*h;
T = zeros(N+1, 1);
T(1) = T0;
for n = 1:N
    k1 = f(t(n), T(n));
    k2 = f(t(n)+h/2, T(n)+h/2*k1);
    k3 = f(t(n)+h/2, T(n)+h/2*k2);
    k4 = f(t(n)+h, T(n)+h*k3);
    T(n+1) = T(n) + h/6*(k1 + 2*k2 + 2*k3 + k4);
end
end
