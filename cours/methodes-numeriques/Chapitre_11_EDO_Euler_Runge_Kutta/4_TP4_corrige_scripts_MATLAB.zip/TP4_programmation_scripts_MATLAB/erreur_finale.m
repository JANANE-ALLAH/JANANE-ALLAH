function err = erreur_finale(schema, h)
% Erreur sur T(tf) d'un schema, mesuree contre une reference RK4 a tres petit pas (h = 0.1 s).
%   schema = 'euler' | 'rk4' | 'implicite'
[f, dfdT] = modele_four();
T0 = 1200; tf = 1200;
[~, Tref] = rk4(f, T0, tf, 0.1);
switch schema
    case 'euler'
        [~, T] = euler_explicite(f, T0, tf, h);
    case 'rk4'
        [~, T] = rk4(f, T0, tf, h);
    case 'implicite'
        [~, T] = euler_implicite(f, dfdT, T0, tf, h);
end
err = abs(T(end) - Tref(end));
end
