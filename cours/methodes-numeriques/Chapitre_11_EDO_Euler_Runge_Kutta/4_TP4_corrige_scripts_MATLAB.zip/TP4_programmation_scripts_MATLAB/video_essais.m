%% video_essais.m -- tous les nombres de la video « TP4 complet » (four, EDO non lineaire)
clear; close all; clc;
[f, dfdT] = modele_four();
T0 = 1200; tf = 1200;

%% E1 : manipulation 1 (h = 5 s)
h = 5;
[t, Te]  = euler_explicite(f, T0, tf, h);
[~, Tr]  = rk4(f, T0, tf, h);
[~, Ti, nit] = euler_implicite(f, dfdT, T0, tf, h);
fprintf('--- E1 : h = %g s ---\n', h);
fprintf('T(0)      = %.4f\n', Te(1));
fprintf('Euler     : T(tf) = %.4f K\n', Te(end));
fprintf('RK4       : T(tf) = %.4f K\n', Tr(end));
fprintf('Implicite : T(tf) = %.4f K\n', Ti(end));
fprintf('|Euler-RK4| = %.4f K ; |Impl-RK4| = %.4f K\n', abs(Te(end)-Tr(end)), abs(Ti(end)-Tr(end)));
fprintf('Newton : iterations par pas min %d max %d moyenne %.2f ; premier pas %d\n', min(nit), max(nit), mean(nit), nit(1));
fprintf('nombre de pas N = %d ; premier pas Euler T(h) = %.4f ; RK4 T(h) = %.4f ; Impl T(h) = %.4f\n', numel(t)-1, Te(2), Tr(2), Ti(2));
fprintf('pente initiale f(0,T0) = %.6f K/s\n', f(0, T0));
fprintf('derivee initiale dfdT(0,T0) = %.6f 1/s\n', dfdT(0, T0));

%% E2 : ordre de convergence (reference = RK4 avec h = 0.1)
[~, Tref] = rk4(f, T0, tf, 0.1);
hs = [40 20 10 5 2.5];
err = zeros(numel(hs), 3);
for i = 1:numel(hs)
    [~, a] = euler_explicite(f, T0, tf, hs(i));
    [~, b] = rk4(f, T0, tf, hs(i));
    [~, c] = euler_implicite(f, dfdT, T0, tf, hs(i));
    err(i,:) = abs([a(end) b(end) c(end)] - Tref(end));
end
fprintf('\n--- E2 : reference RK4 h = 0.1 : T(tf) = %.6f K ---\n', Tref(end));
fprintf('   h      err Euler     err RK4       err Impl\n');
for i = 1:numel(hs)
    fprintf('%5.1f   %.4e   %.4e   %.4e\n', hs(i), err(i,1), err(i,2), err(i,3));
end
rap = err(1:end-1,:)./err(2:end,:);
fprintf('rapports (h -> h/2) :\n');
for i = 1:size(rap,1)
    fprintf('%5.1f -> %5.1f   %.3f   %.3f   %.3f\n', hs(i), hs(i+1), rap(i,1), rap(i,2), rap(i,3));
end
pente = zeros(1,3);
for j = 1:3
    p = polyfit(log(hs'), log(err(:,j)), 1);
    pente(j) = p(1);
end
fprintf('pentes log-log : Euler %.4f  RK4 %.4f  Impl %.4f\n', pente(1), pente(2), pente(3));

%% E3 : stabilite, grands pas
fprintf('\n--- E3 : grands pas ---\n');
lam = abs(dfdT(0, T0));
fprintf('|lambda| = %.6f 1/s ; 2/|lambda| = %.2f s\n', lam, 2/lam);
for hh = [100 200 250 300 400]
    [tt, a] = euler_explicite(f, T0, tf, hh);
    [~, b] = rk4(f, T0, tf, hh);
    [~, c, nn] = euler_implicite(f, dfdT, T0, tf, hh);
    fprintf('h = %3d : Euler T(tf) = %12.4f (min %.1f max %.1f) | RK4 T(tf) = %10.4f | Impl T(tf) = %8.4f (iter max %d)\n', ...
        hh, a(end), min(a), max(a), b(end), c(end), max(nn));
end

%% E4 : Jacobienne fausse (signe)
fprintf('\n--- E4 : derivee fausse dans Newton ---\n');
dfdT_faux = @(t,T) +(8 + 4*5e-9*T.^3)/5000;
[~, Tf, nf] = euler_implicite(f, dfdT_faux, T0, tf, 5);
fprintf('derivee de mauvais signe : T(tf) = %.4f K (juste : %.4f) ; iterations par pas max %d moyenne %.2f\n', Tf(end), Ti(end), max(nf), mean(nf));
dfdT_nul = @(t,T) 0*T;
[~, Tz, nz] = euler_implicite(f, dfdT_nul, T0, tf, 5);
fprintf('derivee oubliee (point fixe) : T(tf) = %.4f K ; iterations par pas max %d moyenne %.2f\n', Tz(end), max(nz), mean(nz));

%% E5 : effet du rayonnement (manipulation 3)
[fc, dfc] = modele_four(false);
[~, Tc] = rk4(fc, T0, tf, 5);
fprintf('\n--- E5 : rayonnement ---\n');
fprintf('RK4 avec : %.4f ; sans : %.4f ; ecart %.2f K\n', Tr(end), Tc(end), Tr(end)-Tc(end));
i1 = find(Tr <= 600, 1); i2 = find(Tc <= 600, 1);
fprintf('temps pour 600 K : avec %.0f s ; sans %.0f s\n', (i1-1)*5, (i2-1)*5);
fprintf('T a 300 s : avec %.4f ; sans %.4f\n', Tr(61), Tc(61));
fprintf('part du rayonnement dans la perte a t = 0 : %.2f %%\n', 100*(5e-9*(T0^4-293^4))/(8*(T0-293)+5e-9*(T0^4-293^4)));

%% E6 : ode45 / ode15s
opts = odeset('RelTol',1e-8,'AbsTol',1e-10);
[t45, T45] = ode45(f, [0 tf], T0, opts);
fprintf('\n--- E6 : ode45 (RelTol 1e-8) : %d pas, T(tf) = %.6f K, ecart a la reference = %.2e K\n', numel(t45)-1, T45(end), abs(T45(end)-Tref(end)));
[t15, T15] = ode15s(f, [0 tf], T0, opts);
fprintf('ode15s : %d pas, T(tf) = %.6f K\n', numel(t15)-1, T15(end));

%% donnees pour les figures
if ~exist('sorties','dir'), mkdir sorties; end
dlmwrite('sorties/courbe_rk4_h5.csv', [t Tr Te Ti], 'precision', '%.6f');
dlmwrite('sorties/erreurs.csv', [hs' err], 'precision', '%.8e');
dlmwrite('sorties/rayonnement.csv', [t Tr Tc], 'precision', '%.6f');
[tg, ag] = euler_explicite(f, T0, tf, 300); [~, bg] = rk4(f, T0, tf, 300); [~, cg] = euler_implicite(f, dfdT, T0, tf, 300);
dlmwrite('sorties/grand_pas_h300.csv', [tg ag bg cg], 'precision', '%.6f');

%% E7 : iterations de Newton du premier pas (h = 5 s)
x = T0; rows = [];
for k = 1:6
    F  = x - T0 - 5*f(5, x);
    dF = 1 - 5*dfdT(5, x);
    delta = -F/dF;
    x = x + delta;
    rows = [rows; k x F delta];
    if abs(delta) < 1e-10, break; end
end
fprintf('\n--- E7 : Newton, premier pas ---\n');
fprintf('F(T0) = %.6f ; dF(T0) = %.6f\n', T0 - T0 - 5*f(5, T0), 1 - 5*dfdT(5, T0));
for i = 1:size(rows,1)
    fprintf('k=%d  x=%.10f  F=%.4e  delta=%.4e\n', rows(i,1), rows(i,2), rows(i,3), rows(i,4));
end
dlmwrite('sorties/newton_pas1.csv', rows, 'precision', '%.12e');
