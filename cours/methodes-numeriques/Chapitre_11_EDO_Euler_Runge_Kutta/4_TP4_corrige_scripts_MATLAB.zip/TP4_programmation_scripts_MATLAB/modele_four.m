function [f, dfdT] = modele_four(rayonnement)
% Modele de la paroi de four : C dT/dt = -hA (T-Tamb) - epsA (T^4-Tamb^4)
% f(t,T) = dT/dt  et  dfdT(t,T) = derivee de f par rapport a T.
% rayonnement = false : convection seule (manipulation 3).
if nargin < 1, rayonnement = true; end
C = 5000; hA = 8; epsA = 5e-9; Tamb = 293;
if rayonnement
    f    = @(t,T) -(hA*(T-Tamb) + epsA*(T.^4-Tamb^4))/C;
    dfdT = @(t,T) -(hA + 4*epsA*T.^3)/C;
else
    f    = @(t,T) -(hA*(T-Tamb))/C;
    dfdT = @(t,T) -hA/C + 0*T;
end
end
