%% video_essais.m -- tous les nombres de la video « TP6 complet » (attracteur de Lorenz)
clear; close all; clc;
F = modele_lorenz();
Y0 = [1; 1; 1]; tf = 20; h = 0.01;
if ~exist('sorties', 'dir'), mkdir sorties; end

%% E1 : simulation RK4 (manipulation 1)
[t, Y] = rk4_systeme(F, Y0, tf, h);
fprintf('--- E1 : RK4, h = %g, tf = %g ---\n', h, tf);
fprintf('taille de Y : %d x %d ; nombre de pas N = %d\n', size(Y,1), size(Y,2), size(Y,1)-1);
fprintf('Y(2,:) = (%.6f, %.6f, %.6f)\n', Y(2,1), Y(2,2), Y(2,3));
fprintf('Y(t=20) = (%.4f, %.4f, %.4f)\n', Y(end,1), Y(end,2), Y(end,3));
fprintf('max|x| = %.4f, max|y| = %.4f, max|z| = %.4f ; min z = %.4f\n', max(abs(Y(:,1))), max(abs(Y(:,2))), max(abs(Y(:,3))), min(Y(:,3)));
chg = sum(diff(sign(Y(:,1))) ~= 0);
fprintf('changements de signe de x (passages d''une aile a l''autre) : %d\n', chg);
fprintf('part du temps avec x > 0 : %.1f %%\n', 100*mean(Y(:,1) > 0));
fprintf('z moyen = %.4f\n', mean(Y(:,3)));
[~, i1] = max(Y(:,3)); fprintf('z max = %.4f a t = %.2f\n', Y(i1,3), t(i1));

%% E2 : sensibilite aux conditions initiales (manipulation 2)
[~, Yp] = rk4_systeme(F, [1.001; 1; 1], tf, h);
d = distance_trajectoires(Y, Yp);
fprintf('\n--- E2 : perturbation de 1e-3 sur x(0) ---\n');
fprintf('distance initiale = %.4e\n', d(1));
for tc = [1 2 5 10 15 20]
    fprintf('t = %2d : distance = %.4e\n', tc, d(round(tc/h)+1));
end
for tc = [0.1 0.2 0.3 0.5]
    fprintf('t = %.1f : distance = %.4e\n', tc, d(round(tc/h)+1));
end
i3 = find(d > 1, 1); fprintf('premier instant ou la distance depasse 1 : t = %.2f\n', t(i3));
i4 = find(d > 10, 1); fprintf('premier instant ou la distance depasse 10 : t = %.2f\n', t(i4));
fprintf('distance maximale : %.4f\n', max(d));
% exposant de Lyapunov : pente de log(d) sur la phase de croissance
fen = (t >= 10) & (t <= 18);
p = polyfit(t(fen), log(d(fen)), 1);
fprintf('pente de log d sur [10, 18] : %.4f -> exposant de Lyapunov estime = %.4f (valeur connue 0.9056)\n', p(1), p(1));
fprintf('temps pour multiplier la distance par 10 : %.2f s\n', log(10)/p(1));

%% E3 : Euler explicite contre RK4 (manipulation 3)
[~, Ye] = euler_systeme(F, Y0, tf, h);
fprintf('\n--- E3 : Euler explicite, h = %g ---\n', h);
fprintf('Euler Y(20) = (%.4f, %.4f, %.4f)\n', Ye(end,1), Ye(end,2), Ye(end,3));
fprintf('RK4   Y(20) = (%.4f, %.4f, %.4f)\n', Y(end,1), Y(end,2), Y(end,3));
de = distance_trajectoires(Y, Ye);
for tc = [0.5 1 2 3 5 10 20]
    fprintf('t = %4.1f : ecart Euler-RK4 = %.4e\n', tc, de(round(tc/h)+1));
end
j1 = find(de > 1, 1); fprintf('Euler s''ecarte de RK4 de plus de 1 a t = %.2f\n', t(j1));
% reference tres fine pour juger lequel des deux est juste
[~, Yr] = rk4_systeme(F, Y0, tf, 0.001);
Yr10 = Yr(1:10:end, :);
fprintf('reference RK4 h = 0.001 : Y(20) = (%.4f, %.4f, %.4f)\n', Yr(end,1), Yr(end,2), Yr(end,3));
dr = distance_trajectoires(Y, Yr10);
for tc = [5 10 15 18 20]
    fprintf('t = %2d : ecart RK4(h=0.01) - reference = %.4e ; Euler - reference = %.4e\n', tc, dr(round(tc/h)+1), distance_trajectoires(Ye(round(tc/h)+1,:), Yr10(round(tc/h)+1,:)));
end
k1 = find(dr > 1, 1); if isempty(k1), k1t = NaN; else, k1t = t(k1); end
fprintf('RK4 (h=0.01) s''ecarte de la reference de plus de 1 a t = %.2f\n', k1t);
k2 = find(dr > 0.01, 1); if isempty(k2), k2t = NaN; else, k2t = t(k2); end
fprintf('RK4 (h=0.01) s''ecarte de la reference de plus de 0,01 a t = %.2f\n', k2t);

%% E4 : le pas de temps
fprintf('\n--- E4 : Euler explicite avec un grand pas ---\n');
for hh = [0.05 0.02 0.1]
    [tt, Yb] = euler_systeme(F, Y0, tf, hh);
    big = find(any(abs(Yb) > 1000, 2), 1);
    if isempty(big)
        fprintf('h = %.2f : pas d''explosion ; Y(20) = (%.4f, %.4f, %.4f) ; max|Y| = %.2f\n', hh, Yb(end,1), Yb(end,2), Yb(end,3), max(abs(Yb(:))));
    else
        fprintf('h = %.2f : |Y| depasse 1000 au pas %d (t = %.2f)\n', hh, big-1, tt(big));
    end
end
for hh = [0.1 0.05 0.02]
    [tt, Yb] = rk4_systeme(F, Y0, tf, hh);
    fprintf('RK4 h = %.2f : Y(20) = (%.4f, %.4f, %.4f) ; max|Y| = %.2f\n', hh, Yb(end,1), Yb(end,2), Yb(end,3), max(abs(Yb(:))));
end
% RK4 a grand pas : trace-t-il encore un papillon ?
[~, Y1] = rk4_systeme(F, Y0, tf, 0.1);
fprintf('RK4 h = 0.1 : changements de signe de x = %d\n', sum(diff(sign(Y1(:,1))) ~= 0));
% temps de calcul
tic; rk4_systeme(F, Y0, tf, 0.01); tr = toc;
tic; euler_systeme(F, Y0, tf, 0.01); te = toc;
fprintf('temps de calcul : RK4 %.3f s, Euler %.3f s (rapport %.1f)\n', tr, te, tr/te);

%% E5 : piege du vecteur ligne
Fligne = @(t, Y) [10*(Y(2)-Y(1)), Y(1)*(28-Y(3))-Y(2), Y(1)*Y(2)-8/3*Y(3)];
fprintf('\n--- E5 : F qui rend un vecteur ligne ---\n');
try
    [~, Yl] = rk4_systeme(Fligne, Y0, 1, 0.01);
    fprintf('pas d''erreur ; taille de Y : %d x %d ; Y(end,:) = (%.4f, %.4f, %.4f)\n', size(Yl,1), size(Yl,2), Yl(end,1), Yl(end,2), Yl(end,3));
catch err
    fprintf('erreur : %s\n', err.message);
end

%% donnees pour les figures
dlmwrite('sorties/trajectoire_xz.csv', [t(1:4:end) Y(1:4:end,1) Y(1:4:end,3)], 'precision', '%.6f');
[t1, Y1] = rk4_systeme(F, Y0, tf, 0.1);
dlmwrite('sorties/trajectoire_xz_h01.csv', [t1 Y1(:,1) Y1(:,3)], 'precision', '%.6f');
dlmwrite('sorties/trajectoire_xt.csv', [t(1:4:end) Y(1:4:end,1) Yp(1:4:end,1)], 'precision', '%.6f');
dlmwrite('sorties/distance.csv', [t(1:5:end) d(1:5:end)], 'precision', '%.8e');
sel = t <= 6;
dlmwrite('sorties/euler_rk4_court.csv', [t(sel) Y(sel,1) Ye(sel,1)], 'precision', '%.6f');
dlmwrite('sorties/ecart_reference.csv', [t(1:5:end) dr(1:5:end) de(1:5:end)], 'precision', '%.8e');
