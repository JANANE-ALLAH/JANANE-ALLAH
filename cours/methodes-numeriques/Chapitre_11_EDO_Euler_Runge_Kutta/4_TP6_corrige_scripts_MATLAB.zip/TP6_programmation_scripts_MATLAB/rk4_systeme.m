function [t, Y] = rk4_systeme(F, Y0, tf, h)
% Runge-Kutta d'ordre 4 pour un SYSTEME : Y0 est un vecteur colonne, F(t, Y) rend un vecteur colonne.
% Y(n, :) contient l'etat a l'instant t(n) (une ligne par instant).
N = round(tf/h);
t = (0:N)'*h;
Y = zeros(N+1, numel(Y0));
Y(1, :) = Y0(:)';
for n = 1:N
    y = Y(n, :)';
    k1 = F(t(n), y);
    k2 = F(t(n)+h/2, y + h/2*k1);
    k3 = F(t(n)+h/2, y + h/2*k2);
    k4 = F(t(n)+h, y + h*k3);
    Y(n+1, :) = (y + h/6*(k1 + 2*k2 + 2*k3 + k4))';
end
end
