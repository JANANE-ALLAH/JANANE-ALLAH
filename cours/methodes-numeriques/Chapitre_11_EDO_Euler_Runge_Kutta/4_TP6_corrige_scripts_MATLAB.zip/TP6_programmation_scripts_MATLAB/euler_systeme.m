function [t, Y] = euler_systeme(F, Y0, tf, h)
% Euler explicite pour un systeme : Y(n+1) = Y(n) + h F(t(n), Y(n)).
N = round(tf/h);
t = (0:N)'*h;
Y = zeros(N+1, numel(Y0));
Y(1, :) = Y0(:)';
for n = 1:N
    y = Y(n, :)';
    Y(n+1, :) = (y + h*F(t(n), y))';
end
end
