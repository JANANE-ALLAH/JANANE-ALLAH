function d = distance_trajectoires(Y1, Y2)
% Distance euclidienne entre deux trajectoires, instant par instant (une valeur par ligne).
d = sqrt(sum((Y1 - Y2).^2, 2));
end
