%% video_consoles.m
% Les " fenetres de commandes " de la video : chaque commande est rejouee telle qu'elle apparait a l'ecran,
% avec les memes noms de variables, et sa sortie est celle de MATLAB.
% Les lignes vides de MATLAB et les en-tetes " ### " ne sont pas affiches dans la video.
% Lancement (depuis ce dossier) :  matlab -batch "video_consoles"      (sortie : sorties/video_consoles.txt)
clear; clc; format short;
if ~exist('sorties', 'dir'), mkdir('sorties'); end
if exist('sorties/video_consoles.txt', 'file'), delete('sorties/video_consoles.txt'); end
diary('sorties/video_consoles.txt');
warning('off', 'backtrace');

disp('### 2a) le modele');
disp('>> F = modele_lorenz();'); F = modele_lorenz();
disp('>> F(0, [1; 1; 1])'); F(0, [1; 1; 1])
disp('>> F(0, [10; 10; 30])'); F(0, [10; 10; 30])

disp('### 3a) RK4 pour un systeme');
disp('>> [t, Y] = rk4_systeme(F, [1; 1; 1], 20, 0.01);'); [t, Y] = rk4_systeme(F, [1; 1; 1], 20, 0.01);
disp('>> size(Y)'); size(Y)
disp('>> Y(2, :)'); Y(2, :)
disp('>> Y(end, :)'); Y(end, :)
disp('>> max(abs(Y))'); max(abs(Y))
disp('>> sum(diff(sign(Y(:, 1))) ~= 0)'); sum(diff(sign(Y(:, 1))) ~= 0)

disp('### 4a) sensibilite aux conditions initiales');
disp('>> [~, Yp] = rk4_systeme(F, [1.001; 1; 1], 20, 0.01);'); [~, Yp] = rk4_systeme(F, [1.001; 1; 1], 20, 0.01);
disp('>> d = distance_trajectoires(Y, Yp);'); d = distance_trajectoires(Y, Yp);
disp('>> format short e'); format short e
disp('>> d([1 101 501 1001 1501 2001])'); d([1 101 501 1001 1501 2001])
disp('>> format short'); format short
disp('>> t(find(d > 1, 1))'); t(find(d > 1, 1))

disp('### 5a) Euler explicite contre RK4');
disp('>> [~, Ye] = euler_systeme(F, [1; 1; 1], 20, 0.01);'); [~, Ye] = euler_systeme(F, [1; 1; 1], 20, 0.01);
disp('>> Ye(end, :)'); Ye(end, :)
disp('>> [~, Yr] = rk4_systeme(F, [1; 1; 1], 20, 0.001);'); [~, Yr] = rk4_systeme(F, [1; 1; 1], 20, 0.001);
disp('>> Yr = Yr(1:10:end, :);'); Yr = Yr(1:10:end, :);
disp('>> Yr(end, :)'); Yr(end, :)
disp('>> dr = distance_trajectoires(Y, Yr);'); dr = distance_trajectoires(Y, Yr);
disp('>> de = distance_trajectoires(Ye, Yr);'); de = distance_trajectoires(Ye, Yr);
disp('>> format short e'); format short e
disp('>> [dr(501)  de(501)]'); [dr(501)  de(501)]
disp('>> format short'); format short
disp('>> t(find(dr > 1, 1))'); t(find(dr > 1, 1))

disp('### 6a) le pas de temps');
disp('>> [tt, Yb] = euler_systeme(F, [1; 1; 1], 20, 0.05);'); [tt, Yb] = euler_systeme(F, [1; 1; 1], 20, 0.05);
disp('>> k = find(any(abs(Yb) > 1000, 2), 1);'); k = find(any(abs(Yb) > 1000, 2), 1);
disp('>> [k - 1  tt(k)]'); [k - 1  tt(k)]
disp('>> [~, Y1] = rk4_systeme(F, [1; 1; 1], 20, 0.1);'); [~, Y1] = rk4_systeme(F, [1; 1; 1], 20, 0.1);
disp('>> sum(diff(sign(Y1(:, 1))) ~= 0)'); sum(diff(sign(Y1(:, 1))) ~= 0)

disp('### 6b) vecteur ligne');
disp('>> Fl = @(t, Y) [10*(Y(2)-Y(1)), Y(1)*(28-Y(3))-Y(2), Y(1)*Y(2)-8/3*Y(3)];'); Fl = @(t, Y) [10*(Y(2)-Y(1)), Y(1)*(28-Y(3))-Y(2), Y(1)*Y(2)-8/3*Y(3)];
disp('>> [t, Y] = rk4_systeme(Fl, [1; 1; 1], 1, 0.01);');
try
    [t, Y] = rk4_systeme(Fl, [1; 1; 1], 1, 0.01);
catch err
    disp(['Error in rk4_systeme (line ' num2str(err.stack(1).line) ')']);
    disp(strrep(err.message, ' and the size', [' and' newline 'the size']));
end
diary off;
