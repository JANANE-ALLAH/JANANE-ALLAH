function F = modele_lorenz(sigma, rho, beta)
% Systeme de Lorenz : Y = [x; y; z],  dY/dt = F(t, Y)  (vecteur COLONNE).
%   x' = sigma (y - x),   y' = x (rho - z) - y,   z' = x y - beta z.
% Valeurs classiques : sigma = 10, rho = 28, beta = 8/3.
if nargin < 3, sigma = 10; rho = 28; beta = 8/3; end
F = @(t, Y) [sigma*(Y(2) - Y(1)); Y(1)*(rho - Y(3)) - Y(2); Y(1)*Y(2) - beta*Y(3)];
end
